package common.utilities;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

public class WebDriverFactory {
    public static WebDriver initializeDriver() {
        //WebDriverManager.chromedriver().setup();
        System.setProperty("webdriver.chrome.driver","C:\\Users\\" + System.getProperty("user.name") + "\\Desktop\\chromedriver.exe");
        DesiredCapabilities chromCaps = new DesiredCapabilities();
        ChromeOptions options = new ChromeOptions();
        options.setExperimentalOption("useAutomationExtension", false);
        options.addArguments("--force-device-scale-factor=1");
        //headless
        options.addArguments("--start-maximized");
        options.addArguments("--disable-gpu");
        //options.addArguments("--remote-debugging-port=9222");
        options.addArguments("--disable-extensions");
        //options.addArguments("--disable-dev-shm-usage");
        //options.addArguments("--window-size=1920,1080");
        options.addArguments("--no-sandbox");
        //options.addArguments("test-type");

        options.addArguments("--disable-infobars");
        options.addArguments("--ignore-certificate-errors");
        chromCaps.setCapability("chrome.binary", "Chrome exe path");
        chromCaps.setCapability(ChromeOptions.CAPABILITY, options);
        chromCaps.acceptInsecureCerts();
        return new ChromeDriver(options);
    }
}
