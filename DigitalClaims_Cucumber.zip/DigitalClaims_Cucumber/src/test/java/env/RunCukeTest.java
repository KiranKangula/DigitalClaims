package env;


import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
		plugin = {
			 "pretty", "html:target/cucumberHtmlReport",
		     "html:target/cucumberHtmlReport",     //  for html result
			 "pretty:target/cucumber-json-report.json"   // for json result
		     },
		features = "src/test/Resources/features",
		monochrome = false,
		glue = {"StepDefinition"   // predefined step definitions package
			   }
)

public class RunCukeTest extends AbstractTestNGCucumberTests {
}
