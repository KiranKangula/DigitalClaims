package StepDefinition;

import common.utilities.WebDriverFactory;
import io.cucumber.java.en.*;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import pages.LoginPage;

public class OSPC {
    WebDriver driver;
    LoginPage loginPage;

    @Given("User launches OSPC URL")
    public void user_launches_ospc_url() {

        driver = WebDriverFactory.initializeDriver();
        driver.get("https://bat.ospc.wsib.ca/");


       // System.out.println("Step 1");

    }
    @When("User login to application")
    public void user_login_to_application() {
        System.out.println("Step 2");

    }
    @Then("My Claims screen is displayed")
    public void my_claims_screen_is_displayed() {
        System.out.println("Step 3");

    }

    @Given("User is on My Claim screen")
    public void userIsOnMyClaimScreen() {
    }

    @When("User clicks on Claimnumber")
    public void userClicksOnClaimnumber() {
    }

    @Then("My Claim overview screen should be displayed")
    public void myClaimOverviewScreenShouldBeDisplayed() {
    }

    @When("User Clicks on Benefit payments link")
    public void userClicksOnBenefitPaymentsLink() {
    }

    @Then("Benefit payments screen should be displayed")
    public void benefitPaymentsScreenShouldBeDisplayed() {
    }

    @When("User Clicks on Health care benefits link")
    public void userClicksOnHealthCareBenefitsLink() {
    }

    @Then("Health care benefits screen should be displayed")
    public void healthCareBenefitsScreenShouldBeDisplayed() {
    }

    @When("User Clicks on Non-health care benefits link")
    public void userClicksOnNonHealthCareBenefitsLink() {
    }

    @Then("Non-health care benefits screen should be displayed")
    public void nonHealthCareBenefitsScreenShouldBeDisplayed() {
    }

    @When("User Clicks on Appeals link")
    public void userClicksOnAppealsLink() {
    }

    @Then("Appeals screen should be displayed")
    public void appealsScreenShouldBeDisplayed() {
    }
}
