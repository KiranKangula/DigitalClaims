Feature: Application Login

  Background: Login to Application
    Given User launches OSPC URL
    When User login to application
    Then My Claims screen is displayed

  Scenario: OSPC MyClaimsOverview
    Given User is on My Claim screen
    When User clicks on Claimnumber
    Then My Claim overview screen should be displayed
    When User Clicks on Benefit payments link
    Then Benefit payments screen should be displayed
    When User Clicks on Health care benefits link
    Then Health care benefits screen should be displayed
    When User Clicks on Non-health care benefits link
    Then Non-health care benefits screen should be displayed
    When User Clicks on Appeals link
    Then Appeals screen should be displayed