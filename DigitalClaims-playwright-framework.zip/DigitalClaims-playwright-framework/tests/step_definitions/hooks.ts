// tests/step_definitions/hooks.ts
import { Before, After, Status } from '@cucumber/cucumber';
import { chromium, firefox, request } from '@playwright/test';
import { CustomWorldClass } from './world';
import { JsonUtils } from '../../utils/JsonUtils';
import { ConfigLoader } from '../../utils/ConfigLoader';

Before(async function (this: CustomWorldClass, scenario) {
  const env = process.env.ENV || 'SIT2';
  const tags = scenario.pickle.tags.map((t) => t.name);

  const sheetTag = tags.find((t) => t.startsWith('@SheetName_'));
  this.sheetName = sheetTag ? sheetTag.replace('@SheetName_', '') : undefined;

  if (tags.some((t) => t.includes('NonWSIB'))) {
    this.scenarioType = 'NonWSIB';
  } else if (tags.some((t) => t.includes('WSIB'))) {
    this.scenarioType = 'WSIB';
  } else {
    this.scenarioType = 'Unknown';
  }

  this.config = ConfigLoader.loadEnvConfig(env);
  this.commonConfig = ConfigLoader.loadCommonConfig();

  if (this.sheetName) {
    this.data = JsonUtils.readJsonData(this.sheetName);
    this.currentIndex = 0;
    this.currentRow = this.data && this.data.length > 0 ? this.data[0] : {};
  }

  this.request = await request.newContext();

  const isApiOnly = tags.includes('@API') && !tags.some((t) => t.includes('@B2BForm7') && !t.includes('@Token'));
  if (!isApiOnly) {
    const browserType = (this.config?.browser || 'chrome').toLowerCase();
    const headless = process.env.HEADLESS === 'true';

    if (browserType.includes('edge')) {
      this.browser = await chromium.launch({ headless, channel: 'msedge' });
    } else if (browserType.includes('firefox')) {
      this.browser = await firefox.launch({ headless });
    } else {
      this.browser = await chromium.launch({ headless, channel: 'chrome' });
    }

    this.context = await this.browser.newContext({
      viewport: { width: 1440, height: 900 },
      ignoreHTTPSErrors: true
    });
    this.page = await this.context.newPage();
    this.initPages();
  }
});

After(async function (this: CustomWorldClass, scenario) {
  if (scenario.result?.status === Status.FAILED && this.page) {
    const screenshot = await this.page.screenshot();
    this.attach(screenshot, 'image/png');
  }

  await this.page?.close();
  await this.context?.close();
  await this.browser?.close();
  await this.request?.dispose();
});