import { When, Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { AxeResults } from 'axe-core';
import { CustomWorld } from './world';
import { AccessibilityUtils } from '../../utils/AccessibilityUtils';

let lastScanResults: AxeResults;

/**
 * Equivalent to Java:
 * @When("User runs accessibility scan on {string}")
 */
When('User runs accessibility scan on {string}', async function (this: CustomWorld, pageName: string) {
  if (!this.page) {
    throw new Error('Playwright page is not initialized in CustomWorld.');
  }

  lastScanResults = await AccessibilityUtils.runAccessibilityScan(this.page, pageName);

  // Log results into Cucumber report (equivalent to Hooks.scenario.get().log)
  const summary = AccessibilityUtils.buildViolationSummary(lastScanResults);
  this.attach(summary, 'text/plain');
});

/**
 * Equivalent to Java:
 * @Then("the page should have no critical WCAG violations")
 */
Then('the page should have no critical WCAG violations', async function (this: CustomWorld) {
  const summary = AccessibilityUtils.buildViolationSummary(lastScanResults);
  const hasCritical = AccessibilityUtils.hasCriticalViolations(lastScanResults);

  expect(
    hasCritical,
    `Critical/Serious WCAG violations found:\n${summary}`
  ).toBeFalsy();
});

/**
 * Equivalent to Java:
 * @Then("the page should have no WCAG violations")
 */
Then('the page should have no WCAG violations', async function (this: CustomWorld) {
  const summary = AccessibilityUtils.buildViolationSummary(lastScanResults);
  const count = lastScanResults ? lastScanResults.violations.length : 0;

  expect(
    count,
    `WCAG violations found:\n${summary}`
  ).toBe(0);
});

/**
 * Equivalent to Java:
 * @And("User logs all WCAG results without failing")
 */
Then('User logs all WCAG results without failing', async function (this: CustomWorld) {
  // Soft check — logs everything, never fails the scenario
  const summary = AccessibilityUtils.buildViolationSummary(lastScanResults);
  this.attach(summary, 'text/plain');
  console.log(summary);
});