// tests/step_definitions/GuidewireCC.ts
import { Given, When, Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { CustomWorldClass } from './world';

Given('User is on GWlogin page', async function (this: CustomWorldClass) {
  if (!this.shouldRun('User is on GWlogin page')) return;
  const gwUrl = this.config?.baseUrl || this.config?.ClaimCenter || this.config?.GWURl || 'https://sit2.wsib.on.ca/cc/ClaimCenter.do';
  await this.gwLogin.launchGWCC(gwUrl);
});

When('User submit username and password', async function (this: CustomWorldClass) {
  if (!this.shouldRun('User submit username and password')) return;
  const user = this.config?.GWCC_Username || 'bonaiutt';
  const pass = this.config?.GWCC_Password || 'welcome1';
  await this.gwLogin.loginGWCC(user, pass);
});

Then('User should be able to login successfully into GWCC', async function (this: CustomWorldClass) {
  if (!this.shouldRun('User should be able to login successfully into GWCC')) return;
  await this.gwLogin.verifyonGWCC();
});

Then('Switch to New tab and Login to ClaimCenter', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Switch to New tab and Login to ClaimCenter')) return;
  const gwUrl = this.config?.baseUrl || this.config?.ClaimCenter || this.config?.GWURl || 'https://sit2.wsib.on.ca/cc/ClaimCenter.do';
  await this.gwLogin.switchtab(gwUrl);
  const user = this.config?.GWCC_Username || 'bonaiutt';
  const pass = this.config?.GWCC_Password || 'welcome1';
  await this.gwLogin.loginGWCC(user, pass);
});

Then('Navigate to Portal Authorization screen', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Navigate to Portal Authorization screen')) return;
  await this.gwAdmin.navigatePortalAuthScreen();
});

Then('Remove the {string} from profile', async function (this: CustomWorldClass, claimNumber: string) {
  if (!this.shouldRun('Remove claim from profile')) return;
  const clm = claimNumber.startsWith('<') ? (this.currentRow?.['Claim Number'] || this.claimNumber || '') : claimNumber;
  await this.gwAdmin.removeClaimfromPortalAuth(clm);
});

Then('Remove all the claims from profile', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Remove all claims from profile')) return;
  const user = this.config?.OSPC_username || this.config?.OSPC_Username || 'Kiran_Kangula@wsib.on.ca';
  await this.gwAdmin.removeAllClaimfromPortalAuth(user);
});

Then('Search for {string}', async function (this: CustomWorldClass, claimNumber: string) {
  if (!this.shouldRun('Search for claim')) return;
  const clm = claimNumber.startsWith('<') ? (this.currentRow?.['Claim Number'] || this.claimNumber || '') : claimNumber;
  await this.gwSearch.searchClaim(clm);
});

Then('Search for Claim number', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Search for Claim number')) return;
  const clm = this.currentRow?.['Claim Number'] || this.claimNumber || '';
  await this.gwSearch.searchClaim(clm);
});

Then('Search for Reference Number', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Search for Reference Number')) return;
  const ref = this.refNumber || this.currentRow?.['ReferenceNumber'] || '';
  await this.gwSearch.searchReference(ref);
});

Then('Search with firstname and lastname & dateofbirth', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Search with name & DOB')) return;
  await this.gwSearch.searchClaimant(
    this.currentRow?.['First Name'] || this.currentRow?.['firstname'] || 'Auto',
    this.currentRow?.['Last Name'] || this.currentRow?.['lastname'] || 'Test',
    this.currentRow?.['Date of Birth'] || this.currentRow?.['dateofbirth'] || '01/01/1990'
  );
});

Then('Search with firstname and lastname & dateofbirth {string}', async function (this: CustomWorldClass, dob: string) {
  if (!this.shouldRun('Search with name & DOB param')) return;
  const dateVal = dob.startsWith('<') ? (this.currentRow?.['dateofbirth'] || '01/01/1990') : dob;
  await this.gwSearch.searchClaimant(
    this.currentRow?.['First Name'] || this.currentRow?.['firstname'] || 'Auto',
    this.currentRow?.['Last Name'] || this.currentRow?.['lastname'] || 'Test',
    dateVal
  );
});

Then('Search for UNCD {string}', async function (this: CustomWorldClass, claimNumber: string) {
  if (!this.shouldRun('Search for UNCD')) return;
  const clm = claimNumber.startsWith('<') ? (this.currentRow?.['claimnumber'] || this.currentRow?.['Claim Number'] || '') : claimNumber;
  await this.gwSearch.searchClaim(clm);
});

Then('Search for the NIHL claimant in GWCC', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Search for NIHL claimant')) return;
  await this.gwSearch.searchClaimant(
    this.currentRow?.['First Name'] || 'NIHLFirst',
    this.currentRow?.['Last Name'] || 'NIHLLast',
    this.currentRow?.['Date of Birth'] || '01/01/1980'
  );
});

Then('User should be able to see the message displayed from OSPC', async function (this: CustomWorldClass) {
  if (!this.shouldRun('verify message in GWCC')) return;
  await this.gwParticipants.searchMessage(this.dynamicMessage || 'Test API');
});

Then('Verify the document is landed in GWCC with valid Author and Description', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Verify document in GWCC')) return;
  const author = this.currentRow?.['Author'] || 'OSPC';
  const desc = this.currentRow?.['Description'] || 'Dental report';
  await this.gwDocuments.verifyLandedDocuments(author, desc);
});

Then('Verify the document are landed in GWCC with valid Author and Description', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Verify documents multi in GWCC')) return;
  const authors = this.currentRow?.['Author'] || 'OSPC';
  const descriptions = this.currentRow?.['Descriptions'] || this.currentRow?.['Description'] || 'Dental report';
  await this.gwDocuments.verifyLandedDocuments(authors, descriptions);
});

Then('Verify the UNCD document is landed in GWCC with {string}, {string}', async function (this: CustomWorldClass, author: string, desc: string) {
  if (!this.shouldRun('Verify UNCD doc in GWCC')) return;
  const auth = author.startsWith('<') ? (this.currentRow?.['Author'] || 'OSPC') : author;
  const dsc = desc.startsWith('<') ? (this.currentRow?.['Description'] || 'Report') : desc;
  await this.gwDocuments.verifyLandedDocuments(auth, dsc);
});

Then('Verify the NIHL submission documents landed in GWCC', async function (this: CustomWorldClass, dataTable: any) {
  if (!this.shouldRun('Verify NIHL doc in GWCC')) return;
  const rows = dataTable.rowsHash();
  const rawAuthors = rows['SupportingAuthors'] || '';
  const rawDescriptions = rows['SupportingDescriptions'] || '';

  const authors = rawAuthors.startsWith('<') ? (this.currentRow?.['GWCCSupportingAuthors'] || '') : rawAuthors;
  const descriptions = rawDescriptions.startsWith('<') ? (this.currentRow?.['GWCCSupportingDescriptions'] || '') : rawDescriptions;

  if (authors && descriptions) {
    await this.gwDocuments.verifyLandedDocuments(authors, descriptions);
  }
});

Then('Verify the Appeal is created in ClaimCenter', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Verify Appeal in GWCC')) return;
  await this.gwAppeals.createAppeals();
});

Then('Verify the Direct Deposit is displayed in ClaimCenter', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Verify Direct Deposit in GWCC')) return;
  await this.gwParticipants.verifyDirectDepositUpdateInGWCC();
});

Then('Verify the Mailing address is updated in GWCC', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Verify Mailing address in GWCC')) return;
  const addr = this.currentRow?.['Address Line1'] || '140 Erskine Ave';
  await this.gwParticipants.verifyMailingAddressUpdateInGWCC(addr);
});

Then('Verify that history events are generated for Mailing address update in GWCC', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Verify history events for address')) return;
  await this.gwCCHistory.verifyHistory();
});

Then('Verify the Phone Number is updated in GWCC', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Verify Phone Number in GWCC')) return;
  const ph = this.currentRow?.['Phone Number'] || '647-800-0000';
  await this.gwParticipants.verifyPhoneNumberUpdateInGWCC(ph);
});

Then('Verify that history events are generated for Phone Number update in GWCC', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Verify history events for phone')) return;
  await this.gwCCHistory.verifyHistory();
});

Then('Run the DI batch job in ClaimCenter to process the Auto Registration', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Run DI batch job')) return;
  await this.gwAdmin.runDIBatch();
});

Then('Verify the Claim is Auto Registered in ClaimCenter', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Verify Auto Registered Claim')) return;
  this.claimNumber = await this.gwSearch.verifyAutoRegisteredClaim(this.refNumber || '');
  expect(this.claimNumber).toBeTruthy();
  this.currentRow['Claim Number'] = this.claimNumber;
  this.persistCurrentRow();
});

Given('User Logged into ClaimCenter', async function (this: CustomWorldClass) {
  if (!this.shouldRun('User Logged into ClaimCenter')) return;
  await this.gwSearch.GWCCLoginsuccess();
});

When('User initiates Manual Registration', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Manual Registration')) return;
  await this.gwRegistration.KickManualRegistration();
});

Then('User selects Source of Information', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Source of Information')) return;
  const src = this.currentRow?.['Source of Information'] || 'Form 6';
  await this.gwRegistration.selectSourceofInformation(src);
});

Then('User enters new worker information', async function (this: CustomWorldClass) {
  if (!this.shouldRun('New worker info')) return;
  await this.gwRegistration.enterWorkerDetails(
    this.currentRow?.['firstname'] || 'Kiran',
    this.currentRow?.['lastname'] || 'Kangulaa',
    this.currentRow?.['dateofbirth'] || '01/01/2000',
    this.currentRow?.['gender'] || 'Male',
    this.currentRow?.['postalcode'] || 'M4P 1Z2',
    this.currentRow?.['phonenumber'] || '647-800-0000'
  );
});

Then('User searches for Existing Worker', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Existing Worker search')) return;
  await this.gwRegistration.searchExistingWorker(
    this.currentRow?.['firstname'] || 'Kiran',
    this.currentRow?.['lastname'] || 'Kangulaa',
    this.currentRow?.['dateofbirth'] || '01/01/2000'
  );
});

Then('User searches for Account with bussiness activity', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Account with business activity')) return;
  const acc = this.currentRow?.['Account#'] || this.currentRow?.['accountNumber'] || '1169879';
  await this.gwRegistration.accountActivity(acc);
});

Then('User enters Accident Details', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Accident Details')) return;
  await this.gwRegistration.enterAccidentDetails(
    this.currentRow?.['dateofaccident'] || '17/12/2024',
    this.currentRow?.['dateReported'] || '17/12/2024'
  );
});

Then('User Enters Body part details', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Body part details')) return;
  await this.gwRegistration.enterBodyPartDetails(
    this.currentRow?.['areaofbody'] || 'Head',
    this.currentRow?.['areaofinjury'] || 'Face',
    'Left',
    this.currentRow?.['natureofinjury'] || 'Major Burns',
    this.currentRow?.['detailedaccidentType'] || 'Burn'
  );
});

Then('Select Third Party accident', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Third Party accident')) return;
  const tpa = this.currentRow?.['Thirdparty'] || 'No';
  await this.gwRegistration.TPASelection(tpa);
});

Then('Select Accident Location from the dropdown', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Accident Location')) return;
  await this.gwRegistration.selectAccidentLocation();
});

Then('Select Health Care Received', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Health Care Received')) return;
  const hc = this.currentRow?.['HealthCareReceived'] || 'No';
  await this.gwRegistration.selectHealthCareRecieved(hc);
});

Then('Select Claim Type', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Select Claim Type')) return;
  const ct = this.currentRow?.['ClaimType'] || 'Lost Time';
  await this.gwRegistration.selectClaimType(ct);
});

Then('Click on Register Claim button and verify that Claim has been registered Successfully', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Register Claim button')) return;
  const claimList = await this.gwRegistration.clickOnRegisterClaimButton();
  this.claimNumber = Array.isArray(claimList) ? claimList[0] : String(claimList);
  expect(this.claimNumber).toBeTruthy();
  this.currentRow['Claim Number'] = this.claimNumber;
  this.persistCurrentRow();
});

Given('I have created a new claim in GW ClaimCenter with New Worker', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Create claim New Worker')) return;
  await this.gwSearch.GWCCLoginsuccess();
  await this.gwRegistration.KickManualRegistration();
  await this.gwRegistration.selectSourceofInformation(this.currentRow?.['Source of Information'] || 'Form 6');
  await this.gwRegistration.enterWorkerDetails(
    this.currentRow?.['firstname'] || 'Kiran',
    this.currentRow?.['lastname'] || 'Kangulaa',
    this.currentRow?.['dateofbirth'] || '01/01/2000',
    this.currentRow?.['gender'] || 'Male',
    this.currentRow?.['postalcode'] || 'M4P 1Z2',
    this.currentRow?.['phonenumber'] || '647-800-0000'
  );
  await this.gwRegistration.accountActivity(this.currentRow?.['Account#'] || '1169879');
  await this.gwRegistration.enterAccidentDetails(
    this.currentRow?.['dateofaccident'] || '17/12/2024',
    this.currentRow?.['dateReported'] || '17/12/2024'
  );
  await this.gwRegistration.enterBodyPartDetails(
    this.currentRow?.['areaofbody'] || 'Head',
    this.currentRow?.['areaofinjury'] || 'Face',
    'Left',
    this.currentRow?.['natureofinjury'] || 'Major Burns',
    this.currentRow?.['detailedaccidentType'] || 'Burn'
  );
  await this.gwRegistration.TPASelection(this.currentRow?.['Thirdparty'] || 'No');
  await this.gwRegistration.selectAccidentLocation();
  await this.gwRegistration.selectHealthCareRecieved(this.currentRow?.['HealthCareReceived'] || 'No');
  await this.gwRegistration.selectClaimType(this.currentRow?.['ClaimType'] || 'Lost Time');
  const claimList = await this.gwRegistration.clickOnRegisterClaimButton();
  this.claimNumber = Array.isArray(claimList) ? claimList[0] : String(claimList);
  this.currentRow['Claim Number'] = this.claimNumber;
  this.persistCurrentRow();
});

Given('I have created a new claim in GW ClaimCenter with Existing Worker', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Create claim Existing Worker')) return;
  await this.gwSearch.GWCCLoginsuccess();
  await this.gwRegistration.KickManualRegistration();
  await this.gwRegistration.selectSourceofInformation(this.currentRow?.['Source of Information'] || 'Form 6');
  await this.gwRegistration.searchExistingWorker(
    this.currentRow?.['firstname'] || 'Kiran',
    this.currentRow?.['lastname'] || 'Kangulaa',
    this.currentRow?.['dateofbirth'] || '01/01/2000'
  );
  await this.gwRegistration.accountActivity(this.currentRow?.['Account#'] || '1169879');
  await this.gwRegistration.enterAccidentDetails(
    this.currentRow?.['dateofaccident'] || '17/12/2024',
    this.currentRow?.['dateReported'] || '17/12/2024'
  );
  await this.gwRegistration.enterBodyPartDetails(
    this.currentRow?.['areaofbody'] || 'Head',
    this.currentRow?.['areaofinjury'] || 'Face',
    'Left',
    this.currentRow?.['natureofinjury'] || 'Major Burns',
    this.currentRow?.['detailedaccidentType'] || 'Burn'
  );
  await this.gwRegistration.TPASelection(this.currentRow?.['Thirdparty'] || 'No');
  await this.gwRegistration.selectAccidentLocation();
  await this.gwRegistration.selectHealthCareRecieved(this.currentRow?.['HealthCareReceived'] || 'No');
  await this.gwRegistration.selectClaimType(this.currentRow?.['ClaimType'] || 'Lost Time');
  const claimList = await this.gwRegistration.clickOnRegisterClaimButton();
  this.claimNumber = Array.isArray(claimList) ? claimList[0] : String(claimList);
  this.currentRow['Claim Number'] = this.claimNumber;
  this.persistCurrentRow();
});

Then('Setup Appeals Data on the Claim', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Setup Appeals')) return;
  await this.gwAppeals.createAppeals();
});

Then('Setup RTW information on the Claim', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Setup RTW')) return;
  await this.gwRecovery.setupRTWData(this.currentRow?.['Proposed_RTW_Goal'] || this.currentRow?.['RTW_Goal'] || 'RTW Pre-Injury');
});

Then('Setup Device Details on the Claim', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Setup Devices')) return;
  await this.gwRecovery.setupDevicesData(this.currentRow?.['DevicesData'] || '[]');
});

Then('Setup Independent Living Allowance on the Claim', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Setup ILA')) return;
  await this.gwRecovery.setupILAData(this.currentRow?.['ILA_Data'] || '[]');
});

Then('Setup Personal Care Allowance on the Claim', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Setup PCA')) return;
  await this.gwRecovery.setupPCAData(this.currentRow?.['PCA_Data'] || '[]');
});

Then('Setup Clothing Allowance on the Claim', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Setup Clothing Allowance')) return;
  await this.gwRecovery.setupClothingAllowanceData(this.currentRow?.['Clothing_Data'] || '[]');
});

Then('Setup Treatment Details on the Claim', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Setup Treatment')) return;
  await this.gwRecovery.setupTreatmentData(this.currentRow?.['Treatment_Data'] || '[]');
});

Then('Setup Medication Details on the Claim', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Setup Medication')) return;
  await this.gwRecovery.setupMedicationData(this.currentRow?.['Medication_Data'] || '[]');
});

Then('Setup Payments data on the Claim', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Setup Payments')) return;
  await this.gwRecovery.setupPaymentsData(this.currentRow?.['TAmount'] || '5000');
});

Then('Verify intake and Worker Information and Validate worker Address', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Verify intake and Worker Information')) return;
  const address = this.currentRow?.['Address Line1'] || this.currentRow?.['postalcode'] || 'M4P 1Z2';
  await this.gwRegistration.validateIntakeAndWorkerAddress(address);
});