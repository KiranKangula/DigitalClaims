// tests/step_definitions/GuidewireCM.ts
import { Given, When, Then } from '@cucumber/cucumber';
import { CustomWorldClass } from './world';

Then('Switch to New tab and Login to Contact Manager', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Switch to New tab and Login to Contact Manager')) return;
  const cmUrl = this.config?.CMURL || this.config?.CMUrl || this.config?.cmUrl || 'https://cm-gssit1-gwcpdev.wsib.alpha3-butterfly.guidewire.net/ContactManager.do';
  await this.guidewirecm.switchtabCM(cmUrl);
});

Then('Search for the Contact using {string} and {string}', async function (this: CustomWorldClass, firstName: string, lastName: string) {
  if (!this.shouldRun('Search for the Contact')) return;
  const fn = firstName.startsWith('<') ? (this.currentRow?.['FirstName'] || this.currentRow?.['First Name'] || 'Auto') : firstName;
  const ln = lastName.startsWith('<') ? (this.currentRow?.['LastName'] || this.currentRow?.['Last Name'] || 'Test') : lastName;
  await this.guidewirecm.searchFirstNameAndLastName(fn, ln);
});

Then('Verify the Direct Deposit is displayed in ContactManager', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Verify Direct Deposit in CM')) return;
  await this.guidewirecm.verifyDirectDepositUpdateInGWCM();
});

Then('Remove the Direct Deposit from the Contact', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Remove Direct Deposit from Contact')) return;
  const transitNumber = this.currentRow?.['transitnumber'] || this.currentRow?.['TransitNumber'] || '12345';
  const bankNumber = this.currentRow?.['banknumber'] || this.currentRow?.['InstitutionNumber'] || '004';
  const accountNumber = this.currentRow?.['accountnumber'] || this.currentRow?.['BankAccountNumber'] || '1234567';
  await this.guidewirecm.VerifyDDRemoveInGWCM(transitNumber, bankNumber, accountNumber);
});

Then('Verify the Mailing address is updated along with history events in Contact Manager', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Verify Mailing address in CM')) return;
  const address = this.currentRow?.['Address Line1'] || '140 Erskine Ave';
  await this.guidewirecm.verifyMailingAddressUpdateInGWCM(address);
});

Then('Verify the Phone Number is updated along with history events in Contact Manager', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Verify Phone Number in CM')) return;
  const phone = this.currentRow?.['Phone Number'] || '647-800-0000';
  await this.guidewirecm.verifyPhoneNumberUpdateInGWCM(phone);
});