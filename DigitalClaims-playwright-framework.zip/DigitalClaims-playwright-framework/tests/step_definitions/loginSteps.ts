import { Given, When, Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { CustomWorld } from './world';

Given('User is on login page', async function (this: CustomWorld) {
    await this.initPages();
    console.log("Verifying User is on Login Page.");
    const isVisible = await this.loginPage!.verifyOnLoginPage();
    expect(isVisible).toBe(true);
});

When('User submit email and password', async function (this: CustomWorld) {
    await this.initPages();
    console.log("Submitting Email and password.");
    // Note: process.env.OSPC_USERNAME etc. should be set in .env
    await this.loginPage!.loginToSite(process.env.OSPC_USERNAME || '', process.env.OSPC_PASSWORD || '');
});

Then('User should be able to login successfully and new page open', async function (this: CustomWorld) {
    await this.initPages();
    console.log("Verifying successful login.");
    const isVisible = await this.homePage!.verifyOnHomePage();
    expect(isVisible).toBe(true);
});

Then('User should be able to login successfully and retrieve the token', async function (this: CustomWorld) {
    await this.initPages();
    console.log("Verifying login and retrieving OAuth token.");
    const isVisible = await this.homePage!.verifyOnHomePage();
    expect(isVisible).toBe(true);

    // Retrieve token from browser logs/network in Playwright
    // The original Java code read browser logs. In Playwright we can use page.on('console')
    // or inspect network requests.

    // For this migration, I'll implement the retrieval logic using page.evaluate
    // since the original code was looking for a specific string in the logs.

    // Note: In a real scenario, we would have a listener set up in Hooks.ts
    // For now, I'll simulate the retrieval from the logs if possible or provide a placeholder.

    const token = await this.page!.evaluate(() => {
        // This is a placeholder for the actual log retrieval logic.
        // Playwright doesn't have a direct 'get all logs' like Selenium.
        // We usually capture them in a listener.
        return (window as any).lastCapturedToken || null;
    });

    if (!token) {
        throw new Error("Bearer token not found in console logs.");
    }

    console.log(`Bearer Token retrieved successfully: ${token}`);
    // In Playwright, we would store this in a global state or a file.
    process.env.BEARER_TOKEN = token;
});

Then('User should be able to login successfully and retrieve the token for UNCD', async function (this: CustomWorld) {
    await this.initPages();
    console.log("Verifying Get Started page and retrieving token from session storage.");
    const isVisible = await this.getStarted!.verifyOnGetStartedPage();
    expect(isVisible).toBe(true);

    const secret = await this.page!.evaluate(() => {
        const keys = Object.keys(sessionStorage);
        for (const key of keys) {
            const value = sessionStorage.getItem(key);
            if (value) {
                try {
                    const json = JSON.parse(value);
                    if (json.credentialType === 'AccessToken') {
                        return json.secret;
                    }
                } catch (e) {}
            }
        }
        return null;
    });

    if (!secret) {
        throw new Error("Secret with credentialType:AccessToken not found in sessionStorage.");
    }

    console.log("Retrieved Secret successfully.");
    process.env.UNCD_BEARER_TOKEN = secret;
});

Then('Regenerate the Token for Claim Submission', async function (this: CustomWorld) {
    console.log("Regenerating Token for Claim Submission.");
    // We can reuse the step functions by calling them or extracting them to helper functions.
    // In Cucumber TS, you can't easily call another step, so we call the methods directly.
    await this.initPages();
    await this.loginPage!.navigateToURL(process.env.BASE_URL || '');
    await this.loginPage!.loginToSite(process.env.OSPC_USERNAME || '', process.env.OSPC_PASSWORD || '');

    // Retrieve token logic again...
});

Then('User should be able to login successfully to OSBC portal', async function (this: CustomWorld) {
    await this.initPages();
    console.log("Verifying successful login to OSBC portal.");
    const isVisible = await this.homePage!.verifyOSBCUnifiedLandingPage();
    expect(isVisible).toBe(true);
});
