import { Given, When, Then, And } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { CustomWorld } from '../../support/world';

Given('User is on my Claim screen', async function (this: CustomWorld) {
    await this.initPages();
    this.log('Verifying User is on My Claims screen.');
    expect(await this.homePage.verifyOnHomePage()).toBeTruthy();
});

When('User clicks on {string}', async function (this: CustomWorld, claimnumberParam: string) {
    await this.initPages();
    const claimnumber = this.currentRow['Claim Number'];
    this.log(`Clicking on Claim Number: ${claimnumber}`);
    await this.homePage.clickClaim(claimnumber);
});

Then('User should be navigated to My Claims Overview screen', async function (this: CustomWorld) {
    await this.initPages();
    this.log('Verifying navigation to Claims Overview screen.');
    expect(await this.ospcClaimOverview.verifyOnClaimOverview()).toBeTruthy();
});

And('User should be navigated to Benefit Payments screen', async function (this: CustomWorld) {
    await this.initPages();
    this.log('Verifying navigation to Benefit Payments screen.');
    expect(await this.ospcClaimOverview.verifyOnBenefitpayments()).toBeTruthy();
});

And('User should be navigated to Healthcare benefit screen', async function (this: CustomWorld) {
    await this.initPages();
    this.log('Verifying navigation to Healthcare Benefit screen.');
    expect(await this.ospcClaimOverview.verifyOnHealthcarebenefits()).toBeTruthy();
});

And('User should be navigated to Non Health care benefit screen', async function (this: CustomWorld) {
    await this.initPages();
    this.log('Verifying navigation to Non-Healthcare Benefit screen.');
    expect(await this.ospcClaimOverview.verifyOnNonHealthcarebenefits()).toBeTruthy();
});

And('User should be navigated to Appeals screen', async function (this: CustomWorld) {
    await this.initPages();
    this.log('Verifying navigation to Appeals screen.');
    expect(await this.ospcClaimOverview.verifyOnAppeals()).toBeTruthy();
});

And('User should be navigated to Submit Document screen', async function (this: CustomWorld) {
    await this.initPages();
    this.log('Verifying navigation to Submit Document screen.');
    expect(await this.ospcClaimOverview.verifyOnSubmitDocuments()).toBeTruthy();
});

And('User should be able to select WSIB form {string}', async function (this: CustomWorld, wsibformParam: string) {
    await this.initPages();
    const wsibform = this.currentRow['wsibform'];
    this.log(`Selecting WSIB form: ${wsibform}`);
    expect(await this.ospcClaimOverview.selectWSIBForm(wsibform)).toBeTruthy();
});

And('User should be able to select WSIB forms {string}', async function (this: CustomWorld, wsibformsParam: string) {
    await this.initPages();
    const wsibforms = this.currentRow['wsibforms'];
    this.log(`Selecting WSIB form: ${wsibforms}`);
    expect(await this.ospcClaimOverview.selectWSIBForm(wsibforms)).toBeTruthy();
});

And('User should be able to select Non WSIB form {string} and {string}', async function (this: CustomWorld, nonwsibformtypeParam: string, nonwsibformParam: string) {
    await this.initPages();
    const nonwsibformtype = this.currentRow['nonwsibformtype'];
    const nonwsibform = this.currentRow['nonwsibform'];
    this.log(`Selecting Non WSIB form: ${nonwsibformtype} and ${nonwsibform}`);
    expect(await this.ospcClaimOverview.selectNonWSIBForm(nonwsibformtype, nonwsibform)).toBeTruthy();
});

And('User should be able to select Non WSIB forms {string} and {string}', async function (this: CustomWorld, nonwsibformsTypeParam: string, nonwsibformsParam: string) {
    await this.initPages();
    const nonwsibformsType = this.currentRow['nonwsibformstype'];
    const nonwsibforms = this.currentRow['nonwsibforms'];
    this.log(`Selecting WSIB form: ${nonwsibforms}`);
    expect(await this.ospcClaimOverview.selectNonWSIBForm(nonwsibformsType, nonwsibforms)).toBeTruthy();
});

And('Select confirmation checkbox and Click on Submit button', async function (this: CustomWorld) {
    await this.initPages();
    this.log('Selecting confirmation checkbox and clicking Submit.');
    expect(await this.ospcClaimOverview.submitDocument()).toBeTruthy();
    this.log(`Document Submitted at: ${new Date().toLocaleString()}`);
});

And('User should be able to upload a document with {string}', async function (this: CustomWorld, filenameParam: string) {
    await this.initPages();
    const filesToUpload = this.currentRow['filename'];
    this.log(`Uploading document: ${filesToUpload}`);
    await this.ospcClaimOverview.uploadDocuments(filesToUpload);
});

And('User should be able to upload documents with {string}', async function (this: CustomWorld, filenamesParam: string) {
    await this.initPages();
    const filesToUpload = this.currentRow['filenames'];
    this.log(`Uploading documents: ${filesToUpload}`);
    await this.ospcClaimOverview.uploadDocuments(filesToUpload);
});

And('Verify the Document History is updated with {string}', async function (this: CustomWorld, formtype: string) {
    await this.initPages();
    let documentCategory: string;
    let documentDescription: string;

    if (formtype === 'WSIB') {
        documentCategory = this.currentRow['documentCategory'];
        documentDescription = this.currentRow['documentDescription'];
    } else {
        documentCategory = this.currentRow['nondocumentCategory'];
        documentDescription = this.currentRow['nondocumentDescription'];
    }

    this.log(`Verifying Document History is updated with: ${documentCategory}::${documentDescription}`);
    expect(await this.ospcClaimOverview.documentHistory(formtype, documentCategory, documentDescription)).toBeTruthy();
});

And('Verify the Document History are updated with {string}', async function (this: CustomWorld, formtype: string) {
    await this.initPages();
    let documentCategories: string;
    let documentDescriptions: string;

    if (formtype === 'WSIB') {
        documentCategories = this.currentRow['documentCategories'];
        documentDescriptions = this.currentRow['documentDescriptions'];
    } else {
        documentCategories = this.currentRow['nondocumentCategories'];
        documentDescriptions = this.currentRow['nondocumentDescriptions'];
    }

    this.log(`Verifying Document History is updated with: ${documentCategories}::${documentDescriptions}`);
    expect(await this.ospcClaimOverview.documentHistory(formtype, documentCategories, documentDescriptions)).toBeTruthy();
});

And('User clicks on Send us a message link and Lands on Send us a message screen', async function (this: CustomWorld) {
    await this.initPages();
    this.log("Clicking on 'Send us a message' link.");
    expect(await this.ospcClaimOverview.verifyOnSendMessageScreen()).toBeTruthy();
});

And('User selects {string} and enter {string}', async function (this: CustomWorld, subject: string, message: string) {
    await this.initPages();
    this.log(`Sending message with subject: ${subject}`);
    expect(await this.ospcClaimOverview.sendUsAMessage(subject, message)).toBeTruthy();
});

And('User clicks on Send button and Lands on Message sent screen', async function (this: CustomWorld) {
    await this.initPages();
    this.log('Clicking Send button.');
    expect(await this.ospcClaimOverview.sendAndConfirm()).toBeTruthy();
});

And('Return to Mail and verify the sent message', async function (this: CustomWorld) {
    await this.initPages();
    this.log('Returning to Mail and verifying sent message.');
    expect(await this.ospcClaimOverview.mailScreen()).toBeTruthy();
});

When('User click on Add a Claim button', async function (this: CustomWorld) {
    await this.initPages();
    this.log("Clicking 'Add a Claim' button.");
    expect(await this.ospcClaimOverview.addClaim()).toBeTruthy();
});

Then('User should be able to add claim with {string}, {string}', async function (this: CustomWorld, claimNumberParam: string, yobParam: string) {
    await this.initPages();
    if (!this.shouldRun('Adding Claim')) return;

    const claimNumber = this.currentRow['Claim Number'];
    const yob = (this.currentRow['DOB'] || '').split('/')[2];
    const injurDate = this.currentRow['QInjurDate'];
    const phoneNumber = this.currentRow['QPhoneNumber'];
    const employerName = this.currentRow['QEmployerName'];
    const postalcode = this.currentRow['QPostalcode'];
    const injuryArea = this.currentRow['QAreaofInjury'];

    this.log(`Adding Claim: ${claimNumber} with YOB: ${yob}`);
    expect(await this.ospcClaimOverview.addAClaimOSPC(claimNumber, yob, injurDate, phoneNumber, employerName, postalcode, injuryArea)).toBeTruthy();
});

And('Switch back to OSPC and verify if the {string} is removed', async function (this: CustomWorld, claimnumberParam: string) {
    await this.initPages();
    if (!this.shouldRun('Switching back to OSPC and verifying removal of claim')) return;

    const claimnumber = this.currentRow['Claim Number'];
    this.log(`Switching back to OSPC and verifying removal of claim: ${claimnumber}`);
    expect(await this.ospcClaimOverview.claimRemovalConfirmationOSPC(claimnumber)).toBeTruthy();
});

And('Switch back to OSPC and verify if the {string} is added', async function (this: CustomWorld, claimnumberParam: string) {
    await this.initPages();
    const claimnumber = this.currentRow['Claim Number'];
    this.log(`Switching back to OSPC and verifying addition of claim: ${claimnumber}`);
    expect(await this.ospcClaimOverview.claimAdditionalConfirmationOSPC(claimnumber)).toBeTruthy();
});

And('Switch to New Tab and Login to OSPC and verify if the {string} is added', async function (this: CustomWorld, claimnumberParam: string) {
    await this.initPages();
    const claimnumber = this.currentRow['Claim Number'];
    this.log(`Navigating to OSPC URL and logging in to verify claim: ${claimnumber}`);

    await this.loginPage.navigateToURL(process.env.OSPC_URL || '');
    await this.loginPage.loginToSite(process.env.OSPC_Username || '', process.env.OSPC_Password || '');
    expect(await this.ospcClaimOverview.claimAdditionConfirmationOSPC(claimnumber)).toBeTruthy();
});

And('Switch back to OSPC and verify appeal registered is displayed', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Switch back to OSPC and verify appeal registered is displayed')) return;

    this.log('Verifying appeal registration in OSPC.');
    const actualCount = await this.ospcClaimOverview.appealRegisteredConfirmationOSPC();
    if (actualCount > (this as any).appealsCount) {
        expect(true).toBeTruthy();
    }
});

And('User should be navigated to Appeals screen and count number of appeals', async function (this: CustomWorld) {
    await this.initPages();
    this.log('Navigating to Appeals screen and counting appeals.');
    (this as any).appealsCount = await this.ospcClaimOverview.verifyCountOfAppeals();
});

When('User clicks on contact information link on my claim screen', async function (this: CustomWorld) {
    await this.initPages();
    this.log("Clicking on 'Contact Information' link.");
    expect(await this.tombstone.clickContactInfoLink()).toBeTruthy();
});

Then('User should be view Personal details, Mailing address and Contact details', async function (this: CustomWorld) {
    await this.initPages();
    this.log('Verifying Personal Details, Mailing Address and Contact Details.');
    expect(await this.tombstone.verifyFullName()).toBeTruthy();
    expect(await this.tombstone.verifyAddress()).toBeTruthy();
    expect(await this.tombstone.verifyPhoneNumber()).toBeTruthy();
});

When('User clicks on Edit button to update Mailing address', async function (this: CustomWorld) {
    await this.initPages();
    this.log('Clicking Edit Mailing Address button.');
    expect(await this.tombstone.clickEditMailingAddress()).toBeTruthy();
});

Then('User should be able to update the Mailing address details and Save', async function (this: CustomWorld) {
    await this.initPages();
    this.log('Updating Mailing Address and saving.');
    expect(await this.tombstone.updateMailingAddress()).toBeTruthy();
});

When('User clicks on Edit button to update Phone Number', async function (this: CustomWorld) {
    await this.initPages();
    this.log('Clicking Edit Phone Number button.');
    expect(await this.tombstone.clickEditPhoneNumber()).toBeTruthy();
});

Then('User should be able to update the Phone Number and Save', async function (this: CustomWorld) {
    await this.initPages();
    this.log('Updating Phone Number and saving.');
    expect(await this.tombstone.updatePhoneNumber()).toBeTruthy();
});
