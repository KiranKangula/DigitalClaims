// tests/step_definitions/eForm6.ts
import { Given, When, Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { CustomWorldClass } from './world';

Given('User is on my Claim screen', async function (this: CustomWorldClass) {
  if (!this.shouldRun('User is on my Claim screen')) return;
  await this.ospcHome.verifyOnHomePage();
});

When('User click on Submit Report button', async function (this: CustomWorldClass) {
  if (!this.shouldRun('User click on Submit Report button')) return;
  await this.ospcHome.clickOnSubmitReport();
});

Then('User should be able to provide consent to the privacy statement', async function (this: CustomWorldClass) {
  if (!this.shouldRun('privacy statement')) return;
  await this.eform6.provideConcent();
});

Then('User should be able to select report type {string}', async function (this: CustomWorldClass, reportType: string) {
  if (!this.shouldRun('select report type')) return;
  const rep = reportType.startsWith('<') ? (this.currentRow?.['Report Type'] || 'Injury or Illness') : reportType;
  await this.eform6.selectReportType(rep);
});

Then('User should be able to select Injury Type {string}', async function (this: CustomWorldClass, injuryType: string) {
  if (!this.shouldRun('select Injury Type')) return;
  const inj = injuryType.startsWith('<') ? (this.currentRow?.['Injury Type'] || 'Physical Injury') : injuryType;
  await this.eform6.selectInjuryType(inj);
});

Then('User should be able to select radio {string}, Body Part {string}', async function (this: CustomWorldClass, physicalInjury: string, bodyPart: string) {
  if (!this.shouldRun('select radio PhysicalInjury Body Part')) return;
  const bp = bodyPart.startsWith('<') ? (this.currentRow?.['Body Part'] || 'Ear(s)') : bodyPart;
  await this.eform6.selectPhysicalInjury(bp);
});

Then('User should be able to enter {string} if applicable', async function (this: CustomWorldClass, existingClaim: string) {
  if (!this.shouldRun('Existing Claim Number')) return;
  const clm = existingClaim.startsWith('<') ? (this.currentRow?.['Existing Claim Number'] || '') : existingClaim;
  await this.eform6.enterExistingClaimNumber(clm);
});

Then('User should be able to enter {string}, {string}, {string}, {string}', async function (this: CustomWorldClass, fn: string, ln: string, phone: string, pronouns: string) {
  if (!this.shouldRun('enter name and contact')) return;
  const firstName = fn.startsWith('<') ? (this.currentRow?.['First Name'] || 'Autojoi') : fn;
  const lastName = ln.startsWith('<') ? (this.currentRow?.['Last Name'] || 'Testmpb') : ln;
  const ph = phone.startsWith('<') ? (this.currentRow?.['Phone Number'] || '6478444444') : phone;
  const pr = pronouns.startsWith('<') ? (this.currentRow?.['Pronouns'] || 'He/Him') : pronouns;
  await this.eform6.enterWorkerPersonalDetails(firstName, lastName, ph, pr);
});

Then('Enter Additional personal details', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Enter Additional personal details')) return;
  const sin = this.currentRow?.['SIN'] || '';
  const address = this.currentRow?.['Address'] || '140 Erskine Avenue|Toronto|Ontario|M4P 1Z2';
  const preferredLang = this.currentRow?.['Language of Service'] || 'English';
  const dob = this.currentRow?.['Date of Birth'] || this.currentRow?.['dateofbirth'] || '01/Jan/1990';
  await this.eform6.enterAdditionalDetails(sin, address, preferredLang, dob);
});

Then('Enter Additional personal details - Exposure', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Enter Additional personal details - Exposure')) return;
  const sin = this.currentRow?.['SIN'] || '';
  const address = this.currentRow?.['Address'] || '140 Erskine Avenue|Toronto|Ontario|M4P 1Z2';
  const preferredLang = this.currentRow?.['Language of Service'] || 'English';
  const dob = this.currentRow?.['Date of Birth'] || this.currentRow?.['dateofbirth'] || '01/Jan/1990';
  await this.eform6.enterAdditionalDetails(sin, address, preferredLang, dob);
});

Then('Enter Worker Address Details', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Enter Worker Address Details')) return;
  await this.eform6.enterWorkerAddressDetails(this.currentRow?.['Address'] || '140 Erskine Avenue|Toronto|Ontario|M4P 1Z2');
});

Then('Enter Employers Details', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Enter Employers Details')) return;
  await this.eform6.enterEmployerDetails(
    this.currentRow?.['Account Number'] || this.currentRow?.['Account#'] || '1102322',
    this.currentRow?.['Employer Name'] || 'Acme Corp',
    this.currentRow?.['Address'] || '140 Erskine Avenue|Toronto|Ontario|M4P 1Z2'
  );
});

Then('Verify the reference number is generated and displayed', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Verify reference number')) return;
  this.refNumber = await this.eform6.verifyReferenceNumber();
  expect(this.refNumber).toBeTruthy();
  this.currentRow['ReferenceNumber'] = this.refNumber;
  this.persistCurrentRow();
});

Then('Enter the Job Details of the Worker', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Enter Job Details')) return;
  const supervisor = (this.currentRow?.['Supervisor Contact'] || 'S First|S Last|6478787777|English').split('|');
  await this.eform6_workhistory.enterWorkerDetails(
    this.currentRow?.['Job Title'] || 'Employee',
    this.currentRow?.['Emp Start Date'] || '1/Jan/2020',
    this.currentRow?.['Emp Years'] || '5',
    this.currentRow?.['Emp Months'] || '1',
    this.currentRow?.['# Employees'] || 'No',
    this.currentRow?.['Union?'] || 'No',
    this.currentRow?.['IsSpouseRelavtive'] || 'No',
    this.currentRow?.['EmployerRelation'] || 'Self employed',
    supervisor[0] || 'S First',
    supervisor[1] || 'S Last'
  );
});

Then('Enter the Job Details of the Worker - Exposure Incident', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Enter Job Details - Exposure')) return;
  await this.eform6_exposuredetails.enterJobDetails(
    this.currentRow?.['Job Title'] || 'Construction Worker',
    this.currentRow?.['Emp Start Date'] || '1/Jan/2020'
  );
});

Then('Enter Joint Health and Safety Committee details', async function (this: CustomWorldClass) {
  if (!this.shouldRun('JHSC details')) return;
  await this.eform6_exposuredetails.enterJointHealthAndSafetyCommittee('No');
});

Then('Enter Tell us about your work details', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Tell us about your work')) return;
  await this.eform6_workhistory.enterWorkDetails(
    this.currentRow?.['WhatHappenedInput'] || 'Regular duties performed.',
    this.currentRow?.['Type of Work'] || 'Regular'
  );
});

Then('Enter the Physical injury or illness details', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Physical injury details')) return;
  await this.eform6_injurydetails.enterInjuryDetails(
    this.currentRow?.['Accident Type'] || 'Burn',
    this.currentRow?.['Described By'] || 'Fainting',
    'Symptoms test description'
  );
});

Then('Enter Injury date and time', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Injury date and time')) return;
  await this.eform6_injurydetails.enterInjuryDateAndTime(
    this.currentRow?.['Injury Date'] || '1/Feb/2024',
    '10:00 AM'
  );
});

Then('Enter Areas of Injury', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Areas of Injury')) return;
  await this.eform6_injurydetails.enterAreasOfInjury(
    this.currentRow?.['Body Parts'] || 'Ear(s)',
    'Left',
    'Head'
  );
});

Then('Enter Date and Time Injury Reported to Employer', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Date and Time Injury Reported')) return;
  const reportedTo = (this.currentRow?.['reported to?'] || 'Kiran|Kangula|6478777777|English').split('|');
  await this.eform6_injurydetails.enterDateAndTimeInjuryReported(
    this.currentRow?.['EmployerKnownDate'] || '1/Mar/2024',
    '10:00 AM',
    reportedTo[0] || 'Kiran',
    reportedTo[1] || 'Kangula',
    reportedTo[2] || '6478777777'
  );
});

Then('Enter Witnesses contact information', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Witnesses contact information')) return;
  await this.eform6_injurydetails.enterWitnessDetails(
    this.currentRow?.['Witness'] || 'No',
    '',
    '',
    '',
    'No'
  );
});

Then('Enter Injury, illness or exposure incident address', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Incident address')) return;
  await this.eform6_injurydetails.enterInjuryAddress();
});

Then('Enter Similar or related previous injury or illness details', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Previous injury details')) return;
  await this.eform6_injurydetails.enterPriorConditions(this.currentRow?.['Prior Conditions'] || 'No');
});

Then('Enter Health care for injury or illness details', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Health care details')) return;
  await this.eform6_healthcare.enterHealthCareDetails(
    this.currentRow?.['HealthCare'] || 'No',
    'Clinic',
    'Dr. Smith',
    '1/Feb/2024',
    'No',
    '',
    '',
    'No',
    'No'
  );
});

Then('Enter Missed time from work details', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Missed time details')) return;
  await this.eform6_losttimeearnings.enterLostTime(this.currentRow?.['LOE'] || 'No');
});

Then('Enter Modified Work Details', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Modified Work Details')) return;
  await this.eform6_losttimeearnings.enterModifiedWork(this.currentRow?.['Type of Work'] || 'Regular');
});

Then('Enter Return to work details', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Return to work details')) return;
  await this.eform6_losttimeearnings.enterReturnToWork('No');
});

Then('Enter Additional earnings and benefits information', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Additional earnings')) return;
  await this.eform6_losttimeearnings.enterAdditionalEarnings(this.currentRow?.['Wage Loss'] || 'No');
});

Then('Enter Authorized representative details', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Authorized representative')) return;
  await this.eform6_reviewandsubmit.enterAuthorizedRepresentative('No');
});

Then('Enter Submit supporting documents details', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Submit supporting documents details')) return;
  await this.eform6_supportingdocuments.enterSupportingDocuments();
});

Then('Upload and verify Form 6 supporting documents', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Upload Form 6 supporting documents')) return;
  await this.eform6_supportingdocuments.uploadSupportingDocuments();
});

Then('Enter Additional Comments details', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Additional Comments')) return;
  await this.eform6_reviewandsubmit.enterAdditionalComments('Automation Test Comments');
});

Then('Verify Review and submit report and Select Declaration checkbox', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Verify Review and submit')) return;
  await this.eform6_reviewandsubmit.acceptDeclaration();
});

Then('Select decision to Add claim to your account and Submit Report', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Submit Report')) return;
  await this.eform6_reviewandsubmit.submitReport('Yes');
});

Then('User selects Submission Requirement', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Submission Requirement')) return;
  await this.eform6_exposuredetails.enterSubmissionRequirement();
});

Then('Enter the Exposure Incident details', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Exposure Incident details')) return;
  await this.eform6_exposuredetails.enterExposureDetails(
    'Asbestos exposure during work',
    '140 Erskine Avenue, Toronto, ON',
    'Inhalation',
    'Lungs',
    '1/Feb/2024',
    '10:00 AM',
    '1/Feb/2024'
  );
});

Then('Verify Review and submit report and Select Declaration checkbox and Submit Exposure', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Submit Exposure')) return;
  await this.eform6_exposuredetails.submitExposure();
});

Then('Enter the injury or illness details', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Illness details')) return;
  await this.eform6_injurydetails.enterInjuryDetails('Illness', 'Respiratory', 'Cough');
});

Then('Enter Illness or medical condition details', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Medical condition details')) return;
  await this.eform6_injurydetails.enterIllnessDetails('Asthma', 'Shortness of breath', 'Wheezing');
});

Then('User should be able to Describe your Injury', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Describe your Injury')) return;
  await this.eform6_injurydetails.DescribeInjury('Mental Stress due to incident');
});

Then('Enter the Mental stress psychological injury details', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Mental stress details')) return;
  await this.eform6_injurydetails.enterMentalStressDetails('Traumatic Event', 'PTSD symptoms', 'Anxiety');
});

Then('Enter Mental stress psychological injury date details', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Mental stress date')) return;
  await this.eform6_injurydetails.enterMentalStressDateAndTime('1/Feb/2024', '10:00 AM');
});

Then('Enter Areas of Injury for Mental', async function (this: CustomWorldClass) {
  if (!this.shouldRun('Areas of Injury Mental')) return;
  await this.eform6_injurydetails.enterAreasOfInjury('Head', 'Left', 'Brain');
});

Then('User should be able to select {string} report type', async function (this: CustomWorldClass, repType: string) {
  if (!this.shouldRun('select report type string')) return;
  await this.eform6.selectReportType(repType);
});

Then('User should be able to select {string} Injury Type', async function (this: CustomWorldClass, injType: string) {
  if (!this.shouldRun('select injury type string')) return;
  await this.eform6.selectInjuryType(injType);
});

Then('User should be able to land on Continue to different online service to make a claim for noise-induced hearing loss screen', async function (this: CustomWorldClass) {
  if (!this.shouldRun('land on NIHL continue screen')) return;
  await this.eform6.verifyNIHLLandingScreen();
});