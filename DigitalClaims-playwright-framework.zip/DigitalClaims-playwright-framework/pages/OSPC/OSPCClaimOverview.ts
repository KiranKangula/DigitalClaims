// pages/OSPC/OSPCClaimOverview.ts
import { Page, Locator, expect } from '@playwright/test';
import { BasePage } from '../../utils/BasePage';
import * as path from 'path';

export class OSPCClaimOverview extends BasePage {
  readonly claimOverviewTab: Locator;
  readonly benefitPaymentsTab: Locator;
  readonly healthCareBenefitTab: Locator;
  readonly nonHealthCareBenefitTab: Locator;
  readonly appealsTab: Locator;
  readonly appealsCountBadge: Locator;

  readonly sendUsAMessageLink: Locator;
  readonly messageSubjectDropdown: Locator;
  readonly messageBodyTextarea: Locator;
  readonly sendMessageButton: Locator;
  readonly messageSentConfirmation: Locator;
  readonly returnToMailButton: Locator;

  readonly submitDocumentLink: Locator;
  readonly fileUploadInput: Locator;
  readonly wsibFormDropdown: Locator;
  readonly nonWsibCategoryDropdown: Locator;
  readonly nonWsibSubFormDropdown: Locator;
  readonly confirmationCheckbox: Locator;
  readonly documentSubmitButton: Locator;
  readonly documentHistoryTable: Locator;

  readonly addClaimButton: Locator;
  readonly claimNumberInput: Locator;
  readonly dobDayInput: Locator;
  readonly dobMonthSelect: Locator;
  readonly dobYearInput: Locator;
  readonly confirmAddClaimButton: Locator;

  constructor(page: Page) {
    super(page);
    this.claimOverviewTab = page.locator("//a[contains(text(),'Overview') or contains(@id,'overview')]");
    this.benefitPaymentsTab = page.locator("//a[contains(text(),'Benefit payments') or contains(text(),'Payments')]");
    this.healthCareBenefitTab = page.locator("//a[contains(text(),'Health care benefits') or contains(text(),'Healthcare')]");
    this.nonHealthCareBenefitTab = page.locator("//a[contains(text(),'Other benefits') or contains(text(),'Non-health')]");
    this.appealsTab = page.locator("//a[contains(text(),'Appeals')]");
    this.appealsCountBadge = page.locator("//a[contains(text(),'Appeals')]//span[contains(@class,'badge') or contains(@class,'count')]");

    this.sendUsAMessageLink = page.locator("//a[contains(text(),'Send us a message') or contains(@href,'message')]");
    this.messageSubjectDropdown = page.locator("select#subject, select[name='subject']");
    this.messageBodyTextarea = page.locator("textarea#message, textarea[name='message']");
    this.sendMessageButton = page.locator("//button[contains(text(),'Send') and @type='submit']");
    this.messageSentConfirmation = page.locator("//h1[contains(text(),'Message sent')] | //div[contains(text(),'Your message has been sent')]");
    this.returnToMailButton = page.locator("//a[contains(text(),'Return to messages') or contains(text(),'Back')]");

    this.submitDocumentLink = page.locator("//a[contains(text(),'Upload a document') or contains(text(),'Submit a document')]");
    this.fileUploadInput = page.locator("input[type='file']");
    this.wsibFormDropdown = page.locator("select#formType, select[name='formName']");
    this.nonWsibCategoryDropdown = page.locator("select#category, select[name='category']");
    this.nonWsibSubFormDropdown = page.locator("select#subCategory, select[name='subCategory']");
    this.confirmationCheckbox = page.locator("input[type='checkbox']#declaration, input[type='checkbox']#confirm");
    this.documentSubmitButton = page.locator("//button[contains(text(),'Submit') and not(@disabled)]");
    this.documentHistoryTable = page.locator("table#documentHistory, table[class*='history']");

    this.addClaimButton = page.locator("//button[contains(text(),'Add a claim') or contains(text(),'Link a claim')]");
    this.claimNumberInput = page.locator("input#claimNumber, input[name='claimNumber']");
    this.dobDayInput = page.locator("input#dobDay, input[name='dobDay']");
    this.dobMonthSelect = page.locator("select#dobMonth, select[name='dobMonth']");
    this.dobYearInput = page.locator("input#dobYear, input[name='dobYear']");
    this.confirmAddClaimButton = page.locator("//button[contains(text(),'Confirm') or contains(text(),'Submit')]");
  }

  async navigateToTab(tabName: string): Promise<void> {
    switch (tabName.toLowerCase()) {
      case 'overview':
        await this.claimOverviewTab.first().click();
        break;
      case 'benefit payments':
        await this.benefitPaymentsTab.first().click();
        break;
      case 'healthcare benefits':
        await this.healthCareBenefitTab.first().click();
        break;
      case 'non healthcare benefits':
        await this.nonHealthCareBenefitTab.first().click();
        break;
      case 'appeals':
        await this.appealsTab.first().click();
        break;
      default:
        await this.page.locator(`//a[contains(text(),'${tabName}')]`).first().click();
    }
  }

  async getAppealsCount(): Promise<number> {
    await this.appealsTab.first().waitFor({ state: 'visible' });
    const countText = await this.appealsCountBadge.first().textContent();
    return countText ? parseInt(countText.trim(), 10) : 0;
  }

  async sendMessage(subject: string, message: string): Promise<void> {
    await this.sendUsAMessageLink.first().click();
    await this.messageSubjectDropdown.first().selectOption({ label: subject });
    await this.messageBodyTextarea.first().fill(message);
    await this.sendMessageButton.first().click();
    await expect(this.messageSentConfirmation.first()).toBeVisible({ timeout: 15000 });
  }

  async uploadSingleDocument(fileName: string, formType: string, isWSIB: boolean = true): Promise<void> {
    await this.submitDocumentLink.first().click();
    const filePath = path.resolve(process.cwd(), 'DocUploadFiles', fileName);
    await this.fileUploadInput.first().setInputFiles(filePath);

    if (isWSIB) {
      await this.wsibFormDropdown.first().selectOption({ label: formType });
    } else {
      await this.nonWsibCategoryDropdown.first().selectOption({ label: formType });
    }

    await this.confirmationCheckbox.first().check();
    await this.documentSubmitButton.first().click();
  }

  async verifyDocumentHistory(expectedForm: string): Promise<void> {
    await this.documentHistoryTable.first().waitFor({ state: 'visible', timeout: 30000 });
    const row = this.documentHistoryTable.locator(`//tr[contains(.,'${expectedForm}')]`);
    await expect(row.first()).toBeVisible({ timeout: 20000 });
  }

  async addClaim(claimNumber: string, dobString: string): Promise<void> {
    await this.addClaimButton.first().click();
    await this.claimNumberInput.first().fill(claimNumber);

    const [day, month, year] = dobString.split('/');
    if (await this.dobDayInput.first().isVisible()) {
      await this.dobDayInput.first().fill(day);
      await this.dobMonthSelect.first().selectOption({ label: month });
      await this.dobYearInput.first().fill(year);
    }
    await this.confirmAddClaimButton.first().click();
  }
}