import { Page, Locator, expect } from '@playwright/test';
import { BasePage } from '../../utils/BasePage';

export class LoginPage extends BasePage {
    private readonly usernameTextField: Locator;
    private readonly passwordTextField: Locator;
    private readonly loginButton: Locator;
    private readonly mfaMethodPhone: Locator;
    private readonly mfaNextButton: Locator;
    private readonly mfaCallMeButton: Locator;
    private readonly mfaRememberMeTrue: Locator;
    private readonly mfaSubmitButton: Locator;

    constructor(page: Page) {
        super(page);
        this.usernameTextField = page.locator("//input[@id='email' or @id='signInName']");
        this.passwordTextField = page.locator("//input[@id='password']");
        this.loginButton = page.locator("//button[@id='next']");
        this.mfaMethodPhone = page.locator("(//input[contains(@id, 'extension_oaMfaMethod')])[2]");
        this.mfaNextButton = page.locator("//*[@id='continue']");
        this.mfaCallMeButton = page.locator("//*[@id='mfaPhoneMethod_phone']");
        this.mfaRememberMeTrue = page.locator("//*[@id='mfaRememberMe_true']");
        this.mfaSubmitButton = page.locator("//*[@id='continue']");
    }

    async navigateToURL(url: string) {
        await this.page.goto(url);
    }

    async loginToSite(username: string, password: string) {
        await this.usernameTextField.waitFor({ state: 'visible' });
        await this.enter(this.usernameTextField, username);
        await this.enter(this.passwordTextField, password);
        await this.click(this.loginButton);

        await this.sleep(3000);

        if (await this.mfaMethodPhone.isVisible()) {
            await this.click(this.mfaMethodPhone);
            await this.click(this.mfaNextButton);
            await this.click(this.mfaCallMeButton);
            await this.click(this.mfaNextButton);
            await this.mfaRememberMeTrue.waitFor({ state: 'visible' });
            await this.click(this.mfaRememberMeTrue);
            await this.click(this.mfaSubmitButton);
        } else {
            console.log(" MFA is not enabled...");
        }
    }

    async verifyOnLoginPage(): Promise<boolean> {
        await this.usernameTextField.waitFor({ state: 'visible' });
        return await this.usernameTextField.isVisible();
    }
}
