// pages/OSPC/Tombstone.ts
import { Page, Locator, expect } from '@playwright/test';
import { BasePage } from '../../utils/BasePage';

export class Tombstone extends BasePage {
  readonly personalDetailsHeader: Locator;
  readonly mailingAddressHeader: Locator;
  readonly contactDetailsHeader: Locator;
  readonly editMailingAddressButton: Locator;
  readonly editPhoneNumberButton: Locator;
  readonly addressLine1Input: Locator;
  readonly cityInput: Locator;
  readonly provinceDropdown: Locator;
  readonly postalCodeInput: Locator;
  readonly phoneNumberInput: Locator;
  readonly saveButton: Locator;
  readonly successBanner: Locator;

  private static readonly provinceMap: Record<string, string> = {
    'AB': 'Alberta',
    'BC': 'British Columbia',
    'MB': 'Manitoba',
    'NB': 'New Brunswick',
    'NL': 'Newfoundland and Labrador',
    'NT': 'Northwest Territories',
    'NS': 'Nova Scotia',
    'NU': 'Nunavut',
    'ON': 'Ontario',
    'PE': 'Prince Edward Island',
    'QC': 'Quebec',
    'SK': 'Saskatchewan',
    'YT': 'Yukon'
  };

  constructor(page: Page) {
    super(page);
    this.personalDetailsHeader = page.locator("//h2[contains(text(),'Personal details')] | //h3[contains(text(),'Personal details')]");
    this.mailingAddressHeader = page.locator("//h2[contains(text(),'Mailing address')] | //h3[contains(text(),'Mailing address')]");
    this.contactDetailsHeader = page.locator("//h2[contains(text(),'Contact details')] | //h3[contains(text(),'Contact details')]");
    this.editMailingAddressButton = page.locator("//button[contains(@aria-label,'Edit Mailing address') or contains(.,'Edit')][1]");
    this.editPhoneNumberButton = page.locator("//button[contains(@aria-label,'Edit Phone number') or contains(.,'Edit Phone')]");
    this.addressLine1Input = page.locator("input[name='addressLine1'], #addressLine1, input[id*='address']");
    this.cityInput = page.locator("input[name='city'], #city");
    this.provinceDropdown = page.locator("select[name='province'], #province, select[id*='province']");
    this.postalCodeInput = page.locator("input[name='postalCode'], #postalCode, input[id*='postal']");
    this.phoneNumberInput = page.locator("input[name='phoneNumber'], #phoneNumber, input[type='tel']");
    this.saveButton = page.locator("//button[contains(text(),'Save') or contains(@id,'save')]");
    this.successBanner = page.locator("//div[contains(@class,'alert-success') or contains(@class,'success') or contains(text(),'updated successfully')]");
  }

  async verifyTombstoneSections(): Promise<void> {
    await expect(this.personalDetailsHeader.first()).toBeVisible({ timeout: 15000 });
    await expect(this.mailingAddressHeader.first()).toBeVisible();
    await expect(this.contactDetailsHeader.first()).toBeVisible();
  }

  async clickEditMailingAddress(): Promise<void> {
    await this.editMailingAddressButton.first().click();
  }

  async clickEditPhoneNumber(): Promise<void> {
    await this.editPhoneNumberButton.first().click();
  }

  async updateMailingAddress(addressLine1: string, city: string, province: string, postalCode: string): Promise<void> {
    await this.addressLine1Input.first().fill(addressLine1);
    await this.cityInput.first().fill(city);

    const fullProvince = Tombstone.provinceMap[province.toUpperCase()] || province;
    try {
      await this.provinceDropdown.first().selectOption({ label: fullProvince });
    } catch {
      await this.provinceDropdown.first().selectOption({ value: province });
    }

    await this.postalCodeInput.first().fill(postalCode);
    await this.saveButton.first().click();
  }

  async updatePhoneNumber(newPhone: string): Promise<void> {
    await this.phoneNumberInput.first().fill(newPhone);
    await this.saveButton.first().click();
  }

  async verifySaveSuccess(): Promise<void> {
    await expect(this.successBanner.first()).toBeVisible({ timeout: 15000 });
  }
}