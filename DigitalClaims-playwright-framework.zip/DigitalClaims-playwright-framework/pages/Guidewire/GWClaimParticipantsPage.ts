import { Page, Locator, expect } from '@playwright/test';
import { BasePage } from '../../utils/BasePage';

export class GWClaimParticipantsPage extends BasePage {
    private readonly ClaimParticipantsLink: Locator;
    private readonly ClaimParticipantsTable: Locator;
    private readonly addressLine1: Locator;
    private readonly addressLine2: Locator;
    private readonly addressLine3: Locator;
    private readonly CopyfromContactManagerButton: Locator;
    private readonly TransitNumber: Locator;
    private readonly BankNumber: Locator;
    private readonly DDReason: Locator;
    private readonly WorkerFirstName: Locator;
    private readonly WorkerLastName: Locator;
    private readonly WorkerWCBID: Locator;
    private readonly PrimaryPhoneNumber: Locator;
    private readonly MessagingLink: Locator;
    private readonly MessagingBody: Locator;

    constructor(page: Page) {
        super(page);
        this.ClaimParticipantsLink = this.page.locator('#Claim\\:MenuLinks\\:Claim_ClaimPartiesGroup');
        this.ClaimParticipantsTable = this.page.locator('#ClaimContacts\\:ClaimContactsScreen\\:PeopleInvolvedDetailedListDetail\\:PeopleInvolvedDetailedLV');
        this.addressLine1 = this.page.locator('#ClaimContacts\\:ClaimContactsScreen\\:PeopleInvolvedDetailedListDetail\\:ContactBasicsDV\\:WSIB_MailingAddressInputSet\\:FNOLAddressInputSet\\:WSIB_AddressSummaryInputSet\\:addressLine1');
        this.addressLine2 = this.page.locator('#ClaimContacts\\:ClaimContactsScreen\\:PeopleInvolvedDetailedListDetail\\:ContactBasicsDV\\:WSIB_MailingAddressInputSet\\:FNOLAddressInputSet\\:WSIB_AddressSummaryInputSet\\:addressLine2');
        this.addressLine3 = this.page.locator('#ClaimContacts\\:ClaimContactsScreen\\:PeopleInvolvedDetailedListDetail\\:ContactBasicsDV\\:WSIB_MailingAddressInputSet\\:FNOLAddressInputSet\\:WSIB_AddressSummaryInputSet\\:addressLine3');
        this.CopyfromContactManagerButton = this.page.locator('#ClaimContacts\\:ClaimContactsScreen\\:PeopleInvolvedDetailedListDetail\\:ContactBasicsDV_tb\\:ContactDetailToolbarButtonSet\\:LinkContactToolbarButtonSet\\:LinkContactToolbarButtons_SyncFromAddressBookButton');
        this.TransitNumber = this.page.locator('xpath=//*[@id="ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:ContactEFTLV:0:0"]/td[2]');
        this.BankNumber = this.page.locator('xpath=//*[@id="ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:ContactEFTLV:0:BankNumber"]');
        this.DDReason = this.page.locator('xpath=//*[@id="ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:ContactBasicsDV:ContactEFTLV:0:Reason"]');
        this.WorkerFirstName = this.page.locator('#ClaimContacts\\:ClaimContactsScreen\\:PeopleInvolvedDetailedListDetail\\:ContactBasicsDV\\:PersonNameInputSet\\:FirstName');
        this.WorkerLastName = this.page.locator('#ClaimContacts\\:ClaimContactsScreen\\:PeopleInvolvedDetailedListDetail\\:ContactBasicsDV\\:PersonNameInputSet\\:LastName');
        this.WorkerWCBID = this.page.locator('#ClaimContacts\\:ClaimContactsScreen\\:PeopleInvolvedDetailedListDetail\\:ContactBasicsDV\\:PersonNameInputSet\\:WCBID');
        this.PrimaryPhoneNumber = this.page.locator('#ClaimContacts\\:ClaimContactsScreen\\:PeopleInvolvedDetailedListDetail\\:ContactBasicsDV\\:PersonContactInfoInputSet\\:PrimaryPhone');
        this.MessagingLink = this.page.locator('#Claim\\:MenuLinks\\:Claim_WSIB_MessagingGroup');
        this.MessagingBody = this.page.locator('#WSIB_ClaimCustomerMessages\\:WSIB_MessagingScreen\\:WSIB_MessagePanelSet\\:0\\:MessageBody');
    }

    async removeDirectDeposit(): Promise<boolean> {
        await this.click(this.ClaimParticipantsLink);
        const rows = this.ClaimParticipantsTable.locator('tr');
        const rowCount = await rows.count();
        for (let i = 0; i < rowCount; i++) {
            const row = rows.nth(i);
            if ((await row.innerText()).includes('Worker')) {
                const role = row.locator('span[value="Worker"]');
                await this.click(role);
                break;
            }
        }
        await this.click(this.CopyfromContactManagerButton);
        return true;
    }

    async addDirectDeposit(): Promise<boolean> {
        await this.click(this.ClaimParticipantsLink);
        const rows = this.ClaimParticipantsTable.locator('tr');
        const rowCount = await rows.count();
        for (let i = 0; i < rowCount; i++) {
            const row = rows.nth(i);
            if ((await row.innerText()).includes('Worker')) {
                const role = row.locator('span[value="Worker"]');
                await this.click(role);
                break;
            }
        }

        if ((await this.TransitNumber.innerText()) === '01001' && (await this.BankNumber.innerText()) === '0010' && (await this.DDReason.innerText()) === 'Update from OSPC') {
            return true;
        } else {
            return false;
        }
    }

    async verifyUpdatedMailingAddress(addressLine1: string, addressLine2: string, addressLine3: string): Promise<boolean> {
        await this.click(this.ClaimParticipantsLink);
        const rows = this.ClaimParticipantsTable.locator('tr');
        const rowCount = await rows.count();
        for (let i = 0; i < rowCount; i++) {
            const row = rows.nth(i);
            if ((await row.innerText()).includes('Worker')) {
                const role = row.locator('span[value="Worker"]');
                await this.click(role);
                break;
            }
        }

        if ((await this.addressLine1.isVisible()) && (await this.addressLine1.innerText()).toLowerCase() === addressLine1.toLowerCase() &&
            (await this.addressLine2.isVisible()) && (await this.addressLine2.innerText()).toLowerCase() === addressLine2.toLowerCase() &&
            (await this.addressLine3.isVisible()) && (await this.addressLine3.innerText()).toLowerCase() === addressLine3.toLowerCase()) {

            console.log(`Verified updated mailing address for ${await this.WorkerFirstName.innerText()} ${await this.WorkerLastName.innerText()}`);
            return true;
        }
        return false;
    }

    async verifyUpdatedPhoneNumber(phonenumber: string): Promise<boolean> {
        await this.click(this.ClaimParticipantsLink);
        const rows = this.ClaimParticipantsTable.locator('tr');
        const rowCount = await rows.count();
        for (let i = 0; i < rowCount; i++) {
            const row = rows.nth(i);
            if ((await row.innerText()).includes('Worker')) {
                const role = row.locator('span[value="Worker"]');
                await this.click(role);
                break;
            }
        }

        if ((await this.PrimaryPhoneNumber.isVisible()) && (await this.PrimaryPhoneNumber.innerText()).toLowerCase() === phonenumber.toLowerCase()) {
            console.log(`Verified updated phone number for ${await this.WorkerFirstName.innerText()} ${await this.WorkerLastName.innerText()}`);
            return true;
        }
        return false;
    }

    async verifySentMessage(randommessage: string): Promise<boolean> {
        await this.click(this.MessagingLink);
        return (await this.MessagingBody.innerText()) === randommessage;
    }
}
