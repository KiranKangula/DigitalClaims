import { Page, Locator, expect } from '@playwright/test';
import { BasePage } from '../../utils/BasePage';

export class GWSearchPage extends BasePage {
    private readonly SearchTab: Locator;
    private readonly DesktopActivities: Locator;
    private readonly ClaimSearchField: Locator;
    private readonly SearchButton: Locator;
    private readonly SelectClaimfromSearch: Locator;
    private readonly SummaryTitlebar: Locator;
    private readonly ClaimRegistrationTitlebar: Locator;
    private readonly SearchFirstName: Locator;
    private readonly SearchLastName: Locator;
    private readonly SearchDOB: Locator;
    private readonly OriginatingChannel: Locator;
    private readonly NIHLClaimResultLinks: Locator;
    private readonly NIHLUnnumberedDocumentsLink: Locator;

    constructor(page: Page) {
        super(page);
        this.SearchTab = page.locator('#TabBar\\:SearchTab');
        this.DesktopActivities = page.locator('#DesktopActivities');
        this.ClaimSearchField = page.locator('#ClaimSearch\\:ClaimSearchScreen\\:ClaimSearchDV\\:ClaimSearchOptionalInputSet\\:ClaimNumber');
        this.SearchButton = page.locator('#ClaimSearch\\:ClaimSearchScreen\\:ClaimSearchDV\\:ClaimSearchAndResetInputSet\\:Search_link');
        this.SelectClaimfromSearch = page.locator("//div[contains(@id, 'ResultsLV:0:ClaimNumber')] | //a[contains(@id, 'ResultsLV:0:ClaimNumber')] | //div[contains(@id, 'ClaimSearch')]//table//tr[1]//td[contains(@class, 'gw-action')]");
        this.SummaryTitlebar = page.locator('#ClaimSummary\\:ClaimSummaryScreen\\:ttlBar');
        this.ClaimRegistrationTitlebar = page.locator('#WSIB_Form8_FNOLWizard\\:WorkersCompWizardStepSet\\:WSIB_ClaimRegistrationScreen\\:ttlBar');
        this.SearchFirstName = page.locator('#ClaimSearch\\:ClaimSearchScreen\\:ClaimSearchDV\\:ClaimSearchOptionalInputSet\\:FirstName');
        this.SearchLastName = page.locator('#ClaimSearch\\:ClaimSearchScreen\\:ClaimSearchDV\\:ClaimSearchOptionalInputSet\\:LastName');
        this.SearchDOB = page.locator('#ClaimSearch\\:ClaimSearchScreen\\:ClaimSearchDV\\:ClaimSearchOptionalInputSet\\:DateOfBirth');
        this.OriginatingChannel = page.locator('#Claim\\:ClaimInfoBar\\:originatingChannel_link');
        this.NIHLClaimResultLinks = page.locator("//table[contains(@id, 'ClaimSearch') and contains(@id, 'ResultsLV')]//a[substring(@id, string-length(@id) - string-length(':ClaimNumber') + 1) = ':ClaimNumber']");
        this.NIHLUnnumberedDocumentsLink = page.locator('#WSIB_Form8_FNOLWizard\\:Documents');
    }

    async searchClaim(claimnumber: string): Promise<boolean> {
        await this.click(this.SearchTab);
        await this.enter(this.ClaimSearchField, claimnumber);
        await this.click(this.SearchButton);
        await this.click(this.SelectClaimfromSearch);
        return await this.SummaryTitlebar.isVisible();
    }

    async searchReference(referenceNumber: string): Promise<boolean> {
        await this.click(this.SearchTab);
        await this.enter(this.ClaimSearchField, referenceNumber);
        await this.click(this.SearchButton);
        await this.click(this.SelectClaimfromSearch);
        return await this.ClaimRegistrationTitlebar.isVisible();
    }

    async GWCCLoginsuccess(): Promise<boolean> {
        await this.DesktopActivities.waitFor({ state: 'visible' });
        return await this.DesktopActivities.isVisible();
    }

    async searchClaimant(firstname: string, lastname: string, dateofbirth: string, docUploadVerification: string = 'No'): Promise<boolean> {
        if (!firstname?.trim() || !lastname?.trim() || !dateofbirth?.trim()) {
            throw new Error('First name, last name, and date of birth are required.');
        }

        const extendedVerification = 'Yes'.equalsIgnoreCase(docUploadVerification);
        const maxAttempts = extendedVerification ? 50 : 2;
        const resultTimeout = 5000;
        const startedAt = Date.now();

        // Date conversion - simplified as Playwright handles input better
        const formattedDob = dateofbirth;

        console.log(`[GWCC SEARCH] Starting claimant search. Maximum attempts: ${maxAttempts}; result wait per attempt: ${resultTimeout / 1000} seconds.`);
        console.log('[GWCC SEARCH] Opening Search and entering criteria.');

        await this.click(this.SearchTab);
        await this.enter(this.SearchFirstName, firstname.trim());
        await this.enter(this.SearchLastName, lastname.trim());
        await this.enter(this.SearchDOB, formattedDob.trim());

        for (let attempt = 1; attempt <= maxAttempts; attempt++) {
            console.log(`[GWCC SEARCH] Attempt ${attempt}/${maxAttempts}: submitting search.`);
            await this.click(this.SearchButton);

            try {
                await this.SelectClaimfromSearch.waitFor({ state: 'visible', timeout: resultTimeout });
                if (await this.SelectClaimfromSearch.isEnabled()) {
                    const claimNumber = await this.SelectClaimfromSearch.innerText();
                    if (claimNumber.trim()) {
                        await this.SelectClaimfromSearch.click();
                        const elapsedSeconds = Math.floor((Date.now() - startedAt) / 1000);
                        console.log(`[GWCC SEARCH] SUCCESS: clicked claim ${claimNumber} on attempt ${attempt}/${maxAttempts}. Total elapsed: ${elapsedSeconds} seconds.`);
                        return true;
                    }
                }
            } catch (e) {
                console.log(`[GWCC SEARCH] Attempt ${attempt}/${maxAttempts}: no usable claim result could be clicked within ${resultTimeout / 1000} seconds.`);
                if (attempt < maxAttempts) {
                    console.log('[GWCC SEARCH] Retrying: submitting the search again.');
                }
            }
        }

        const elapsedSeconds = Math.floor((Date.now() - startedAt) / 1000);
        console.log(`[GWCC SEARCH] FAILED: no claim result was successfully clicked after ${maxAttempts} attempts. Total elapsed: ${elapsedSeconds} seconds.`);
        return false;
    }

    async searchDIClaim(firstname: string, lastname: string, dateofbirth: string, currentRowData?: any, writeJsonCallback?: (data: any) => void): Promise<boolean> {
        console.log(`Searching DI Claim: ${firstname} ${lastname}, DOB: ${dateofbirth}`);
        await this.click(this.SearchTab);
        await this.enter(this.SearchFirstName, firstname);
        await this.enter(this.SearchLastName, lastname);
        await this.page.locator('#ClaimSearch\\:ClaimSearchScreen\\:ClaimSearchDV\\:ClaimSearchOptionalInputSet\\:DateOfBirth').fill(dateofbirth);

        for (let loop = 0; loop < 50; loop++) {
            await this.click(this.SearchButton);
            await this.sleep(2000);
            if (await this.SelectClaimfromSearch.isVisible()) {
                const text = await this.SelectClaimfromSearch.innerText();
                if (text.charAt(0) === '3') {
                    console.log(`Claim found in GWCC: ${text}`);
                    if (currentRowData) {
                        currentRowData['Claim Number'] = text;
                        if (writeJsonCallback) writeJsonCallback(currentRowData);
                    }
                    await this.click(this.SelectClaimfromSearch);
                    break;
                } else {
                    console.log(`Waiting for Auto Registration to Complete... current value: ${text}`);
                }
            } else {
                console.log(`Search Results not available Yet, trying again... Attempt: ${loop}`);
                await this.sleep(5000);
                await this.click(this.SearchTab);
            }
        }
        await this.OriginatingChannel.waitFor({ state: 'visible' });
        return await this.OriginatingChannel.isVisible();
    }

    async searchNIHLClaimant(firstName: string, lastName: string, dob: string, timeoutSeconds: number, pollSeconds: number, currentRowData?: any): Promise<boolean> {
        if (!firstName?.trim() || !lastName?.trim() || !dob?.trim()) {
            throw new Error('NIHL claimant name and DOB are required.');
        }
        if (timeoutSeconds <= 0 || pollSeconds <= 0) {
            throw new Error('NIHL timeout and poll seconds must be positive.');
        }

        if (currentRowData) {
            delete currentRowData['NIHLGWCCReference'];
        }

        const expectedName = this.nihlSearchText(`${firstName} ${lastName}`);
        // dob format: dd/MM/uuuu
        const expectedDob = new Date(dob.trim());

        const started = Date.now();
        const budget = timeoutSeconds * 1000;
        let attempt = 0;

        while (Date.now() - started < budget) {
            attempt++;
            const elapsed = Math.floor((Date.now() - started) / 1000);
            console.log(`[NIHL GWCC SEARCH] Attempt ${attempt}; elapsed=${elapsed}s; budget=${timeoutSeconds}s.`);

            await this.click(this.SearchTab);
            await this.ClaimSearchField.fill('');
            await this.enter(this.SearchFirstName, firstName.trim());
            await this.enter(this.SearchLastName, lastName.trim());
            await this.SearchDOB.fill(dob.trim());
            await this.click(this.SearchButton);

            const remaining = budget - (Date.now() - started);
            if (remaining <= 0) break;

            try {
                const selected = await this.findMatchingNIHLClaim(expectedName, expectedDob, Math.min(remaining, 5000));
                if (selected) {
                    const reference = await selected.innerText();
                    await selected.click();

                    const remainingAfterClick = budget - (Date.now() - started);
                    if (remainingAfterClick <= 0) return false;

                    await this.NIHLUnnumberedDocumentsLink.waitFor({ state: 'visible', timeout: Math.min(remainingAfterClick, 15000) });

                    if (currentRowData) {
                        currentRowData['NIHLGWCCReference'] = reference.trim();
                    }
                    console.log(`[NIHL GWCC SEARCH] SUCCESS: matched identity and opened UNCD reference ${reference}. Elapsed=${Math.floor((Date.now() - started) / 1000)}s.`);
                    return true;
                }
            } catch (e) {
                console.log('[NIHL GWCC SEARCH] Matching claimant is not visible yet.');
                await this.nihlSearchPause(started, budget, pollSeconds);
            }
        }

        console.log('[NIHL GWCC SEARCH] TIMEOUT: matching NIHL claimant was not opened.');
        return false;
    }

    private async findMatchingNIHLClaim(expectedName: string, expectedDob: Date, timeout: number): Promise<Locator | null> {
        const links = await this.NIHLClaimResultLinks.all();
        for (const link of links) {
            if (!(await link.isVisible()) || !(await link.isEnabled())) continue;

            const row = this.page.locator('tr', { has: link });
            const actualName = await row.locator('span[id$=":Claimant"]').innerText();
            const actualDobText = await row.locator('span[id$=":WorkerDateOfBirth"]').innerText();

            // Date parsing dd/MMM/uuuu (e.g. 28/Oct/2026)
            const actualDob = new Date(actualDobText.trim());

            if (expectedName === this.nihlSearchText(actualName) &&
                expectedDob.getTime() === actualDob.getTime() &&
                (await link.innerText()).trim() !== '') {
                return link;
            }
        }
        return null;
    }

    private nihlSearchText(text: string): string {
        return text.replace(/ /g, ' ').trim().replace(/\s+/g, ' ').toLowerCase();
    }

    private async nihlSearchPause(started: number, budget: number, pollSeconds: number): Promise<void> {
        const remaining = budget - (Date.now() - started);
        if (remaining > 0) {
            const delay = Math.min(pollSeconds * 1000, remaining);
            await this.sleep(Math.floor(delay));
        }
    }
}
