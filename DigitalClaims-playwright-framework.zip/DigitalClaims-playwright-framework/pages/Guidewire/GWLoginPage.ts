import { Page, Locator } from '@playwright/test';
import { BasePage } from '../../utils/BasePage';

export class GWLoginPage extends BasePage {
    private readonly usernameTextField: Locator;
    private readonly passwordTextField: Locator;
    private readonly loginButton: Locator;
    private readonly GWCCLogout: Locator;

    constructor(page: Page) {
        super(page);
        this.usernameTextField = page.locator('#Login\\:LoginScreen\\:LoginDV\\:username');
        this.passwordTextField = page.locator('#Login\\:LoginScreen\\:LoginDV\\:password');
        this.loginButton = page.locator('#Login\\:LoginScreen\\:LoginDV\\:submit');
        this.GWCCLogout = page.locator('#TabBar\\:LogoutTabBarLink');
    }

    async loginToGWCC(username: string, password: string): Promise<void> {
        await this.page.frameLocator('frame[name="top_frame"]').locator('body').waitFor();
        const frame = this.page.frame('top_frame');
        if (!frame) {
            throw new Error('top_frame not found');
        }

        // Using frame locator for elements inside top_frame
        const frameUsername = frame.locator('#Login\\:LoginScreen\\:LoginDV\\:username');
        const framePassword = frame.locator('#Login\\:LoginScreen\\:LoginDV\\:password');
        const frameLoginButton = frame.locator('#Login\\:LoginScreen\\:LoginDV\\:submit');

        if (await frameUsername.isVisible()) {
            await frameUsername.waitFor({ state: 'visible' });
            await this.enter(frameUsername, username);
            await this.enter(framePassword, password);
            await this.click(frameLoginButton);
        } else {
            console.log('User has already logged in, login page is not displayed');
        }
    }

    async GWCClogout(): Promise<void> {
        await this.click(this.GWCCLogout);
    }

    async verifyonGWCC(): Promise<boolean> {
        const frame = this.page.frame('top_frame');
        if (!frame) return false;

        const frameUsername = frame.locator('#Login\\:LoginScreen\\:LoginDV\\:username');
        return await frameUsername.isVisible();
    }

    async switchtab(gwUrl: string): Promise<string[]> {
        const pages = await this.page.context().pages();
        const newPage = await this.page.context().newPage();
        await newPage.goto(gwUrl);
        return pages.map(p => p.url());
    }
}
