import { Page, Locator, expect } from '@playwright/test';
import { BasePage } from '../../utils/BasePage';

export class GWAdminPage extends BasePage {
    private readonly AdminTab: Locator;
    private readonly PortalAuthorizationLink: Locator;
    private readonly SearchClaimNumberUserInput: Locator;
    private readonly SearchUsersUserNameInput: Locator;
    private readonly CheckboxAll: Locator;
    private readonly SearchPortalAuth: Locator;
    private readonly EmailProfileLink: Locator;
    private readonly EditButton: Locator;
    private readonly PortalAuthTable: Locator;
    private readonly PortalAuthDeleteButton: Locator;
    private readonly PortalAuthOKButton: Locator;
    private readonly PortalAuthAdminScreen: Locator;

    constructor(page: Page) {
        super(page);
        this.AdminTab = this.page.locator('#TabBar\\:AdminTab');
        this.PortalAuthorizationLink = this.page.locator('#Admin\\:MenuLinks\\:Admin_PortalAuthorizationAdminPage');
        this.SearchClaimNumberUserInput = this.page.locator('#PortalAuthorizationAdminPage\\:PortalAuthAdminScreen\\:PortalUserSearchFieldsDV\\:SearchClaimNumberUserInput');
        this.SearchUsersUserNameInput = this.page.locator('#PortalAuthorizationAdminPage\\:PortalAuthAdminScreen\\:PortalUserSearchFieldsDV\\:SearchUsersUserNameInput');
        this.CheckboxAll = this.page.locator('#PortalAuthUserDetailPopup\\:PortalAuthUserGrantedAuthoritiesLV\\:_Checkbox');
        this.SearchPortalAuth = this.page.locator('xpath=//*[@id="PortalAuthorizationAdminPage:PortalAuthAdminScreen:PortalAuthUsersLV_tb:ToolbarButton"]/span[2]');
        this.EmailProfileLink = this.page.locator('xpath=//table[@id="PortalAuthorizationAdminPage:PortalAuthAdminScreen:PortalAuthUsersLV"]//tbody//tr[contains(@id, "PortalAuthUsersLV:") and contains(@id, ":") and .//input[@type="checkbox"]]//a[contains(@id, "UserNameCell") and not(contains(@id, "Header"))]');
        this.EditButton = this.page.locator('#PortalAuthUserDetailPopup\\:PortalAuthUserDV_tb\\:Edit');
        this.PortalAuthTable = this.page.locator('#PortalAuthUserDetailPopup\\:PortalAuthUserGrantedAuthoritiesLV');
        this.PortalAuthDeleteButton = this.page.locator('#PortalAuthUserDetailPopup\\:PortalAuthUserGrantedAuthoritiesLV_tb\\:deleteAuthoritiesButton');
        this.PortalAuthOKButton = this.page.locator('#PortalAuthUserDetailPopup\\:PortalAuthUserDV_tb\\:Update');
        this.PortalAuthAdminScreen = this.page.locator('#PortalAuthorizationAdminPage\\:PortalAuthAdminScreen\\:0');
    }

    async navigatePortalAuthScreen(): Promise<boolean> {
        await this.click(this.AdminTab);
        await this.click(this.PortalAuthorizationLink);
        await this.SearchClaimNumberUserInput.waitFor({ state: 'visible' });
        return await this.SearchClaimNumberUserInput.isVisible();
    }

    async removeClaimfromPortalAuth(claimnumber: string): Promise<boolean> {
        await this.enter(this.SearchClaimNumberUserInput, claimnumber);
        await this.click(this.SearchPortalAuth);
        await this.click(this.EmailProfileLink);
        await this.click(this.EditButton);

        const rows = this.PortalAuthTable.locator('tr');
        const rowCount = await rows.count();
        for (let i = 0; i < rowCount; i++) {
            const row = rows.nth(i);
            const cells = row.locator('td');
            const cellCount = await cells.count();
            for (let j = 0; j < cellCount; j++) {
                if (await cells.nth(j).innerText() === claimnumber) {
                    const checkbox = row.locator('input[type="checkbox"]');
                    await this.click(checkbox);
                    break;
                }
            }
        }
        await this.click(this.PortalAuthDeleteButton);
        await this.click(this.PortalAuthOKButton);
        await this.PortalAuthAdminScreen.waitFor({ state: 'visible' });
        return await this.PortalAuthAdminScreen.isVisible();
    }

    async removeAllClaimfromPortalAuth(username: string): Promise<boolean> {
        await this.enter(this.SearchUsersUserNameInput, username);
        await this.click(this.SearchPortalAuth);
        await this.click(this.EmailProfileLink);
        await this.click(this.EditButton);
        if (await this.CheckboxAll.isVisible()) {
            await this.click(this.CheckboxAll);
            await this.click(this.PortalAuthDeleteButton);
        }
        await this.click(this.PortalAuthOKButton);
        await this.PortalAuthAdminScreen.waitFor({ state: 'visible' });
        return await this.PortalAuthAdminScreen.isVisible();
    }
}
