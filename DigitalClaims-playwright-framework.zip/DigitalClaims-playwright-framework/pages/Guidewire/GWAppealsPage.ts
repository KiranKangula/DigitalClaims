import { Page, Locator, expect } from '@playwright/test';
import { BasePage } from '../../utils/BasePage';

export class GWAppealsPage extends BasePage {
    private readonly AppealsLink: Locator;
    private readonly NewMatterButton: Locator;
    private readonly Matter_Name: Locator;
    private readonly Appealtype: Locator;
    private readonly Objectingparty: Locator;
    private readonly AppealsUpdateButton: Locator;
    private readonly AppealsEditButton: Locator;
    private readonly AppealTab: Locator;
    private readonly WSIB_AppealTypeCase: Locator;
    private readonly WSIB_NewAppealType: Locator;
    private readonly language: Locator;
    private readonly CaseRefferal: Locator;
    private readonly otherparticipating: Locator;
    private readonly ObjOrigin: Locator;
    private readonly MatterDetailPage_update: Locator;
    private readonly CreateNumber: Locator;
    private readonly AppealNumber: Locator;
    private readonly BatchProcessInfoBar: Locator;
    private readonly ReturnToClaimCenter: Locator;

    constructor(page: Page) {
        super(page);
        this.AppealsLink = this.page.locator('#Claim\\:MenuLinks\\:Claim_ClaimMattersGroup');
        this.NewMatterButton = this.page.locator('#ClaimMatters\\:ClaimMatterScreen\\:ClaimMatters_NewMatterButton');
        this.Matter_Name = this.page.locator('#NewMatter\\:NewMatterScreen\\:NewMatterDV\\:Matter_Name');
        this.Appealtype = this.page.locator('#NewMatter\\:NewMatterScreen\\:NewMatterDV\\:Appealtype');
        this.Objectingparty = this.page.locator('#NewMatter\\:NewMatterScreen\\:NewMatterDV\\:Objectingparty');
        this.AppealsUpdateButton = this.page.locator('#NewMatter\\:NewMatterScreen\\:NewMatterDV_tb\\:Update');
        this.AppealsEditButton = this.page.locator('#MatterDetailPage\\:MatterDetailScreen\\:Edit');
        this.AppealTab = this.page.locator('#MatterDetailPage\\:MatterDetailScreen\\:OITandInitialDVTab');
        this.WSIB_AppealTypeCase = this.page.locator('#MatterDetailPage\\:MatterDetailScreen\\:WSIB_AppealTypeCase');
        this.WSIB_NewAppealType = this.page.locator('#MatterDetailPage\\:MatterDetailScreen\\:WSIB_NewAppealType');
        this.language = this.page.locator('#MatterDetailPage\\:MatterDetailScreen\\:language');
        this.CaseRefferal = this.page.locator('#MatterDetailPage\\:MatterDetailScreen\\:CaseRefferal');
        this.otherparticipating = this.page.locator('#MatterDetailPage\\:MatterDetailScreen\\:otherparticipating');
        this.ObjOrigin = this.page.locator('#MatterDetailPage\\:MatterDetailScreen\\:DualObj');
        this.MatterDetailPage_update = this.page.locator('#MatterDetailPage\\:MatterDetailScreen\\:Update');
        this.CreateNumber = this.page.locator('#MatterDetailPage\\:MatterDetailScreen\\:ToolbarButton_AppealRequest');
        this.AppealNumber = this.page.locator('#MatterDetailPage\\:MatterDetailScreen\\:Matter_Name');
        this.BatchProcessInfoBar = this.page.locator('#BatchProcessInfo\\:BatchProcessScreen\\:ttlBar');
        this.ReturnToClaimCenter = this.page.locator('#InternalToolsTabBar\\:ReturnTabBarLink');
    }

    async createAppeal(): Promise<boolean> {
        await this.click(this.AppealsLink);
        await this.click(this.NewMatterButton);
        await this.enter(this.Matter_Name, 'AppealTest');
        await this.Appealtype.selectOption({ label: 'Appeal' });
        await this.Objectingparty.selectOption({ index: 1 });
        await this.sleep(2000);
        await this.click(this.AppealsUpdateButton);
        await this.AppealsEditButton.waitFor({ state: 'visible' });
        await this.click(this.AppealsEditButton);
        await this.click(this.AppealTab);
        await this.WSIB_AppealTypeCase.selectOption({ label: 'Regular' });
        await this.sleep(2000);
        await this.WSIB_NewAppealType.selectOption({ label: 'Claims' });
        await this.sleep(2000);
        await this.language.selectOption({ label: 'English' });
        await this.sleep(2000);
        await this.CaseRefferal.selectOption({ label: 'OD' });
        await this.sleep(2000);
        await this.otherparticipating.selectOption({ label: 'No' });
        await this.sleep(2000);
        await this.ObjOrigin.selectOption({ label: 'Worker' });
        await this.sleep(2000);
        await this.click(this.CreateNumber);
        await this.AppealNumber.waitFor({ state: 'visible' });
        if ((await this.AppealNumber.innerText()).trim() !== '') {
            await this.click(this.MatterDetailPage_update);
            return true;
        }
        return false;
    }

    async runDIBatchJob(batchNameToRun: string): Promise<boolean> {
        // mimicAltShiftT is a custom method. I'll assume it's a shortcut.
        await this.page.keyboard.press('Alt+Shift+T');
        await this.BatchProcessInfoBar.waitFor({ state: 'visible' });

        const rows = this.page.locator('table[id="BatchProcessInfo:BatchProcessScreen:BatchProcessesLV"] tbody tr');
        const rowCount = await rows.count();
        let lastRunStatus: string | null = null;

        for (let i = 0; i < rowCount; i++) {
            const row = rows.nth(i);
            if (await row.innerText().includes(batchNameToRun)) {
                const runButton = row.locator('a[id*="RunBatchWithoutNotify"]');
                await this.click(runButton);
                await this.sleep(5000);

                for (let j = 0; j < 10; j++) {
                    try {
                        const updatedRow = this.page.locator(`table[id="BatchProcessInfo:BatchProcessScreen:BatchProcessesLV"] tbody tr:has-text("${batchNameToRun}")`);
                        const status = await updatedRow.locator('span[id*="LastRunStatus"]').innerText();
                        if (status.toLowerCase() === 'completed') {
                            lastRunStatus = 'Completed';
                            break;
                        }
                    } catch (e) {}
                    await this.sleep(5000);
                }
                break;
            }
        }

        if (lastRunStatus === 'Completed') {
            await this.click(this.ReturnToClaimCenter);
            return true;
        }
        return false;
    }
}
