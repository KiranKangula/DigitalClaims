// utils/JsonUtils.ts
import * as fs from 'fs';
import * as path from 'path';

export class JsonUtils {
  private static getDataFilePath(sheetName: string): string {
    const env = process.env.ENV || 'SIT2';
    return path.resolve(process.cwd(), `data/${env}/${sheetName}.json`);
  }

  public static readJsonData(sheetName: string): Record<string, any>[] {
    const filePath = this.getDataFilePath(sheetName);
    if (!fs.existsSync(filePath)) {
      console.error(`ERROR: JSON data file not found at: ${filePath}`);
      return [];
    }
    try {
      const fileData = fs.readFileSync(filePath, 'utf-8');
      return JSON.parse(fileData);
    } catch (e) {
      console.error(`ERROR parsing JSON data at ${filePath}:`, e);
      return [];
    }
  }

  public static writeJsonData(sheetName: string, data: Record<string, any>[]): void {
    const filePath = this.getDataFilePath(sheetName);
    try {
      fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
    } catch (e) {
      console.error(`ERROR writing JSON data to ${filePath}:`, e);
    }
  }
}