import { Page } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
import { AxeResults, Result } from 'axe-core';

export class AccessibilityUtils {
  /**
   * Runs a full WCAG accessibility scan on the current page.
   * Equivalent to AxeBuilder().withTags(...).analyze(driver) in Java.
   *
   * @param page     active Playwright Page instance
   * @param pageName a label for reporting purposes
   * @returns AxeResults containing violations, passes, incomplete
   */
  public static async runAccessibilityScan(page: Page, pageName: string): Promise<AxeResults> {
    const axeResults: AxeResults = await new AxeBuilder({ page })
      .withTags(['wcag2a', 'wcag2aa', 'wcag21aa', 'wcag22aa', 'best-practice'])
      .analyze();

    console.log(`=== Accessibility Scan: ${pageName} ===`);
    console.log(`URL: ${axeResults.url}`);
    console.log(`WCAG Violations Found: ${axeResults.violations.length}`);

    return axeResults;
  }

  /**
   * Builds a human-readable summary of violations for reporting.
   * Matches the exact output format from AccessibilityUtils.java.
   */
  public static buildViolationSummary(results: AxeResults): string {
    const violations: Result[] = results.violations;

    if (!violations || violations.length === 0) {
      return `✅ No WCAG violations found on: ${results.url}`;
    }

    let sb = `❌ WCAG Violations on: ${results.url}\n\n`;

    for (const violation of violations) {
      sb += '--------------------------------------------------\n';
      sb += `Rule ID    : ${violation.id}\n`;
      sb += `Impact     : ${violation.impact ?? 'unknown'}\n`;
      sb += `Description: ${violation.description}\n`;
      sb += `Help URL   : ${violation.helpUrl}\n`;
      sb += 'Affected Nodes:\n';

      for (const node of violation.nodes) {
        sb += `  - HTML  : ${node.html}\n`;
        if (node.failureSummary) {
          node.failureSummary.split('\n').forEach((line) => {
            if (line.trim().length > 0) {
              sb += `    Issue : ${line.trim()}\n`;
            }
          });
        }
      }
      sb += '\n';
    }

    return sb;
  }

  /**
   * Returns true if there are any critical/serious violations.
   */
  public static hasCriticalViolations(results: AxeResults): boolean {
    return results.violations.some(
      (v) => v.impact === 'critical' || v.impact === 'serious'
    );
  }
}