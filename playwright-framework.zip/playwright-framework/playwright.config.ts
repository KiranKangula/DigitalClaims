import { defineConfig, devices } from '@playwright/test';
import dotenv from 'dotenv';
import path from 'path';
import { ConfigLoader } from './utils/ConfigLoader';

dotenv.config({ path: path.resolve(__dirname, 'config/.env') });

const config = ConfigLoader.getConfig();

export default defineConfig({
  testDir: './tests',
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: parseInt(process.env.RETRY_COUNT || config['test.retry.count'] || '2'),
  workers: process.env.PARALLEL === 'true' ? 4 : 1,
  reporter: 'html',
  use: {
    baseURL: config.baseUrl,
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
    headless: process.env.HEADLESS === 'true' || config.headless === 'true',
  },
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
  ],
});
