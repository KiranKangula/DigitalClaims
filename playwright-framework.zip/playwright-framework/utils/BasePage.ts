import { Page, Locator, expect } from '@playwright/test';
import fs from 'fs';
import path from 'path';

export class BasePage {
    protected page: Page;

    constructor(page: Page) {
        this.page = page;
    }

    async sleep(ms: number) {
        await this.page.waitForTimeout(ms);
    }

    async click(locator: Locator) {
        try {
            await locator.click({ timeout: 10000 });
        } catch (e) {
            console.log(`Standard click failed, trying JS click: ${e}`);
            await locator.evaluate(el => (el as HTMLElement).click());
        }
    }

    async enter(locator: Locator, value: string, isGooglePlaces: boolean = false) {
        await locator.fill(''); // Clear field
        await locator.fill(value);

        if (isGooglePlaces) {
            await this.sleep(500);
            await this.page.keyboard.press('ArrowDown');
            await this.page.keyboard.press('Enter');
        } else {
            await this.page.keyboard.press('Tab');
        }
    }

    async selectJutroDropdownOption(dropdownId: string, optionText: string) {
        const wrapperId = dropdownId.endsWith('-wrapper') ? dropdownId : `${dropdownId}-wrapper`;
        const dropdownControl = this.page.locator(`//*[@id='${wrapperId}' or @id='${dropdownId}']//div[contains(@class, 'jut__GenericSelectControl__control')]`);

        await dropdownControl.scrollIntoViewIfNeeded();
        await dropdownControl.click();

        const optionLocator = this.page.locator(`//div[contains(@class, 'jut__GenericSelectControl__menu') or contains(@class, 'jut__DropdownSelectField__menu')]//div[contains(@class, 'jut__GenericSelectControl__option') or @role='option'][normalize-space(.)='${optionText}']`);

        try {
            await optionLocator.click({ timeout: 5000 });
        } catch (e) {
            await this.page.locator(`//div[contains(@class, 'jut__GenericSelectControl__menu')]//*[normalize-space(text())='${optionText}']`).click();
        }
    }

    async datePicker(uniqueInputId: string, dateString: string) {
        // Date format expected: d/MMM/yyyy (e.g., 28/Oct/2026)
        const date = new Date(dateString);
        const year = date.getFullYear().toString();
        const monthValue = (date.getMonth()).toString(); // JS months are 0-11
        const day = date.getDate().toString();

        const inputField = this.page.locator(`#${uniqueInputId}`);
        const calendarIcon = inputField.locator('xpath=./ancestor::div[contains(@class, "wsib-date-picker_datePickerRow__2bX8k")]/div[@role="button"]');

        await calendarIcon.click();
        await this.page.waitForSelector('.react-datepicker-popper');

        await this.page.locator('.wsib-date-picker_yearSelect__1LIag').selectOption(year);
        await this.page.locator('.wsib-date-picker_monthSelect__3GLvO').selectOption(monthValue);

        // Construct the aria-label for the day
        // The Java code had a complex way of getting the day name.
        // In Playwright we can often just find the day by text or relative position.
        // Based on the Java logic: //div[@role='option' and contains(@aria-label, 'Choose ...')]

        // Better approach: find the cell that matches the day number and is not from a different month
        await this.page.locator(`div[role="option"]:has-text("${day}")`).first().click();
    }

    async uploadDocuments(filenames: string[]) {
        const timestamp = new Date().toISOString().replace(/[:.]/g, '').replace('T', '_').split('Z')[0];
        const uploadedFiles = [];
        const uploadDir = path.resolve('src/test/resources/DocUploadFiles');

        for (let i = 0; i < filenames.length; i++) {
            const originalFile = filenames[i];
            const ext = path.extname(originalFile);
            const base = path.basename(originalFile, ext);
            const newFilename = `${base}_${timestamp}_${i}${ext}`;
            const newPath = path.join(uploadDir, newFilename);

            fs.copyFileSync(path.join(uploadDir, originalFile), newPath);
            uploadedFiles.push(newPath);
        }

        const fileInput = this.page.locator("input[type='file']");
        await fileInput.evaluate(el => el.style.display = 'block');
        await fileInput.setInputFiles(uploadedFiles);

        return uploadedFiles.map(p => path.basename(p));
    }

    // Utility methods from BaseDriverClass
    static getProvinceAbbreviation(province: string): string {
        const provinces: Record<string, string> = {
            "alberta": "AB", "british columbia": "BC", "manitoba": "MB",
            "new brunswick": "NB", "newfoundland and labrador": "NL",
            "nova scotia": "NS", "ontario": "ON", "prince edward island": "PE",
            "quebec": "QC", "saskatchewan": "SK", "northwest territories": "NT",
            "nunavut": "NU", "yukon": "YT"
        };
        return provinces[province.toLowerCase()] || "";
    }

    static generateRandomText(length: number): string {
        const chars = 'abcdefghijklmnopqrstuvwxyz';
        let result = '';
        for (let i = 0; i < length; i++) {
            result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return result;
    }

    static generateRandomNumber(length: number): string {
        let result = '';
        for (let i = 0; i < length; i++) {
            result += Math.floor(Math.random() * 10).toString();
        }
        return result;
    }
}
