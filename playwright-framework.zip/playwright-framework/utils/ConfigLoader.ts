import fs from 'fs';
import path from 'path';
import dotenv from 'dotenv';

dotenv.config({ path: path.resolve(__dirname, '../config/.env') });

export interface Config {
    [key: string]: any;
}

export class ConfigLoader {
    private static commonConfig: Config = {};
    private static currentEnv: string = process.env.ENV || 'BAT';
    private static currentApp: string = process.env.APP || 'OSPC';

    static async load() {
        // 1. Load common config
        const commonPath = path.resolve(__dirname, '../config/common.json');
        if (fs.existsSync(commonPath)) {
            this.commonConfig = JSON.parse(fs.readFileSync(commonPath, 'utf8'));
        }

        return this.getConfig();
    }

    static getConfig(appOverride?: string): Config {
        const app = appOverride || this.currentApp;
        const env = this.currentEnv;
        const envConfigPath = path.resolve(__dirname, `../config/environments/${env}/${app}.json`);

        let envConfig: Config = {};
        if (fs.existsSync(envConfigPath)) {
            envConfig = JSON.parse(fs.readFileSync(envConfigPath, 'utf8'));
        }

        // Merge: Common < Environment/App < .env (Secrets)
        return {
            ...this.commonConfig,
            ...envConfig,
            // Override with .env if exists for security/flexibility
            baseUrl: process.env.BASE_URL || envConfig.baseUrl || this.commonConfig.baseUrl,
            username: process.env.OSPC_USERNAME || envConfig.OSPC_username || this.commonConfig.OSPC_username,
            password: process.env.OSPC_PASSWORD || envConfig.OSPC_Password || this.commonConfig.OSPC_Password,
        };
    }

    static getEnv(): string {
        return this.currentEnv;
    }
}
