import { And } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { CustomWorld } from '../../support/world';

And('Switch to New tab and Login to Contact Manager', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Switch to New tab and Login to Contact Manager')) return;

    await this.guidewirecm.switchTabCM();
    const env = process.env.ENV?.toUpperCase();
    if (env === 'BAT' || env === 'PPD') {
        const username = process.env.GWCM_Username || '';
        const password = process.env.GWCM_Password || '';
        await this.guidewirecm.loginToGWCM(username, password);
    }
});

And('Search for the Contact using {string} and {string}', async function (this: CustomWorld, firstnameParam: string, lastnameParam: string) {
    await this.initPages();
    if (!this.shouldRun('Search for the Contact ')) return;

    const firstname = this.currentRow['Firstname'];
    const lastname = this.currentRow['Lastname'];
    const wcbId = this.currentRow['WCB Id'];
    await this.guidewirecm.searchContactInGWCM(firstname, lastname, wcbId);
});

And('Verify the Mailing address is updated along with history events in Contact Manager', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Verify the Mailing address is updated along with history events in Contact Manager')) return;

    const address = this.currentRow['Address Line1'];
    const city = this.currentRow['City'];
    const postalCode = this.currentRow['Postal Code'];
    expect(await this.guidewirecm.verifyMailingAddressUpdateInGWCM(address, city, postalCode)).toBeTruthy();
});

And('Verify the Phone Number is updated along with history events in Contact Manager', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Verify the Phone Number is updated along with history events in Contact Manager')) return;

    const phonenumber = this.currentRow['Phone Number'];
    expect(await this.guidewirecm.verifyPhoneNumberUpdateInGWCM(phonenumber)).toBeTruthy();
});

And('Verify the Direct Deposit is displayed in ContactManager', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Verify the Direct Deposit is displayed in ContactManager')) return;

    const transitNumber = this.currentRow['TransitNumber'];
    const institutionNumber = this.currentRow['InstitutionNumber'];
    const accountNumber = this.currentRow['AccountNumber'];
    expect(await this.guidewirecm.verifyDDUpdateInGWCM(transitNumber, institutionNumber, accountNumber)).toBeTruthy();
});

And('Remove the Direct Deposit from the Contact', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Remove the Direct Deposit from the Contact')) return;

    const transitNumber = this.currentRow['TransitNumber'];
    const institutionNumber = this.currentRow['InstitutionNumber'];
    const accountNumber = this.currentRow['AccountNumber'];
    expect(await this.guidewirecm.verifyDDRemoveInGWCM(transitNumber, institutionNumber, accountNumber)).toBeTruthy();
});
