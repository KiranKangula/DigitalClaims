import { setWorldConstructor, World, IWorldOptions } from '@cucumber/cucumber';
import { Browser, BrowserContext, Page } from '@playwright/test';
import { LoginPage } from '../pages/OSPC/LoginPage';
import { HomePage } from '../pages/OSPC/HomePage';
import { GetStarted } from '../pages/UNCD/GetStarted';
import { GWLoginPage } from '../pages/Guidewire/GWLoginPage';
import { GWSearchPage } from '../pages/Guidewire/GWSearchPage';
import { GWClaimRegistrationPage } from '../pages/Guidewire/GWClaimRegistrationPage';
import { GWClaimParticipantsPage } from '../pages/Guidewire/GWClaimParticipantsPage';
import { GWDocumentsPage } from '../pages/Guidewire/GWDocumentsPage';
import { GWAdminPage } from '../pages/Guidewire/GWAdminPage';
import { GWRecoveryPage } from '../pages/Guidewire/GWRecoveryPage';
import { GWAppealsPage } from '../pages/Guidewire/GWAppealsPage';
import { GWCC_History } from '../pages/Guidewire/GWCC_History';

export class CustomWorld extends World {
    browser?: Browser;
    context?: BrowserContext;
    page?: Page;

    // Page Objects
    loginPage?: LoginPage;
    homePage?: HomePage;
    getStarted?: GetStarted;

    // Guidewire Page Objects
    gwLogin?: any;
    gwSearch?: any;
    gwRegistration?: any;
    gwParticipants?: any;
    gwDocuments?: any;
    gwAdmin?: any;
    gwRecovery?: any;
    gwAppeals?: any;
    gwccHistory?: any;
    gwcm?: any;

    // OSPC Page Objects
    ospcClaimOverview?: any;
    tombstone?: any;
    ospcDirectDeposit?: any;

    // CAA Page Objects
    clothingAllowance?: any;
    wtLandingPage?: any;
    travelExpense?: any;

    // UNCD Page Objects
    uncdGetStarted?: any;
    uncdAddClaimantInfo?: any;
    uncdSubmitDocuments?: any;
    uncdReviewSubmission?: any;

    // EForm6 Page Objects
    eform6?: any;
    eform6_workhistory?: any;
    eform6_injurydetails?: any;
    eform6_reviewandsubmit?: any;
    eform6_supportingdocuments?: any;
    eform6_losttimeearnings?: any;
    eform6_healthcare?: any;
    eform6_exposuredetails?: any;

    // EForm7 Page Objects
    eform7?: any;
    eform7_reporttype?: any;
    eform7_reporterdetails?: any;
    eform7_employerdetails?: any;
    eform7_employeedetails?: any;
    eform7_workhistorydetails?: any;
    eform7_injuryillnessdetails?: any;
    eform7_healthcaredetails?: any;
    eform7_losstimeearningsdetails?: any;
    eform7_supportingdocuments?: any;
    eform7_reviewandsubmit?: any;
    ospcClaimOverview?: any;

    // NIHL Page Objects
    nihllandingpage?: any;
    myinformation?: any;
    healthcare?: any;
    employement?: any;
    nihlsupportingdocuments?: any;
    nihlreviewandconfirm?: any;

    // API State
    apiEndpoint?: string;
    apiRequestBody?: string;
    apiResponse?: any;

    // Accessibility
    lastScanResults?: any;

    // Data
    currentRow?: any;

    constructor(options: IWorldOptions) {
        super(options);
    }

    async initPages() {
        if (!this.page) throw new Error("Page not initialized");
        this.loginPage = new LoginPage(this.page);
        this.homePage = new HomePage(this.page);
        this.getStarted = new GetStarted(this.page);

        this.gwLogin = new GWLoginPage(this.page);
        this.gwSearch = new GWSearchPage(this.page);
        this.gwRegistration = new GWClaimRegistrationPage(this.page);
        this.gwParticipants = new GWClaimParticipantsPage(this.page);
        this.gwDocuments = new GWDocumentsPage(this.page);
        this.gwAdmin = new GWAdminPage(this.page);
        this.gwRecovery = new GWRecoveryPage(this.page);
        this.gwAppeals = new GWAppealsPage(this.page);
        this.gwccHistory = new GWCC_History(this.page);
        this.gwcm = new (require('../pages/Guidewire/GuidewireCMPage').GuidewireCMPage || any)(this.page);

        this.uncdGetStarted = new (require('../pages/UNCD/GetStarted').GetStarted || any)(this.page);
        this.uncdAddClaimantInfo = new (require('../pages/UNCD/AddClaimantInfo').AddClaimantInfo || any)(this.page);
        this.uncdSubmitDocuments = new (require('../pages/UNCD/SubmitDocuments').SubmitDocuments || any)(this.page);
        this.uncdReviewSubmission = new (require('../pages/UNCD/ReviewSubmission').ReviewSubmission || any)(this.page);

        this.eform6 = new (require('../pages/DynamicIntakeEform6/DIeForm6').DIeForm6 || any)(this.page);
        this.eform6_workhistory = new (require('../pages/DynamicIntakeEform6/DIeForm6_WorkHistory').DIeForm6_WorkHistory || any)(this.page);
        this.eform6_injurydetails = new (require('../pages/DynamicIntakeEform6/DIeForm6_InjuryDetails').DIeForm6_InjuryDetails || any)(this.page);
        this.eform6_reviewandsubmit = new (require('../pages/DynamicIntakeEform6/DIeForm6_ReviewandSubmit').DIeForm6_ReviewandSubmit || any)(this.page);
        this.eform6_supportingdocuments = new (require('../pages/DynamicIntakeEform6/DIeForm6_SupportingDocuments').DIeForm6_SupportingDocuments || any)(this.page);
        this.eform6_losttimeearnings = new (require('../pages/DynamicIntakeEform6/DIeForm6_LostTimeandEarnings').DIeForm6_LostTimeandEarnings || any)(this.page);
        this.eform6_healthcare = new (require('../pages/DynamicIntakeEform6/DIeForm6_HealthCare').DIeForm6_HealthCare || any)(this.page);
        this.eform6_exposuredetails = new (require('../pages/DynamicIntakeEform6/DIeForm6_ExposureDetails').DIeForm6_ExposureDetails || any)(this.page);

        // OSPC Page Objects
        this.ospcClaimOverview = new (require('../pages/OSPC/OSPCClaimOverview').OSPCClaimOverview || any)(this.page);
        this.tombstone = new (require('../pages/OSPC/Tombstone').Tombstone || any)(this.page);

        this.wtLandingPage = new (require('../pages/WT/WTLandingPage').WTLandingPage || any)(this.page);
        this.travelExpense = new (require('../pages/WT/TravelExpense').TravelExpense || any)(this.page);
    }
}

setWorldConstructor(CustomWorld);
