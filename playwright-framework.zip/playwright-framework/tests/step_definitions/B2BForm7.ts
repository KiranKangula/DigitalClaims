import { Given, When, Then, And } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { CustomWorld } from './world';
import { BasePage } from '../../utils/BasePage';
import fs from 'fs';
import path from 'path';

Given('the API endpoint is configured with {string}', async function (this: CustomWorld, endpointSuffix: string) {
    this.apiEndpoint = (process.env.AUTH_HANDLER || '') + endpointSuffix;
    console.log(`API Endpoint configured: ${this.apiEndpoint}`);
});

Given('the API Token endpoint is configured with {string}', async function (this: CustomWorld, tokenEndpointSuffix: string) {
    this.apiEndpoint = (process.env.AUTH_HANDLER || '') + tokenEndpointSuffix;
    console.log(`API Token Endpoint configured: ${this.apiEndpoint}`);
});

And('the request body is:', async function (this: CustomWorld, body: string) {
    const claimNumber = process.env.CLAIM_NUMBER || '';
    const fileId = process.env.FILE_ID || '';
    const loginId = process.env.USER_LOGIN_ID || '';
    const lastName = process.env.LAST_NAME || '';
    const dateOfBirth = process.env.DATE_OF_BIRTH || '';
    const month = process.env.MONTH || '';
    const year = process.env.YEAR || '';
    const institutionNumber = process.env.INSTITUTION_NUMBER || '';
    const transitNumber = process.env.TRANSIT_NUMBER || '';
    const bankAccountNumber = process.env.BANK_ACCOUNT_NUMBER || '';
    const ddPublicId = process.env.DD_PUBLIC_ID || '';
    const refNumber = process.env.REF_NUMBER || '';
    const sessionId = process.env.SESSION_ID || '';
    const uploadFileId = process.env.UPLOAD_FILE_ID || '';
    const filename = process.env.FILENAME || '';

    this.apiRequestBody = body
        .replace('{{ClaimNumber}}', claimNumber)
        .replace('{{FileID}}', fileId)
        .replace('{{userLoginID}}', loginId)
        .replace('{{LastName}}', lastName)
        .replace('{{dateOfBirth}}', dateOfBirth)
        .replace('{{Month}}', month)
        .replace('{{Year}}', year)
        .replace('{{InstitutionNumber}}', institutionNumber)
        .replace('{{TransitNumber}}', transitNumber)
        .replace('{{BankAccountNumber}}', bankAccountNumber)
        .replace('{{DD_publicID}}', ddPublicId)
        .replace('{{RefNumber}}', refNumber)
        .replace('{{Filename}}', filename)
        .replace('{{SessionId}}', sessionId)
        .replace('{{UploadFileId}}', uploadFileId);

    console.log('Request body configured with dynamic parameters.');
});

When('a POST request is sent', async function (this: CustomWorld) {
    const bearerToken = process.env.BEARER_TOKEN || '';
    console.log(`Sending POST request to: ${this.apiEndpoint}`);

    const response = await this.context!.request.post(this.apiEndpoint!, {
        headers: {
            'Authorization': `Bearer ${bearerToken}`,
            'Content-Type': 'application/json',
        },
        data: this.apiRequestBody
    });

    this.apiResponse = response;
});

Then('the response status code should be {int}', async function (this: CustomWorld, statusCode: number) {
    const response = this.apiResponse;
    console.log('Response Pretty Print:');
    console.log(await response.text());

    expect(response.status()).toBe(statusCode);
    console.log(`Response status code validated: ${statusCode}`);
});

When('a POST request is sent with form data', async function (this: CustomWorld) {
    const bearerToken = process.env.BEARER_TOKEN || '';
    const filePath = process.env.FILE_PATH || '';
    console.log(`Sending POST request with form-data to: ${this.apiEndpoint}`);

    const response = await this.context!.request.post(this.apiEndpoint!, {
        headers: {
            'Authorization': `Bearer ${bearerToken}`,
            'Content-Type': 'multipart/form-data',
        },
        multipart: {
            file: {
                name: 'file',
                mimeType: 'application/pdf', // Assuming PDF based on Java code
                buffer: fs.readFileSync(filePath),
            },
            claimId: process.env.CLAIM_NUMBER || '',
        }
    });

    this.apiResponse = response;
});

Then('Extract the file id from the response', async function (this: CustomWorld) {
    const response = this.apiResponse;
    const json = await response.json();
    const fileId = json.name;

    expect(fileId).not.toBeNull();
    process.env.FILE_ID = fileId;
    console.log(`Extracted File ID: ${fileId}`);
});

When('a POST request is sent with Claimid as parameters', async function (this: CustomWorld) {
    const bearerToken = process.env.BEARER_TOKEN || '';
    console.log(`Sending GET request with ClaimId parameter to: ${this.apiEndpoint}`);

    const response = await this.context!.request.get(this.apiEndpoint!, {
        headers: {
            'Authorization': `Bearer ${bearerToken}`,
        },
        params: {
            'claimId': process.env.CLAIM_NUMBER || '',
        }
    });

    this.apiResponse = response;
});

Then('Capture the Public id from the response', async function (this: CustomWorld) {
    const response = this.apiResponse;
    const json = await response.json();
    const publicId = json.result?.publicID;

    expect(publicId).not.toBeNull();
    process.env.DD_PUBLIC_ID = publicId;
    console.log(`Extracted PublicId: ${publicId}`);
});

And('the request body is identified: {string}', async function (this: CustomWorld, type: string) {
    console.log(`Identifying request body for type: ${type}`);

    if (type === 'Injury') {
        this.apiRequestBody = JSON.stringify({
            id: "b1385a2c-8477-4580-903c-f7c3c8331aa6_32",
            jsonrpc: "2.0",
            method: "createClaim",
            params: [
                {
                    privacyWC: true,
                    diwizardStep: "DI_EmployerDetails",
                    reportType: "injuryOrIllness",
                    intakeChannel: "OSPC_DI_Web",
                    originalChannel: "OSPC_DI_Web",
                    categoryOfIllness: "physicalInjury",
                    oneTime: "no",
                    injuryDescribedAs: "Faint",
                    lossDetails: {
                        injuryIncident: {
                            accidentIllnessCat: "GraduallyOccuringOverTime",
                            natureOfAccident: "Faint"
                        }
                    },
                    claimant: {
                        firstName: "Kiran",
                        lastName: "Kangula",
                        pronoun_Ext: "he_him",
                        workNumber: "234-234-2342",
                        gender: "M",
                        dateOfBirthLocal: { year: 2000, month: 0, day: 1 },
                        languageOfService_Ext: "english",
                        show: false,
                        workerSinNoExist_Ext: true,
                        primaryAddress: {
                            country: "CA",
                            state: "ON",
                            addressLine1: "140 Erskine Avenue",
                            city: "Toronto",
                            postalCode: "M4P 1Z2"
                        }
                    },
                    checkAgeUnderSixteen_WC: false,
                    languageOfServiceUi: "en",
                    employer: {
                        primaryAddress: {
                            country: "CA",
                            state: "ON",
                            addressLine1: "140 Erskine Avenue",
                            city: "Toronto",
                            postalCode: "M4P 1Z2"
                        },
                        contactName: "InjuryTest",
                        workNumber: "000-000-0000"
                    }
                }
            ]
        });
    } else if (type === 'Illness') {
        this.apiRequestBody = JSON.stringify({
            id: "eb41e556-7a50-4cde-920e-d45d5810baab_2",
            jsonrpc: "2.0",
            method: "createClaim",
            params: [
                {
                    privacyWC: true,
                    diwizardStep: "DI_EmployerDetails",
                    reportType: "injuryOrIllness",
                    intakeChannel: "OSPC_DI_Web",
                    originalChannel: "OSPC_DI_Web",
                    lossDetails: {
                        injuryIncident: {
                            accidentIllnessCat: "OccupationalDisease"
                        }
                    },
                    exposureApplicable: "false",
                    categoryOfIllness: "illness",
                    claimant: {
                        firstName: "Kiran",
                        lastName: "Kangula",
                        pronoun_Ext: "he_him",
                        workNumber: "647-666-6666",
                        gender: "M",
                        dateOfBirthLocal: { year: 2000, month: 0, day: 1 },
                        languageOfService_Ext: "english",
                        show: false,
                        workerSinNoExist_Ext: true,
                        primaryAddress: {
                            country: "CA",
                            state: "ON",
                            addressLine1: "140 Erskine Avenue",
                            city: "Toronto",
                            postalCode: "M4P 1Z2"
                        }
                    },
                    checkAgeUnderSixteen_WC: false,
                    languageOfServiceUi: "en",
                    employer: {
                        primaryAddress: {
                            country: "CA",
                            state: "ON",
                            addressLine1: "140 Erskine Avenue",
                            city: "Toronto",
                            postalCode: "M4P 1Z2"
                        },
                        contactName: "IllnessTest",
                        workNumber: "000-000-0000"
                    }
                }
            ]
        });
    } else if (type === 'Mental Health') {
        this.apiRequestBody = JSON.stringify({
            id: "eb41e556-7a50-4cde-920e-d45d5810baab_4",
            jsonrpc: "2.0",
            method: "createClaim",
            params: [
                {
                    privacyWC: true,
                    diwizardStep: "DI_ReviewAndSubmit",
                    reportType: "injuryOrIllness",
                    intakeChannel: "OSPC_DI_Web",
                    originalChannel: "OSPC_DI_Web",
                    categoryOfIllness: "mentalHealth",
                    lossDetails: {
                        injuryIncident: {
                            accidentIllnessCat: "PsychologicalCondition",
                            natureOfAccident: "CumPsycoEvent"
                        }
                    },
                    claimant: {
                        firstName: "Kiran",
                        lastName: "Kangula",
                        pronoun_Ext: "he_him",
                        workNumber: "647-888-8888",
                        gender: "M",
                        dateOfBirthLocal: { year: 2000, month: 0, day: 1 },
                        languageOfService_Ext: "english",
                        show: false,
                        workerSinNoExist_Ext: true,
                        primaryAddress: {
                            country: "CA",
                            state: "ON",
                            addressLine1: "140 Erskine Avenue",
                            city: "Toronto",
                            postalCode: "M4P 1Z2"
                        }
                    },
                    checkAgeUnderSixteen_WC: false,
                    languageOfServiceUi: "en",
                    employer: {
                        primaryAddress: {
                            country: "CA",
                            state: "ON",
                            addressLine1: "140 Erskine Avenue",
                            city: "Toronto",
                            postalCode: "M4P 1Z2"
                        },
                        contactName: "EmployerMental",
                        workNumber: "000-000-0000"
                    }
                }
            ]
        });
    } else if (type === 'Construction') {
        this.apiRequestBody = JSON.stringify({
            id: "eb41e556-7a50-4cde-920e-d45d5810baab_6",
            jsonrpc: "2.0",
            method: "createClaim",
            params: [
                {
                    privacyWC: true,
                    diwizardStep: "DI_ReviewAndSubmit",
                    reportType: "exposureIncident",
                    intakeChannel: "OSPC_DI_Web",
                    originalChannel: "OSPC_DI_Web",
                    lossDetails: {
                        injuryIncident: {
                            natureOfAccident: "ExposureReportWithoutInjury",
                            accidentIllnessCat: "OccupationalDisease"
                        },
                        peirceir: {
                            workerInConstruction: true
                        }
                    },
                    exposureApplicable: "false",
                    claimant: {
                        firstName: "Kiran",
                        lastName: "Kangula",
                        pronoun_Ext: "he_him",
                        workNumber: "647-888-8888",
                        languageOfService_Ext: "english",
                        gender: "M",
                        workerSinNoExist_Ext: true,
                        dateOfBirthLocal: { year: 2000, month: 0, day: 1 },
                        primaryAddress: {
                            country: "CA",
                            state: "ON",
                            addressLine1: "140 Erskine Avenue",
                            city: "Toronto",
                            postalCode: "M4P 1Z2"
                        }
                    },
                    checkAgeUnderSixteen_WC: false,
                    employer: {
                        primaryAddress: {
                            country: "CA",
                            state: "ON",
                            addressLine1: "140 Erskine Avenue",
                            city: "Toronto",
                            postalCode: "M4P 1Z2"
                        },
                        contactName: "EmployerConstruction",
                        workNumber: "647-777-7777"
                    }
                }
            ]
        });
    } else if (type === 'Other Industry') {
        this.apiRequestBody = JSON.stringify({
            id: "eb41e556-7a50-4cde-920e-d45d5810baab_8",
            jsonrpc: "2.0",
            method: "createClaim",
            params: [
                {
                    privacyWC: true,
                    diwizardStep: "DI_ReviewAndSubmit",
                    reportType: "exposureIncident",
                    intakeChannel: "OSPC_DI_Web",
                    originalChannel: "OSPC_DI_Web",
                    lossDetails: {
                        injuryIncident: {
                            natureOfAccident: "ExposureReportWithoutInjury",
                            accidentIllnessCat: "OccupationalDisease"
                        },
                        peirceir: {
                            workerInConstruction: false
                        }
                    },
                    exposureApplicable: "false",
                    claimant: {
                        firstName: "Kiran",
                        lastName: "Kangula",
                        pronoun_Ext: "he_him",
                        workNumber: "647-888-8888",
                        languageOfService_Ext: "english",
                        gender: "M",
                        workerSinNoExist_Ext: true,
                        dateOfBirthLocal: { year: 2000, month: 0, day: 1 },
                        primaryAddress: {
                            country: "CA",
                            state: "ON",
                            addressLine1: "140 Erskine Avenue",
                            city: "Toronto",
                            postalCode: "M4P 1Z2"
                        }
                    },
                    checkAgeUnderSixteen_WC: false,
                    employer: {
                        primaryAddress: {
                            country: "CA",
                            state: "ON",
                            addressLine1: "140 Erskine Avenue",
                            city: "Toronto",
                            postalCode: "M4P 1Z2"
                        },
                        contactName: "OtherIndustry",
                        workNumber: "647-099-8888"
                    }
                }
            ]
        });
    }
    console.log(`Identifying request body for type: ${type}`);
});

Then('Capture the ReferenceNumber from the response', async function (this: CustomWorld) {
    const response = this.apiResponse;
    const json = await response.json();
    const refNumber = json.result?.claimNumber;

    expect(refNumber).not.toBeNull();
    process.env.REF_NUMBER = refNumber;
    console.log(`Extracted RefNumber: ${refNumber}`);
});

And('the request body for submit claim is configured: {string}', async function (this: CustomWorld, type: string) {
    console.log(`Configuring request body for submit claim: ${type}`);
    const refNumber = process.env.REF_NUMBER || '';

    if (type === 'Injury') {
        this.apiRequestBody = JSON.stringify({
            id: "b1385a2c-8477-4580-903c-f7c3c8331aa6_32",
            jsonrpc: "2.0",
            method: "submitClaim",
            params: [
                {
                    privacyWC: true,
                    diwizardStep: "DI_ReviewAndSubmit",
                    reportType: "injuryOrIllness",
                    intakeChannel: "OSPC_DI_Web",
                    originalChannel: "OSPC_DI_Web",
                    oneTime: "no",
                    injuryDescribedAs: "Faint",
                    categoryOfIllness: "physicalInjury",
                    languageOfServiceUi: "en",
                    createTime: "2025-06-16T19:50:16Z",
                    claimNumber: refNumber,
                    claimant: {
                        displayName: "Kiran Kangula",
                        subtype: "WSIB_PersonWorker",
                        firstName: "Kiran",
                        lastName: "Kangula",
                        gender: "M",
                        primaryAddress: {
                            state: "ON",
                            country: "CA",
                            displayName: "140 Erskine Avenue,\\nToronto, ON M4P 1Z2",
                            city: "Toronto",
                            postalCode: "M4P 1Z2",
                            addressLine1: "140 Erskine Avenue"
                        },
                        contactType: "WSIB_PersonWorker",
                        workNumber: "234-234-2342",
                        dateOfBirthLocal: { month: 0, year: 2000, day: 1 },
                        pronoun_Ext: "he_him",
                        languageOfService_Ext: "english",
                        workerSinNoExist_Ext: true
                    },
                    claimState: "draft",
                    claimReportedByType: "worker",
                    checkAgeUnderSixteen_WC: false,
                    employer: {
                        displayName: "InjuryTest",
                        subtype: "Company",
                        primaryAddress: {
                            state: "ON",
                            country: "CA",
                            displayName: "140 Erskine Avenue,\\nToronto, ON M4P 1Z2",
                            city: "Toronto",
                            postalCode: "M4P 1Z2",
                            addressLine1: "140 Erskine Avenue"
                        },
                        contactType: "Company",
                        contactName: "InjuryTest",
                        workNumber: "000-000-0000",
                        primaryPhoneValue_WSIB: "000-000-0000"
                    },
                    lossDetails: {
                        injuryIncident: {
                            accidentIllnessCat: "GraduallyOccuringOverTime",
                            natureOfAccident: "Faint",
                            firstGradualTimeDesc: "Test",
                            bodyPartDetails: [
                                { detailedBodyPart: "Head", primaryBodyPart: "head" }
                            ],
                            havsdetails: [],
                            nihldetails: []
                        },
                        accidentLocation: {
                            state: "ON",
                            country: "CA",
                            displayName: "140 Erskine Avenue,\\nToronto, ON M4P 1Z2",
                            city: "Toronto",
                            postalCode: "M4P 1Z2",
                            addressLine1: "140 Erskine Avenue",
                            areaOfAccident: "WorkOrJobSite"
                        },
                        lossTimeDetails: {
                            lostTimeDueToInjury: false,
                            rtwisWageLoss: false,
                            typeOfReturnedWork: "Regular"
                        },
                        healthCare: {
                            hcreceivedWorker: "No"
                        },
                        priorSimilarCond: false,
                        accidentWitness: false
                    },
                    employmentData: {
                        occupation: "Job",
                        hireDate: { month: 0, year: 2023, day: 1 },
                        wsib_BenEarningsSummaries: [
                            { benefitEarnings: [], otherBenefitEarnings: [] }
                        ],
                        company20Employee: false,
                        wsib_EmployerRelation: "self_employed",
                        wsib_IsSpouseRelavtive: false,
                        employmentLengthYear: 2,
                        employmentLengthMonth: 1,
                        representation: false
                    },
                    immediateSupervisor: {
                        displayName: "Test Super",
                        subtype: "WSIB_PersonOther",
                        firstName: "Test",
                        lastName: "Super",
                        contactType: "WSIB_PersonOther",
                        workNumber: "234-234-2342"
                    },
                    accidentHistory: "Test",
                    onsetFromDate: { month: 0, year: 2024, day: 1 },
                    signatAknlgmt: true,
                    isSubmitEnroll: true,
                    allowAutoEnrollment: true
                }
            ]
        });
    } else if (type === 'Illness') {
        this.apiRequestBody = JSON.stringify({
            id: "655f5504-0f06-43e5-bd51-6aa9b16fd259_44",
            jsonrpc: "2.0",
            method: "submitClaim",
            params: [
                {
                    privacyWC: true,
                    diwizardStep: "DI_ReviewAndSubmit",
                    reportType: "injuryOrIllness",
                    intakeChannel: "OSPC_DI_Web",
                    originalChannel: "OSPC_DI_Web",
                    categoryOfIllness: "illness",
                    languageOfServiceUi: "en",
                    createTime: "2025-06-18T14:14:53Z",
                    claimNumber: refNumber,
                    claimant: {
                        displayName: "Kiran Kangula",
                        subtype: "WSIB_PersonWorker",
                        firstName: "Kiran",
                        lastName: "Kangula",
                        gender: "M",
                        primaryAddress: {
                            state: "ON",
                            country: "CA",
                            displayName: "140 Erskine Avenue,\\nToronto, ON M4P 1Z2",
                            city: "Toronto",
                            postalCode: "M4P 1Z2",
                            addressLine1: "140 Erskine Avenue"
                        },
                        contactType: "WSIB_PersonWorker",
                        workNumber: "647-666-6666",
                        dateOfBirthLocal: { month: 0, year: 2000, day: 1 },
                        pronoun_Ext: "he_him",
                        languageOfService_Ext: "english",
                        workerSinNoExist_Ext: true
                    },
                    claimState: "draft",
                    claimReportedByType: "worker",
                    checkAgeUnderSixteen_WC: false,
                    employer: {
                        displayName: "IllnessTest",
                        subtype: "Company",
                        primaryAddress: {
                            state: "ON",
                            country: "CA",
                            displayName: "140 Erskine Avenue,\\nToronto, ON M4P 1Z2",
                            city: "Toronto",
                            postalCode: "M4P 1Z2",
                            addressLine1: "140 Erskine Avenue"
                        },
                        contactType: "Company",
                        contactName: "IllnessTest",
                        workNumber: "000-000-0000",
                        primaryPhoneValue_WSIB: "000-000-0000"
                    },
                    lossDetails: {
                        injuryIncident: {
                            accidentCatOptns: "NA",
                            accidentIllnessCat: "OccupationalDisease",
                            od_illnessDetails: "Sfasasdf",
                            od_treatmentDetails: "asdfadfasasdfaqf",
                            bodyPartDetails: [],
                            havsdetails: [],
                            nihldetails: []
                        },
                        accidentLocation: {
                            state: "ON",
                            country: "CA",
                            displayName: "140 Erskine Avenue,\\nToronto, ON M4P 1Z2",
                            city: "Toronto",
                            postalCode: "M4P 1Z2",
                            addressLine1: "140 Erskine Avenue",
                            areaOfAccident: "WorkOrJobSite"
                        },
                        lossTimeDetails: {
                            lostTimeDueToInjury: false,
                            rtwisWageLoss: false,
                            typeOfReturnedWork: "Regular"
                        },
                        healthCare: {
                            hcreceivedWorker: "No"
                        },
                        priorSimilarCond: false,
                        accidentWitness: false
                    },
                    employmentData: {
                        occupation: "Test",
                        hireDate: { month: 0, year: 2000, day: 1 },
                        wsib_BenEarningsSummaries: [
                            { benefitEarnings: [], otherBenefitEarnings: [] }
                        ],
                        company20Employee: false,
                        wsib_EmployerRelation: "self_employed",
                        wsib_IsSpouseRelavtive: false,
                        employmentLengthYear: 1,
                        employmentLengthMonth: 1,
                        representation: false
                    },
                    immediateSupervisor: {
                        displayName: "Test Super",
                        subtype: "WSIB_PersonOther",
                        firstName: "Test",
                        lastName: "Super",
                        contactType: "WSIB_PersonOther",
                        workNumber: "000-000-0000"
                    },
                    accidentHistory: "asdfasdf",
                    onsetFromDate: { month: 0, year: 2023, day: 1 },
                    additionalIntakeComments_WC: "asasdasdasd",
                    signatAknlgmt: true,
                    isSubmitEnroll: true,
                    allowAutoEnrollment: true
                }
            ]
        });
    } else if (type === 'Mental Health') {
        this.apiRequestBody = JSON.stringify({
            id: "655f5504-0f06-43e5-bd51-6aa9b16fd259_24",
            jsonrpc: "2.0",
            method: "submitClaim",
            params: [
                {
                    privacyWC: true,
                    diwizardStep: "DI_ReviewAndSubmit",
                    reportType: "injuryOrIllness",
                    intakeChannel: "OSPC_DI_Web",
                    originalChannel: "OSPC_DI_Web",
                    categoryOfIllness: "mentalHealth",
                    languageOfServiceUi: "en",
                    createTime: "2025-06-18T14:15:19Z",
                    claimNumber: refNumber,
                    claimant: {
                        displayName: "Kiran Kangula",
                        subtype: "WSIB_PersonWorker",
                        firstName: "Kiran",
                        lastName: "Kangula",
                        gender: "M",
                        primaryAddress: {
                            state: "ON",
                            country: "CA",
                            displayName: "140 Erskine Avenue,\\nToronto, ON M4P 1Z2",
                            publicID: "cc:651890446",
                            city: "Toronto",
                            postalCode: "M4P 1Z2",
                            addressLine1: "140 Erskine Avenue"
                        },
                        contactType: "WSIB_PersonWorker",
                        workNumber: "647-888-8888",
                        dateOfBirthLocal: { month: 0, year: 2000, day: 1 },
                        pronoun_Ext: "he_him",
                        languageOfService_Ext: "english",
                        workerSinNoExist_Ext: true
                    },
                    claimState: "draft",
                    claimReportedByType: "worker",
                    checkAgeUnderSixteen_WC: false,
                    employer: {
                        displayName: "EmployerMental",
                        subtype: "Company",
                        primaryAddress: {
                            state: "ON",
                            country: "CA",
                            displayName: "140 Erskine Avenue,\\nToronto, ON M4P 1Z2",
                            publicID: "cc:651890447",
                            city: "Toronto",
                            postalCode: "M4P 1Z2",
                            addressLine1: "140 Erskine Avenue"
                        },
                        contactType: "Company",
                        contactName: "EmployerMental",
                        workNumber: "000-000-0000",
                        primaryPhoneValue_WSIB: "000-000-0000"
                    },
                    lossDetails: {
                        injuryIncident: {
                            accidentCatOptns: "NA",
                            accidentIllnessCat: "PsychologicalCondition",
                            natureOfAccident: "CumPsycoEvent",
                            bodyPartDetails: [],
                            havsdetails: [],
                            nihldetails: []
                        },
                        accidentLocation: {
                            state: "ON",
                            country: "CA",
                            displayName: "140 Erskine Avenue,\\nToronto, ON M4P 1Z2",
                            city: "Toronto",
                            postalCode: "M4P 1Z2",
                            addressLine1: "140 Erskine Avenue",
                            areaOfAccident: "WorkOrJobSite"
                        },
                        lossTimeDetails: {
                            lostTimeDueToInjury: false,
                            rtwisWageLoss: false,
                            typeOfReturnedWork: "Regular"
                        },
                        healthCare: {
                            hcreceivedWorker: "No"
                        },
                        priorSimilarCond: false,
                        accidentWitness: false
                    },
                    employmentData: {
                        occupation: "Ilness title",
                        hireDate: { month: 0, year: 2000, day: 1 },
                        wsib_BenEarningsSummaries: [
                            { benefitEarnings: [], otherBenefitEarnings: [] }
                        ],
                        company20Employee: false,
                        wsib_EmployerRelation: "self_employed",
                        wsib_IsSpouseRelavtive: false,
                        employmentLengthYear: 1,
                        employmentLengthMonth: 1,
                        representation: false
                    },
                    immediateSupervisor: {
                        displayName: "Test Super",
                        subtype: "WSIB_PersonOther",
                        firstName: "Test",
                        lastName: "Super",
                        contactType: "WSIB_PersonOther",
                        workNumber: "000-000-0000"
                    },
                    accidentHistory: "Reqsasd",
                    onsetFromDate: { month: 0, year: 2023, day: 1 },
                    periodOnSetToDate: { month: 0, year: 2023, day: 1 },
                    psycholphysicalinjury_wc: false,
                    additionalIntakeComments_WC: "Test",
                    signatAknlgmt: true,
                    isSubmitEnroll: true,
                    allowAutoEnrollment: true
                }
            ]
        });
    } else if (type === 'Construction') {
        this.apiRequestBody = JSON.stringify({
            id: "655f5504-0f06-43e5-bd51-6aa9b16fd259_59",
            jsonrpc: "2.0",
            method: "submitClaim",
            params: [
                {
                    privacyWC: true,
                    diwizardStep: "DI_ReviewAndSubmit",
                    reportType: "exposureIncident",
                    intakeChannel: "OSPC_DI_Web",
                    originalChannel: "OSPC_DI_Web",
                    languageOfServiceUi: "en",
                    createTime: "2025-06-18T14:15:43Z",
                    claimNumber: refNumber,
                    claimant: {
                        displayName: "Kiran Kangula",
                        subtype: "WSIB_PersonWorker",
                        firstName: "Kiran",
                        lastName: "Kangula",
                        gender: "M",
                        primaryAddress: {
                            state: "ON",
                            country: "CA",
                            displayName: "140 Erskine Avenue,\\nToronto, ON M4P 1Z2",
                            city: "Toronto",
                            postalCode: "M4P 1Z2",
                            addressLine1: "140 Erskine Avenue"
                        },
                        contactType: "WSIB_PersonWorker",
                        workNumber: "647-888-8888",
                        dateOfBirthLocal: { month: 0, year: 2000, day: 1 },
                        pronoun_Ext: "he_him",
                        languageOfService_Ext: "english",
                        workerSinNoExist_Ext: true
                    },
                    claimState: "draft",
                    claimReportedByType: "worker",
                    checkAgeUnderSixteen_WC: false,
                    employer: {
                        displayName: "EmployerConstruction",
                        subtype: "Company",
                        primaryAddress: {
                            state: "ON",
                            country: "CA",
                            displayName: "140 Erskine Avenue,\\nToronto, ON M4P 1Z2",
                            city: "Toronto",
                            postalCode: "M4P 1Z2",
                            addressLine1: "140 Erskine Avenue"
                        },
                        contactType: "Company",
                        contactName: "EmployerConstruction",
                        workNumber: "647-777-7777",
                        primaryPhoneValue_WSIB: "647-777-7777"
                    },
                    lossDetails: {
                        injuryIncident: {
                            accidentCatOptns: "NA",
                            accidentIllnessCat: "OccupationalDisease",
                            natureOfAccident: "ExposureReportWithoutInjury",
                            bodyPartDetails: [],
                            havsdetails: [],
                            nihldetails: []
                        },
                        accidentLocation: {
                            state: "ON",
                            country: "CA",
                            displayName: "140 Erskine Avenue,\\nToronto, ON M4P 1Z2",
                            city: "Toronto",
                            postalCode: "M4P 1Z2",
                            addressLine1: "140 Erskine Avenue",
                            areaOfAccident: "WorkOrJobSite"
                        },
                        peirceir: {
                            exposureSource: "Souircer",
                            hsrepCheck: false,
                            jhsccheck: false,
                            natureOfBusiness: "Testers",
                            peirCeirExposureCat: "InfectiousSubstance",
                            peirCeirExposureType: "BodyFluidSplash",
                            peirCeirSubstance: "Tuberculosis",
                            unionNameLocal: "Tester",
                            workerInConstruction: true
                        }
                    },
                    employmentData: {
                        occupation: "Test",
                        hireDate: { month: 0, year: 2000, day: 1 },
                        wsib_BenEarningsSummaries: [
                            { benefitEarnings: [], otherBenefitEarnings: [] }
                        ],
                        company20Employee: false,
                        wsib_EmployerRelation: "self_employed",
                        wsib_IsSpouseRelavtive: false
                    },
                    onsetFromDate: { month: 0, year: 2023, day: 1 },
                    additionalIntakeComments_WC: "Test tetsdq",
                    signatAknlgmt: true
                }
            ]
        });
    } else if (type === 'Other Industry') {
        this.apiRequestBody = JSON.stringify({
            id: "655f5504-0f06-43e5-bd51-6aa9b16fd259_71",
            jsonrpc: "2.0",
            method: "submitClaim",
            params: [
                {
                    privacyWC: true,
                    diwizardStep: "DI_ReviewAndSubmit",
                    reportType: "exposureIncident",
                    intakeChannel: "OSPC_DI_Web",
                    originalChannel: "OSPC_DI_Web",
                    languageOfServiceUi: "en",
                    createTime: "2025-06-18T14:16:05Z",
                    claimNumber: refNumber,
                    claimant: {
                        displayName: "Kiran Kangula",
                        subtype: "WSIB_PersonWorker",
                        firstName: "Kiran",
                        lastName: "Kangula",
                        gender: "M",
                        primaryAddress: {
                            state: "ON",
                            country: "CA",
                            displayName: "140 Erskine Avenue,\\nToronto, ON M4P 1Z2",
                            city: "Toronto",
                            postalCode: "M4P 1Z2",
                            addressLine1: "140 Erskine Avenue"
                        },
                        contactType: "WSIB_PersonWorker",
                        workNumber: "647-888-8888",
                        dateOfBirthLocal: { month: 0, year: 2000, day: 1 },
                        pronoun_Ext: "he_him",
                        languageOfService_Ext: "english",
                        workerSinNoExist_Ext: true
                    },
                    claimState: "draft",
                    claimReportedByType: "worker",
                    checkAgeUnderSixteen_WC: false,
                    employer: {
                        displayName: "OtherIndustry",
                        subtype: "Company",
                        primaryAddress: {
                            state: "ON",
                            country: "CA",
                            displayName: "140 Erskine Avenue,\\nToronto, ON M4P 1Z2",
                            city: "Toronto",
                            postalCode: "M4P 1Z2",
                            addressLine1: "140 Erskine Avenue"
                        },
                        contactType: "Company",
                        contactName: "OtherIndustry",
                        workNumber: "647-099-8888",
                        primaryPhoneValue_WSIB: "647-099-8888"
                    },
                    lossDetails: {
                        injuryIncident: {
                            accidentCatOptns: "NA",
                            accidentIllnessCat: "OccupationalDisease",
                            natureOfAccident: "ExposureReportWithoutHinjury",
                            bodyPartDetails: [],
                            havsdetails: [],
                            nihldetails: []
                        },
                        accidentLocation: {
                            state: "ON",
                            country: "CA",
                            displayName: "140 Erskine Avenue,\\nToronto, ON M4P 1Z2",
                            city: "Toronto",
                            postalCode: "M4P 1Z2",
                            addressLine1: "140 Erskine Avenue",
                            areaOfAccident: "WorkOrJobSite"
                        },
                        peirceir: {
                            locationInAffectedArea: "Testest",
                            natureOfBusiness: "Testers",
                            peirExposureDetail: "Explosion",
                            peirCeirExposureCat: "ChemicalWorkplace",
                            workerInConstruction: false,
                            wornPPE: "teststst"
                        }
                    },
                    employmentData: {
                        occupation: "Test Ob",
                        hireDate: { month: 0, year: 2023, day: 1 },
                        wsib_BenEarningsSummaries: [
                            { benefitEarnings: [], otherBenefitEarnings: [] }
                        ],
                        company20Employee: false,
                        wsib_EmployerRelation: "self_employed",
                        wsib_IsSpouseRelavtive: false
                    },
                    onsetFromDate: { month: 0, year: 2023, day: 1 },
                    additionalIntakeComments_WC: "SAasdasdasd",
                    signatAknlgmt: true
                }
            ]
        });
    }
    console.log(`Configuring request body for submit claim: ${type}`);
});

Then('Capture the SessionId from the response', async function (this: CustomWorld) {
    const response = this.apiResponse;
    const json = await response.json();
    const sessionId = json.result;

    expect(sessionId).not.toBeNull();
    process.env.SESSION_ID = sessionId;
    console.log(`Extracted SessionId: ${sessionId}`);
});

When('a POST request is sent with file and Metadata as parameters', async function (this: CustomWorld) {
    const bearerToken = process.env.BEARER_TOKEN || '';
    const filePath = process.env.FILE_PATH || '';
    console.log(`Sending POST request with file and metadata to: ${this.apiEndpoint}`);

    const response = await this.context!.request.post(this.apiEndpoint!, {
        headers: {
            'Authorization': `Bearer ${bearerToken}`,
            'Content-Type': 'multipart/form-data',
        },
        multipart: {
            file: {
                name: 'file',
                mimeType: 'application/pdf',
                buffer: fs.readFileSync(filePath),
            },
            claimId: process.env.CLAIM_NUMBER || '',
            docMetadata: JSON.stringify({
                docUID: "001",
                documentType: "letter_received",
                securityType: "unrestricted",
                status: "final",
                claimNumber: process.env.REF_NUMBER || '',
                name: process.env.FILENAME || '',
                mimeType: "application/pdf",
                sessionID: process.env.SESSION_ID || ''
            })
        }
    });

    this.apiResponse = response;
});

And('Capture the UploadFileId from the response', async function (this: CustomWorld) {
    const response = this.apiResponse;
    const json = await response.json();
    const uploadFileId = json.uploadFileID;

    expect(uploadFileId).not.toBeNull();
    process.env.UPLOAD_FILE_ID = uploadFileId;
    console.log(`Extracted UploadFileId: ${uploadFileId}`);
});

Then('Capture the timestamp of the Document uploaded', async function (this: CustomWorld) {
    const now = new Date();
    const timeStamp = now.toISOString().substring(0, 16).replace('T', 'T');
    // Java used yyyy-MM-dd'T'HH:mm
    process.env.TIME_STAMP = timeStamp;
    console.log(`Captured Document Upload Timestamp: ${timeStamp}`);
    await new Promise(resolve => setTimeout(resolve, 10000));
});

Then('Verify the uploaded document is displayed in the response', async function (this: CustomWorld) {
    const response = this.apiResponse;
    const json = await response.json();
    const expectedFileName = process.env.FILENAME || '';
    const expectedTimeStamp = process.env.TIME_STAMP || '';

    const submittedDocuments = json.submittedDocuments || [];
    const isMatchFound = submittedDocuments.some((doc: any) => {
        const formattedTimeStamp = new Date(doc.timeStamp).toISOString().substring(0, 16);
        return doc.fileName === expectedFileName && formattedTimeStamp === expectedTimeStamp;
    });

    if (!isMatchFound) {
        throw new Error(`No matching fileName and timeStamp found in the response. Expected: ${expectedFileName}, ${expectedTimeStamp}`);
    }
    console.log(`Match found: fileName = ${expectedFileName}, timeStamp = ${expectedTimeStamp}`);
});

Then('Capture the timestamp of the message sent', async function (this: CustomWorld) {
    const now = new Date();
    // Java used dd MMM yyyy HH:mm z (America/New_York)
    const timeStamp = now.toLocaleString('en-US', {
        timeZone: 'America/New_York',
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        hour12: false,
        timeZoneName: 'short'
    }).replace(/,/g, '');

    process.env.M_TIME_STAMP = timeStamp;
    console.log(`Captured Message Sent Timestamp: ${timeStamp}`);
    await new Promise(resolve => setTimeout(resolve, 10000));
});

Then('Verify the sent message is displayed in the response', async function (this: CustomWorld) {
    const response = this.apiResponse;
    const json = await response.json();
    const expectedBody = "Test API";
    const expectedTimeStamp = process.env.M_TIME_STAMP || '';

    const customerMessageDetail = json.result?.customerMessages?.customerMessageDetail || [];
    const isMatchFound = customerMessageDetail.some((msg: any) => {
        return msg.body === expectedBody && msg.sendDate === expectedTimeStamp;
    });

    if (!isMatchFound) {
        throw new Error(`No matching body and sendDate found in the response. Expected: ${expectedBody}, ${expectedTimeStamp}`);
    }
    console.log(`Match found: body = ${expectedBody}, sendDate = ${expectedTimeStamp}`);
});

When('the token request body has set up', async function (this: CustomWorld) {
    this.apiRequestBody = `UserId=${process.env.USER_ID || ''}&Password=${process.env.PASSWORD || ''}`;
    console.log('Token request body set up.');
});

And('a Token POST request is sent', async function (this: CustomWorld) {
    console.log(`Sending Token POST request to: ${this.apiEndpoint}`);
    const response = await this.context!.request.post(this.apiEndpoint!, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'User-Agent': 'Jakarta Commons-HttpClient/3.1',
            'Accept': '*/*',
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
        },
        data: this.apiRequestBody
    });
    this.apiResponse = response;
});

Then('Capture the token value from response', async function (this: CustomWorld) {
    const response = this.apiResponse;
    const text = await response.text();

    // The Java code used XmlPath to get Response.ACK.result.authentication.authHandler
    // Since we are in JS, we can use a regex or an XML parser.
    const match = text.match(/<authHandler>(.*?)<\/authHandler>/);
    const token = match ? match[1] : null;

    expect(token).not.toBeNull();
    process.env.AUTH_TOKEN = token;
    console.log('Extracted Auth Token successfully.');
});

And('the request body is configured', async function (this: CustomWorld) {
    this.apiRequestBody = `<?xml version="1.0" encoding="UTF-8"?>
<wsibf7:Form7 xmlns:wsib="http://www.wsib.on.ca" xmlns:wsibf7="http://www.wsib.on.ca/form7" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.wsib.on.ca/form7 ../Form7.xsd http://www.wsib.on.ca BasicComplexTypes.xsd ">
  <wsibf7:version>1.04</wsibf7:version>
  <wsibf7:workerInfo>
    <wsibf7:jobTitle>SE</wsibf7:jobTitle>
    <wsibf7:SIN>354555556</wsibf7:SIN>
    <wsibf7:timeInPosition>12 weeks</wsibf7:timeInPosition>
    <wsibf7:additionalWorkerAttribute>
      <wsibf7:executive>N</wsibf7:executive>
      <wsibf7:electedOfficial>N</wsibf7:electedOfficial>
      <wsibf7:owner>N</wsibf7:owner>
      <wsibf7:spouseOfOwner>N</wsibf7:spouseOfOwner>
    </wsibf7:additionalWorkerAttribute>
    <wsibf7:lastname>${process.env.LAST_NAME || ''}</wsibf7:lastname>
    <wsibf7:firstname>${process.env.FIRST_NAME || ''}</wsibf7:firstname>
    <wsibf7:address>
      <wsib:street>27 Greybeaver Trial</wsib:street>
      <wsib:city>Scarbrough</wsib:city>
      <wsib:province>ON</wsib:province>
      <wsib:postalCode>M1c4p1</wsib:postalCode>
    </wsibf7:address>
    <wsibf7:collectiveAgreementCoverage>Y</wsibf7:collectiveAgreementCoverage>
    <wsibf7:referenceNumber>123456789012345</wsibf7:referenceNumber>
    <wsibf7:preferredLanguage>
      <wsib:priLanguage>E</wsib:priLanguage>
    </wsibf7:preferredLanguage>
    <wsibf7:dateOfBirth>${process.env.DATE_OF_BIRTH || ''}</wsibf7:dateOfBirth>
    <wsibf7:dateOfHire>01012000</wsibf7:dateOfHire>
    <wsibf7:gender>M</wsibf7:gender>
    <wsibf7:phoneNumber>(416)123-1230</wsibf7:phoneNumber>
  </wsibf7:workerInfo>
  <wsibf7:employerInfo>
    <wsibf7:tradeLegalName>BYBUUUU</wsibf7:tradeLegalName>
    <wsibf7:firmAccountNumber>
      <wsibf7:accountNumber>${process.env.ACCOUNT_NUMBER || ''}</wsibf7:accountNumber>
    </wsibf7:firmAccountNumber>
    <wsibf7:mailingAddress>
      <wsib:street>wsib:street</wsib:street>
      <wsib:city>wsib:city</wsib:city>
      <wsib:province>ON</wsib:province>
      <wsib:postalCode>12345</wsib:postalCode>
    </wsibf7:mailingAddress>
    <wsibf7:telephoneNumber>(416)123-1230</wsibf7:telephoneNumber>
    <wsibf7:classCode>A</wsibf7:classCode>
    <wsibf7:NAICSCode>111110</wsibf7:NAICSCode>
    <wsibf7:businessActivityDescription>Soy Bean Farming</wsibf7:businessActivityDescription>
    <wsibf7:over20Employees>N</wsibf7:over20Employees>
    <wsibf7:faxNumber>(416)123-1230</wsibf7:faxNumber>
    <wsibf7:branchAddress>
      <wsib:street>wsib:street</wsib:street>
      <wsib:city>wsib:city</wsib:city>
      <wsib:province>ON</wsib:province>
      <wsib:postalCode>12345</wsib:postalCode>
    </wsibf7:branchAddress>
    <wsibf7:alternateTelephone>(416)123-1230</wsibf7:alternateTelephone>
  </wsibf7:employerInfo>
  <wsibf7:accidentIllnessDetails>
    <wsibf7:incidentDate>
      <wsibf7:incidentDate>01012003</wsibf7:incidentDate>
      <wsibf7:incidentTime>
        <wsib:time>12:23</wsib:time>
        <wsib:AMorPM>AM</wsib:AMorPM>
      </wsibf7:incidentTime>
      <wsibf7:reportedDate>01012003</wsibf7:reportedDate>
      <wsibf7:reportedTime>
        <wsib:time>12:23</wsib:time>
        <wsib:AMorPM>AM</wsib:AMorPM>
      </wsibf7:reportedTime>
    </wsibf7:incidentDate>
    <wsibf7:incidentReport>
      <wsibf7:reportedPersonAndPosition>
        <wsibf7:lineOne>wsibf7:lineOne</wsibf7:lineOne>
        <wsibf7:lineTwo>wsibf7:lineT</wsibf7:lineTwo>
      </wsibf7:reportedPersonAndPosition>
      <wsibf7:phoneNumber>
        <wsib:phoneNumber>(416)123-1230</wsib:phoneNumber>
        <wsib:extension>123</wsib:extension>
      </wsibf7:phoneNumber>
    </wsibf7:incidentReport>
    <wsibf7:accidentOccurrence>S</wsibf7:accidentOccurrence>
    <wsibf7:accidentType>
      <wsibf7:accidentTypes>
        <wsibf7:standardAccidentType>STRUCK</wsibf7:standardAccidentType>
        <wsibf7:otherAccidentType>wsibf7:otherAccidentType</wsibf7:otherAccidentType>
      </wsibf7:accidentTypes>
    </wsibf7:accidentType>
    <wsibf7:injuryArea>
      <wsibf7:injuryAreas>
        <wsibf7:standardInjuryArea>HEAD</wsibf7:standardInjuryArea>
        <wsibf7:otherInjuryArea>wsibf7:otherInjuryArea</wsibf7:otherInjuryArea>
      </wsibf7:injuryAreas>
    </wsibf7:injuryArea>
    <wsibf7:accidentDescription>
      <wsibf7:line1>This is line1</wsibf7:line1>
      <wsibf7:line2>This is line2</wsibf7:line2>
      <wsibf7:line3>This is line3</wsibf7:line3>
      <wsibf7:line4>This is line4</wsibf7:line4>
      <wsibf7:line5>This is line5</wsibf7:line5>
      <wsibf7:line6>12345678901234567890123456789012345678901234567890123456789012345678901234567890123456</wsibf7:line6>
      <wsibf7:line7>123456789012345678901234567890123456789012345678901234567890123456789012345678901234</wsibf7:line7>
    </wsibf7:accidentDescription>
    <wsibf7:accidentLocation>
      <wsibf7:happenedOnEmployersPermises>Y</wsibf7:happenedOnEmployersPermises>
      <wsibf7:Location>wsibf7:Location</wsibf7:Location>
    </wsibf7:accidentLocation>
    <wsibf7:outOfProvinceAccident>
      <wsibf7:inProvinceAccident>Y</wsibf7:inProvinceAccident>
    </wsibf7:outOfProvinceAccident>
    <wsibf7:witnesses>
      <wsibf7:noWitness>Y</wsibf7:noWitness>
    </wsibf7:witnesses>
    <wsibf7:responsibleNonEmployee>
      <wsibf7:noOneResponsible>Y</wsibf7:noOneResponsible>
    </wsibf7:responsibleNonEmployee>
    <wsibf7:relatedProblem>
      <wsibf7:notAware>Y</wsibf7:notAware>
    </wsibf7:relatedProblem>
    <wsibf7:submissionAttached>Y</wsibf7:submissionAttached>
  </wsibf7:accidentIllnessDetails>
  <wsibf7:healthcare>
    <wsibf7:receivingHealthCare>
      <wsibf7:notReceived>Y</wsibf7:notReceived>
    </wsibf7:receivingHealthCare>
    <wsibf7:workerTreatmentLocation>
      <wsibf7:locations>
        <wsibf7:standardLocation>ONSITE</wsibf7:standardLocation>
        <wsibf7:otherLocation>wsibf7:otherLocation</wsibf7:otherLocation>
      </wsibf7:locations>
      <wsibf7:treatmentProfessionalOrFacility>
        <wsibf7:line1>12345678901234567890123456789012345678901234567890</wsibf7:line1>
        <wsibf7:line2>1234567890123456789012345678901234567890123456789012345678901234567890</wsibf7:line2>
        <wsibf7:line3>1234567890123456789012345678901234567890123456789012345678901234567890</wsibf7:line3>
      </wsibf7:treatmentProfessionalOrFacility>
    </wsibf7:workerTreatmentLocation>
  </wsibf7:healthcare>
  <wsibf7:lostOrNoLostTime>
    <wsibf7:returnToRegularJob>
      <wsibf7:baseWageAndEmploymentInformation>
        <wsibf7:employmentType>
          <wsibf7:employmentTypes>
            <wsibf7:standardEmploymentType>PERM_FULL</wsibf7:standardEmploymentType>
            <wsibf7:otherEmploymentType>wsibf7:otherEmploymentType</wsibf7:otherEmploymentType>
          </wsibf7:employmentTypes>
        </wsibf7:employmentType>
        <wsibf7:regularPayRate>
          <wsibf7:payRate>0.0</wsibf7:payRate>
          <wsibf7:payFrequency>
            <wsibf7:standardPayFrequency>H</wsibf7:standardPayFrequency>
          </wsibf7:payFrequency>
        </wsibf7:regularPayRate>
      </wsibf7:baseWageAndEmploymentInformation>
      <wsibf7:declaration>
        <wsibf7:name>wsibfx:name</wsibf7:name>
        <wsibf7:officialTitle>wsibfx:officialTitle</wsibf7:officialTitle>
        <wsibf7:phoneNumber>
          <wsib:phoneNumber>(416)123-1230</wsib:phoneNumber>
          <wsib:extension>123</wsib:extension>
        </wsibf7:phoneNumber>
        <wsibf7:declarationDate>01012003</wsibf7:declarationDate>
      </wsibf7:declaration>
    </wsibf7:returnToRegularJob>
    <wsibf7:confirmedBy>
      <wsibf7:byMyself>Y</wsibf7:byMyself>
    </wsibf7:confirmedBy>
  </wsibf7:lostOrNoLostTime>
  <wsibf7:additionalInformation>
    <wsibf7:info>Info line 1</wsibf7:info>
    <wsibf7:info>Info line 2</wsibf7:info>
    <wsibf7:info>Info line 3</wsibf7:info>
    <wsibf7:info>Info line 4</wsibf7:info>
    <wsibf7:info>Info line 5</wsibf7:info>
    <wsibf7:info>Info line 1a</wsibf7:info>
    <wsibf7:info>Info line 2a</wsibf7:info>
    <wsibf7:info>Info line 3a</wsibf7:info>
    <wsibf7:info>Info line 4a</wsibf7:info>
    <wsibf7:info>Info line 5a</wsibf7:info>
    <wsibf7:info>Info line 1</wsibf7:info>
    <wsibf7:info>Info line 2</wsibf7:info>
    <wsibf7:info>Info line 3</wsibf7:info>
    <wsibf7:info>Info line 4</wsibf7:info>
    <wsibf7:info>Info line 5</wsibf7:info>
    <wsibf7:info>Info line 1a</wsibf7:info>
    <wsibf7:info>Info line 2a</wsibf7:info>
    <wsibf7:info>Info line 3a</wsibf7:info>
    <wsibf7:info>Info line 4a</wsibf7:info>
    <wsibf7:info>Info line 5a</wsibf7:info>
    <wsibf7:info>Info line 1</wsibf7:info>
    <wsibf7:info>Info line 2</wsibf7:info>
    <wsibf7:info>Info line 3</wsibf7:info>
    <wsibf7:info>Info line 4</wsibf7:info>
    <wsibf7:info>Info line 5</wsibf7:info>
    <wsibf7:info>Info line 1a</wsibf7:info>
    <wsibf7:info>Info line 2a</wsibf7:info>
    <wsibf7:info>Info line 3a</wsibf7:info>
    <wsibf7:info>Info line 4a</wsibf7:info>
    <wsibf7:info>Info line 5a</wsibf7:info>
    <wsibf7:info>Info line 1</wsibf7:info>
    <wsibf7:info>Info line 2</wsibf7:info>
    <wsibf7:info>Info line 3</wsibf7:info>
    <wsibf7:info>Info line 4</wsibf7:info>
    <wsibf7:info>Info line 5</wsibf7:info>
    <wsibf7:info>Info line 1a</wsibf7:info>
    <wsibf7:info>Info line 2a</wsibf7:info>
    <wsibf7:info>Info line 3a</wsibf7:info>
    <wsibf7:info>Info line 4a</wsibf7:info>
    <wsibf7:info>Info line 5a</wsibf7:info>
    <wsibf7:info>Info line 5a1</wsibf7:info>
    <wsibf7:info>Info line 5a2</wsibf7:info>
    <wsibf7:info>Info line 5a3</wsibf7:info>
    <wsibf7:info>Info line 5a4</wsibf7:info>
  </wsibf7:additionalInformation>
  <wsibf7:wsibReserved>
    <wsib:reservedField1>wsib:reservedField1</wsib:reservedField1>
    <wsib:reservedField2>wsib:reservedField2</wsib:reservedField2>
  </wsibf7:wsibReserved>
</wsibf7:Form7>`;
    console.log('XML request body configured.');
});

When('a POST request is sent with XML body', async function (this: CustomWorld) {
    const authToken = process.env.AUTH_TOKEN || '';
    console.log(`Sending XML POST request to: ${this.apiEndpoint}`);

    const response = await this.context!.request.post(this.apiEndpoint!, {
        headers: {
            'Content-Type': 'text/plain; charset=ISO-8859-1',
            'Cookie': `$Version=0; JSESSIONID=0000${authToken}:-1; $Path=/`,
            'User-Agent': 'Jakarta Commons-HttpClient/3.1',
        },
        params: {
            'authHandler': authToken,
        },
        data: this.apiRequestBody
    });

    this.apiResponse = response;
});

Then('the response status code and confirmation number should be validated', async function (this: CustomWorld) {
    const response = this.apiResponse;
    expect(response.status()).toBe(200);

    const text = await response.text();
    const match = text.match(/<confirmationNumber>(.*?)<\/confirmationNumber>/);
    const confirmationNumber = match ? match[1] : null;

    expect(confirmationNumber).not.toBeNull();
    console.log(`Response status code validated: 200. Confirmation Number: ${confirmationNumber}`);
    expect(text).not.toContain('error');
});
