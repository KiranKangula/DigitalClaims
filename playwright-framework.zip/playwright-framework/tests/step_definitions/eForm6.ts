import { When, Then, And } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { CustomWorld } from './world';

When('User click on Submit Report button', async function (this: CustomWorld) {
    await this.initPages();
    console.log("Clicking on 'Submit Report' button.");
    expect(await this.eform6!.verifySubmitReportButtonDisplayed()).toBe(true);
    expect(await this.eform6!.clickSubmitReportButton()).toBe(true);
});

Then('User should be able to provide consent to the privacy statement', async function (this: CustomWorld) {
    await this.initPages();
    console.log('Providing consent to the privacy statement.');
    expect(await this.eform6!.clickPrivacyStatement()).toBe(true);
});

And('User should be able to select report type {string}', async function (this: CustomWorld, reporttypeParam: string) {
    await this.initPages();
    const reporttype = this.currentRow?.['ReportType'] || reporttypeParam;
    console.log(`Selecting report type: ${reporttype}`);
    await this.eform6!.selectReportType(reporttype);
});

And('User should be able to select Injury Type {string}', async function (this: CustomWorld, injurytypeParam: string) {
    await this.initPages();
    const injurytype = this.currentRow?.['InjuryType'] || injurytypeParam;
    console.log(`Selecting Injury Type: ${injurytype}`);
    await this.eform6!.selectInjuryType(injurytype);
});

And('User should be able to select radio {string}, Body Part {string}', async function (this: CustomWorld, physicalInjParam: string, bodyPartParam: string) {
    await this.initPages();
    const physicalInj = this.currentRow?.['PhyInjury'] || physicalInjParam;
    const bodyPart = this.currentRow?.['DescribeInjury'] || bodyPartParam;
    console.log(`Selecting Physical Injury: ${physicalInj}, Body Part: ${bodyPart}`);
    expect(await this.eform6!.selectBodyPart(physicalInj, bodyPart)).toBe(true);
});

And('User should be able to enter {string} if applicable', async function (this: CustomWorld, existingClaimnumberParam: string) {
    await this.initPages();
    const existingClaimnumber = this.currentRow?.['ExistingClaimNumber'] || existingClaimnumberParam;
    console.log(`Entering existing claim number (if applicable): ${existingClaimnumber}`);
    expect(await this.eform6!.enterExistingClaimNumber(existingClaimnumber)).toBe(true);
});

And('User should be able to enter {string}, {string}, {string}, {string}', async function (this: CustomWorld, firstNameParam: string, lastNameParam: string, phonenumberParam: string, pronounsParam: string) {
    await this.initPages();
    const firstName = this.currentRow?.['FirstName'] || firstNameParam;
    const lastName = this.currentRow?.['LastName'] || lastNameParam;
    const phonenumber = this.currentRow?.['PhoneNumber'] || phonenumberParam;
    const pronouns = this.currentRow?.['Pronouns'] || pronounsParam;
    console.log(`Entering personal information for: ${firstName} ${lastName}`);
    expect(await this.eform6!.enterPersonalInformation(firstName, lastName, phonenumber, pronouns)).toBe(true);
});

And('Enter Additional personal details', async function (this: CustomWorld) {
    await this.initPages();
    const gender = this.currentRow?.['Gender'] || '';
    const dateOfBirth = this.currentRow?.['DateofBirth'] || '';
    const preferredLang = this.currentRow?.['PreferredLanguage'] || '';
    const sin = this.currentRow?.['sinNumber'] || '';
    console.log(`Entering additional personal details: Gender=${gender}, DOB=${dateOfBirth}`);
    expect(await this.eform6!.enterAdditionalDetails(gender, dateOfBirth, preferredLang, sin)).toBe(true);
});

And('Enter Additional personal details - Exposure', async function (this: CustomWorld) {
    await this.initPages();
    const gender = this.currentRow?.['Gender'] || '';
    const dateOfBirth = this.currentRow?.['DateofBirth'] || '';
    console.log(`Entering additional details for exposure: Gender=${gender}, DOB=${dateOfBirth}`);
    expect(await this.eform6!.enterAdditionalDetails(gender, dateOfBirth)).toBe(true);
});

And('Enter Worker Address Details', async function (this: CustomWorld) {
    await this.initPages();
    const address = this.currentRow?.['Address'] || '';
    console.log(`Entering worker address details: ${address}`);
    expect(await this.eform6!.enterMailingAddress(address)).toBe(true);
});

And('Enter Employers Details', async function (this: CustomWorld) {
    await this.initPages();
    const employerName = this.currentRow?.['EmployerName'] || '';
    const empPhone = this.currentRow?.['EmployerPhone'] || '';
    const employerAddress = this.currentRow?.['EmployerAddress'] || '';
    console.log(`Entering employer details: ${employerName}`);
    await this.eform6!.enterEmployerDetails(employerName, empPhone, employerAddress);
});

Then('Verify the reference number is generated and displayed', async function (this: CustomWorld) {
    await this.initPages();
    const referenceClaimNumber = await this.eform6!.verifyReferenceNumber();
    console.log(`Reference Claim Number is: ${referenceClaimNumber}`);
    expect(referenceClaimNumber.length).toBeGreaterThan(0);
    if (this.currentRow) {
        this.currentRow['ReferenceNumber'] = referenceClaimNumber;
    }
});

And('Enter the Job Details of the Worker', async function (this: CustomWorld) {
    await this.initPages();
    const jobTitle = this.currentRow?.['JobTitle'] || '';
    const startDate = this.currentRow?.['JobStartDate'] || '';
    const empDurationYears = this.currentRow?.['EmpDurationYears'] || '';
    const empDurationMonths = this.currentRow?.['EmpDurationMonths'] || '';
    const supervisorFirstName = this.currentRow?.['SupervisorFirstName'] || '';
    const supervisorLastName = this.currentRow?.['SupervisorLastName'] || '';
    const supervisorPhoneNumber = this.currentRow?.['SupervisorPhoneNumber'] || '';
    const companySize = this.currentRow?.['CompanySize'] || '';
    const thirdPartyUnion = this.currentRow?.['ThirdPartyUnion'] || '';
    const nameOfTheUnion = this.currentRow?.['NameOfTheUnion'] || '';
    console.log(`Entering job details: Title=${jobTitle}, Start Date=${startDate}`);
    expect(await this.eform6_workhistory!.enterJobDetails(jobTitle, startDate, empDurationYears, empDurationMonths, supervisorFirstName, supervisorLastName, supervisorPhoneNumber, companySize, thirdPartyUnion, nameOfTheUnion)).toBe(true);
});

And('Enter the Job Details of the Worker - Exposure Incident', async function (this: CustomWorld) {
    await this.initPages();
    const jobTitle = this.currentRow?.['JobTitle'] || '';
    const startDate = this.currentRow?.['JobStartDate'] || '';
    const whatTypeOfWork = this.currentRow?.['WhatTypeofWork'] || '';
    const companySize = this.currentRow?.['CompanySize'] || '';
    console.log(`Entering job details for exposure: Title=${jobTitle}`);
    await this.eform6_workhistory!.enterJobDetails(jobTitle, startDate, whatTypeOfWork, companySize);
});

And('Enter Tell us about your work details', async function (this: CustomWorld) {
    await this.initPages();
    const relative = this.currentRow?.['Relative'] || '';
    const typesOfEmployment = this.currentRow?.['TypesofEmployment'] || '';
    console.log(`Entering work details: Employment Type=${typesOfEmployment}`);
    await this.eform6_workhistory!.enterWorkDetails(relative, typesOfEmployment);
});

And('Enter the Physical injury or illness details', async function (this: CustomWorld) {
    await this.initPages();
    const whatHappened = this.currentRow?.['WhatHappened'] || '';
    console.log(`Entering physical injury details: ${whatHappened}`);
    await this.eform6_injurydetails!.PhysicalInjuryDetails(whatHappened);
});

And('Enter Injury date and time', async function (this: CustomWorld) {
    await this.initPages();
    const injuryOneTimeDate = this.currentRow?.['InjuryDate'] || '';
    console.log(`Entering injury date and time: ${injuryOneTimeDate}`);
    await this.eform6_injurydetails!.enterInjuryDateAndTime(injuryOneTimeDate);
});

And('Enter Areas of Injury', async function (this: CustomWorld) {
    await this.initPages();
    const physicalInj = this.currentRow?.['PhysicalInjury'] || '';
    const bodyPart = this.currentRow?.['BodyPart'] || '';
    console.log(`Entering areas of injury: ${physicalInj} / ${bodyPart}`);
    await this.eform6_injurydetails!.selectBodyPart(physicalInj, bodyPart);
});

And('Enter Date and Time Injury Reported to Employer', async function (this: CustomWorld) {
    await this.initPages();
    const reportedToEmp = this.currentRow?.['ReportedtoEmp'] || '';
    const injurDateReptoEmployer = this.currentRow?.['InjurDateReptoEmployer'] || '';
    console.log(`Entering Date and contact information of reporting injury or illness to employer: ${reportedToEmp} / ${injurDateReptoEmployer}`);
    await this.eform6_injurydetails!.selectReportedToEmpl(reportedToEmp, injurDateReptoEmployer);
});

And('Enter Witnesses contact information', async function (this: CustomWorld) {
    await this.initPages();
    const witnessInvolved = this.currentRow?.['WitnessInvolved'] || '';
    const witnessFirstName = this.currentRow?.['WitnessFirstName'] || '';
    const witnessLastName = this.currentRow?.['WitnessLastName'] || '';
    const witnessPosition = this.currentRow?.['WitnessPosition'] || '';
    const witnessPhoneNumber = this.currentRow?.['WitnessPhoneNumber'] || '';
    console.log(`Entering witness contact information if involved: ${witnessInvolved}`);
    await this.eform6_injurydetails!.enterWitnessDetails(witnessInvolved, witnessFirstName, witnessLastName, witnessPosition, witnessPhoneNumber);
});

And('Enter Injury, illness or exposure incident address', async function (this: CustomWorld) {
    await this.initPages();
    console.log('Entering incident address.');
    await this.eform6_injurydetails!.enterIncidentAddress();
});

And('Enter Similar or related previous injury or illness details', async function (this: CustomWorld) {
    await this.initPages();
    const similarInjury = this.currentRow?.['SimilarInjury'] || '';
    const previousClaim = this.currentRow?.['PreviousClaim'] || '';
    const previousClaimNumber = this.currentRow?.['PreviousClaimNumber'] || '';
    const sameAreaofInjury = this.currentRow?.['SameAreaofInjury'] || '';
    const tellUsAboutPreviousInjury = this.currentRow?.['TellUsAboutPreviousInjury'] || '';
    console.log('Entering similar previous injury details.');
    await this.eform6_injurydetails!.enterSimilarInjuryDetails(similarInjury, previousClaim, previousClaimNumber, sameAreaofInjury, tellUsAboutPreviousInjury);
});

And('Enter Health care for injury or illness details', async function (this: CustomWorld) {
    await this.initPages();
    const healthCareReceived = this.currentRow?.['HealthCareReceived'] || '';
    const whenDoYouExpect = this.currentRow?.['Whendoyouexpect'] || '';
    const whereHealthCareReceived = this.currentRow?.['WhereHealthCareReceived'] || '';
    const healthCareReceivedDate = this.currentRow?.['HealthCareReceivedDate'] || '';
    const emplReportedDate = this.currentRow?.['EmplReportedDate'] || '';
    const reporter = this.currentRow?.['Reporter'] || '';
    const provider = this.currentRow?.['Provider'] || '';
    const providerOrg = this.currentRow?.['ProviderOrg'] || '';
    const providerOrgAddress = this.currentRow?.['ProviderOrgAddress'] || '';
    console.log('Entering health care details for injury.');
    await this.eform6_healthcare!.enterHealthCareDetails(healthCareReceived, whereHealthCareReceived, healthCareReceivedDate, emplReportedDate, reporter, provider, providerOrg, providerOrgAddress, whenDoYouExpect);
});

And('Enter Missed time from work details', async function (this: CustomWorld) {
    await this.initPages();
    const missedTimeFromWork = this.currentRow?.['MissedTimeFromWork'] || '';
    const missedTimeFromWorkStartDate = this.currentRow?.['MissedTimeStartDate'] || '';
    console.log(`Entering missed time details: ${missedTimeFromWork}`);
    await this.eform6_losttimeearnings!.enterMissedTimeFromWorkDetails(missedTimeFromWork, missedTimeFromWorkStartDate);
});

And('Enter Modified Work Details', async function (this: CustomWorld) {
    await this.initPages();
    const offeredTo = this.currentRow?.['OfferedTo'] || '';
    const modifiedDate = this.currentRow?.['ModifiedDate'] || '';
    const modifiedWork = this.currentRow?.['ModifiedWork'] || '';
    const declineReason = this.currentRow?.['DeclineReason'] || '';
    console.log('Entering modified work details.');
    await this.eform6_losttimeearnings!.enterModifiedWorkDetails(offeredTo, modifiedDate, modifiedWork, declineReason);
});

And('Enter Return to work details', async function (this: CustomWorld) {
    await this.initPages();
    const returningToWork = this.currentRow?.['ReturningToWork'] || '';
    const returningDate = this.currentRow?.['ReturningDate'] || '';
    const returnedDate = this.currentRow?.['ReturnedDate'] || '';
    const typeOfReturn = this.currentRow?.['TypeOfReturn'] || '';
    const wageLoss = this.currentRow?.['WageLoss'] || '';
    const rtwContact = this.currentRow?.['RTWContact'] || '';

    const nextYearDate = new Date();
    nextYearDate.setFullYear(nextYearDate.getFullYear() + 1);
    const formattedNextYearDate = nextYearDate.toISOString().split('T')[0];

    console.log(`Entering return to work details: Returning=${returningToWork}`);
    await this.eform6_losttimeearnings!.enterReturnToWorkDetails(returningToWork, returningDate, typeOfReturn, formattedNextYearDate, wageLoss, rtwContact, returnedDate);
});

And('Enter Additional earnings and benefits information', async function (this: CustomWorld) {
    await this.initPages();
    const additionalEarnings = this.currentRow?.['AdditionalEarnings?'] || '';
    const additionalBenefits = this.currentRow?.['AdditionalBenefits?'] || '';
    const didYouWorkforMorethanOneEmpl = this.currentRow?.['DidYouWorkforMorethanOneEmpl?'] || '';
    console.log('Entering additional earnings and benefits.');
    await this.eform6_losttimeearnings!.enterAdditionalEarningsAndBenefits(additionalEarnings, additionalBenefits, didYouWorkforMorethanOneEmpl);
});

And('Enter Authorized representative details', async function (this: CustomWorld) {
    await this.initPages();
    console.log('Entering authorized representative details.');
    await this.eform6_losttimeearnings!.enterAuthorizedRepDetails();
});

And('Enter Submit supporting documents details', async function (this: CustomWorld) {
    await this.initPages();
    console.log('Entering supporting documents details.');
    await this.eform6_supportingdocuments!.enterSupportingDocuments();
});

And('Enter Additional Comments details', async function (this: CustomWorld) {
    await this.initPages();
    const additionalComments = this.currentRow?.['AdditionalComments'] || '';
    console.log('Entering additional comments.');
    await this.eform6_supportingdocuments!.enterAdditionalComments(additionalComments);
});

And('Verify Review and submit report and Select Declaration checkbox', async function (this: CustomWorld) {
    await this.initPages();
    console.log('Verifying Review and submit report screen and selecting Declaration.');
    expect(await this.eform6_reviewandsubmit!.verifyReviewAndSubmitReport()).toBe(true);
});

And('Verify Review and submit report and Select Declaration checkbox and Submit Exposure', async function (this: CustomWorld) {
    await this.initPages();
    console.log('Verifying Review and submit for Exposure and submitting.');
    expect(await this.eform6_reviewandsubmit!.verifyReviewAndSubmitExposure()).toBe(true);
    await this.eform6_reviewandsubmit!.verifyReturnToDashBoard();
    console.log(`Report Submitted at: ${new Date().toLocaleString()}`);
});

And('Select decision to Add claim to your account and Submit Report', async function (this: CustomWorld) {
    await this.initPages();
    const addClaimtoProfile = this.currentRow?.['AddClaimtoProfile'] || '';
    console.log(`Selecting decision to add claim to profile: ${addClaimtoProfile}`);
    expect(await this.eform6_reviewandsubmit!.selectAddClaimtoProfile(addClaimtoProfile)).toBe(true);
    expect(await this.eform6_reviewandsubmit!.verifyReturnToDashBoard()).toBe(true);
    console.log(`Report Submitted at: ${new Date().toLocaleString()}`);
});

And('Enter the injury or illness details', async function (this: CustomWorld) {
    await this.initPages();
    const conditionInput = this.currentRow?.['ConditionInput'] || '';
    const relatedToWorkInput = this.currentRow?.['RelatedToWorkInput'] || '';
    const symptomsInput = this.currentRow?.['SymptomsInput'] || '';
    console.log('Entering injury or illness details.');
    await this.eform6_injurydetails!.enterInjuryDetails(conditionInput, relatedToWorkInput, symptomsInput);
});

And('Enter Illness or medical condition details', async function (this: CustomWorld) {
    await this.initPages();
    const illnessStartDate = this.currentRow?.['IllnessStartDate'] || '';
    console.log(`Entering illness details: Start Date=${illnessStartDate}`);
    await this.eform6_injurydetails!.enterIllnessDetails(illnessStartDate);
});

And('User should be able to Describe your Injury', async function (this: CustomWorld) {
    await this.initPages();
    const describeInjury = this.currentRow?.['DescribeInjury'] || '';
    console.log(`Describing injury: ${describeInjury}`);
    await this.eform6_injurydetails!.DescribeInjury(describeInjury);
});

And('Enter the Mental stress psychological injury details', async function (this: CustomWorld) {
    await this.initPages();
    const injuryDetailsInput = this.currentRow?.['InjuryDetailsInput'] || '';
    console.log('Entering mental stress injury details.');
    await this.eform6_injurydetails!.enterMentalInjuryDetails(injuryDetailsInput);
});

And('Enter Mental stress psychological injury date details', async function (this: CustomWorld) {
    await this.initPages();
    const injuryStartDate = this.currentRow?.['InjuryStartDate'] || '';
    const injuryEndDate = this.currentRow?.['InjuryEndDate'] || '';
    console.log(`Entering mental stress injury dates: ${injuryStartDate} to ${injuryEndDate}`);
    await this.eform6_injurydetails!.enterMentalInjuryDateDetails(injuryStartDate, injuryEndDate);
});

And('Enter Areas of Injury for Mental', async function (this: CustomWorld) {
    await this.initPages();
    const physicalInjury = this.currentRow?.['PhysicalInjury?'] || '';
    console.log(`Entering areas of injury for mental stress. Physical Injury Involved?=${physicalInjury}`);
    await this.eform6_injurydetails!.InjuredQuestion(physicalInjury);
    // Call enterAreasOfInjury() - this is a call to another step, in Cucumber TS we just call the function if we have access or define the logic.
    // Since enterAreasOfInjury is in the same file, I'll just call the logic.
    const physicalInj = this.currentRow?.['PhysicalInjury'] || '';
    const bodyPart = this.currentRow?.['BodyPart'] || '';
    await this.eform6_injurydetails!.selectBodyPart(physicalInj, bodyPart);
});

And('User should be able to select {string} report type', async function (this: CustomWorld, reporttype: string) {
    await this.initPages();
    console.log(`Selecting report type: ${reporttype}`);
    await this.eform6!.selectReportType(reporttype);
});

And('User should be able to select {string} Injury Type', async function (this: CustomWorld, injurytype: string) {
    await this.initPages();
    console.log(`Selecting injury type: ${injurytype}`);
    await this.eform6!.selectInjuryType(injurytype);
});

And('User should be able to land on Continue to different online service to make a claim for noise-induced hearing loss screen', async function (this: CustomWorld) {
    await this.initPages();
    console.log('Verifying landing on NIHL screen.');
    expect(await this.eform6!.verifyNIHLPage()).toBe(true);
});

And('User selects Submission Requirement', async function (this: CustomWorld) {
    await this.initPages();
    const submissionRequirement = this.currentRow?.['SubmissionRequirement'] || '';
    console.log(`Selecting submission requirement: ${submissionRequirement}`);
    await this.eform6!.selectSubmissionRequirement(submissionRequirement);
});

And('Enter Joint Health and Safety Committee details', async function (this: CustomWorld) {
    await this.initPages();
    const safetyCommittee = this.currentRow?.['SafetyCommittee?'] || '';
    const safetyRepresentative = this.currentRow?.['SafetyRepresentative?'] || '';
    const nameOfTheUnion = this.currentRow?.['NameOfTheUnion'] || '';
    console.log('Entering Joint Health and Safety Committee details.');
    await this.eform6_workhistory!.enterJointHealthAndSafetyCommittee(safetyCommittee, safetyRepresentative, nameOfTheUnion);
});

And('Enter the Exposure Incident details', async function (this: CustomWorld) {
    await this.initPages();
    const exposureTo = this.currentRow?.['ExposureTo?'] || '';
    const exposureDate = this.currentRow?.['ExposureDate'] || '';
    const howContacted = this.currentRow?.['HowContacted?'] || '';
    const sourceOfExposure = this.currentRow?.['Source'] || '';
    const whatSubstance = this.currentRow?.['WhatSubstance'] || '';
    const describeWhere = this.currentRow?.['DescribeWhere?'] || '';
    const whatAreYouWearing = this.currentRow?.['WhatareYouWearing?'] || '';
    console.log('Entering exposure incident details.');
    await this.eform6_exposuredetails!.enterExposureDetails(exposureTo, exposureDate, howContacted, sourceOfExposure, whatSubstance, describeWhere, whatAreYouWearing);
});

And('Upload and verify Form 6 supporting documents', async function (this: CustomWorld) {
    await this.initPages();
    const row = this.currentRow;
    if (!row) {
        throw new Error('Form 6 scenario data is not initialized.');
    }
    const files = row['SupportingFiles'];
    const documentTypes = row['SupportingDocumentTypes'];
    if (!files || files.trim() === '') {
        throw new Error('The upload scenario requires SupportingFiles in the selected JSON row.');
    }
    if (!documentTypes || documentTypes.trim() === '') {
        throw new Error('The upload scenario requires actual SupportingDocumentTypes dropdown labels.');
    }
    console.log(`[FORM 6 DOCUMENTS] Uploading and verifying: ${files}`);
    const uploadFolder = process.env.UPLOAD_FOLDER || 'src/test/resources/DocUploadFiles';
    const verified = await this.eform6_supportingdocuments!.enterSupportingDocuments(files, documentTypes, uploadFolder);
    row['VerifiedSupportingFiles'] = verified.join('|');
    console.log(`[FORM 6 DOCUMENTS] All configured files were verified in Your submitted documents: ${verified.join(' | ')}`);
});
