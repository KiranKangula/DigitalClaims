import { Before, After, Status } from '@cucumber/cucumber';
import { chromium, Browser, BrowserContext, Page } from '@playwright/test';
import { CustomWorld } from './world';

Before(async function (this: CustomWorld) {
    if (!this.browser) {
        this.browser = await chromium.launch({
            headless: process.env.HEADLESS === 'true'
        });
    }

    this.context = await this.browser.newContext({
        // Add any specific context options here (viewport, userAgent, etc.)
    });

    this.page = await this.context.newPage();

    // Listen for console logs to capture tokens
    this.page.on('console', msg => {
        if (msg.text().includes('Oauth token for request:')) {
            const token = msg.text().split('Oauth token for request:')[1].replace(/\"/g, '').trim();
            (window as any).lastCapturedToken = token;
            // We can also store it in world or a global
            process.env.BEARER_TOKEN = token;
        }
    });
});

After(async function (this: CustomWorld, scenario) {
    if (scenario.result?.status === Status.FAILED) {
        const screenshot = await this.page?.screenshot();
        if (screenshot) {
            const filename = `failure_${scenario.pickle.name}_${Date.now()}.png`;
            // In a real project, we'd save this to a report folder
            console.log(`Screenshot saved as ${filename}`);
        }
    }

    await this.page?.close();
    await this.context?.close();
});
