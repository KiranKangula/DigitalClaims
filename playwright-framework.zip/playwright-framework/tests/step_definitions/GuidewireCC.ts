import { Given, When, Then, And } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { CustomWorld } from '../../support/world';

/**
 * Helper to generate random alphanumeric text.
 */
function generateRandomText(length: number): string {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
}

/**
 * Helper to format date.
 * Note: In a real project, this would be moved to a date utility file.
 */
function getDateFormat(dateStr: string, fromFormat: string, toFormat: string): string {
    // Simplification for migration: assuming dates are handled or converted via a utility.
    return dateStr;
}

/**
 * Helper to get province abbreviation.
 */
function getProvinceAbbreviation(province: string): string {
    const provinces: Record<string, string> = {
        'Ontario': 'ON',
        'British Columbia': 'BC',
        'Alberta': 'AB',
        'Saskatchewan': 'SK',
        'Manitoba': 'MB',
        'Quebec': 'QC',
        'New Brunswick': 'NB',
        'Nova Scotia': 'NS',
        'Prince Edward Island': 'PE',
        'Newfoundland and Labrador': 'NL',
    };
    return provinces[province] || province;
}

Then('Switch to New tab and Login to ClaimCenter', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Switch to New tab and Login to ClaimCenter')) return;

    this.log('Switching to New tab and Logging into ClaimCenter');
    await this.gwLogin.switchTab();

    if (process.env.ENV?.toUpperCase() !== 'PPD') {
        const username = process.env.GWCC_Username || '';
        const password = process.env.GWCC_Password || '';
        this.log(`Logging into GWCC with Username: ${username} and Password: ${password}`);
        await this.gwLogin.loginToGWCC(username, password);
    } else {
        await this.gwLogin.switchToTopFrame();
    }
});

And('Search for {string}', async function (this: CustomWorld, claimnumber: string) {
    await this.initPages();
    if (!this.shouldRun('Search for ClaimNumber')) return;

    const claimNo = this.currentRow['Claim Number'];
    this.log(`Searching for Claim Number: ${claimNo}`);
    expect(await this.gwSearch.searchClaim(claimNo)).toBeTruthy();
});

And('Search for claim number', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Search for Claim Number')) return;

    const claimNo = this.currentRow['Claim Number'];
    this.log(`Searching for Claim Number: ${claimNo}`);
    expect(await this.gwSearch.searchClaim(claimNo)).toBeTruthy();
});

And('Search for UNCD {string}', async function (this: CustomWorld, claimnumber: string) {
    await this.initPages();
    if (!this.shouldRun('Search for UNCD')) return;

    const claimNo = this.currentRow['claimnumber'];
    this.log(`Searching for UNCD Claim Number: ${claimNo}`);
    expect(await this.gwSearch.searchClaim(claimNo)).toBeTruthy();
});

Then('User should be able to see the message displayed from OSPC', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('User should be able to see the message displayed from OSPC')) return;

    this.log('Verifying message displayed from OSPC');
    expect(await this.gwParticipants.verifySentMessage()).toBeTruthy();
});

And('Navigate to Portal Authorization screen', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Navigate to Portal Authorization Screen')) return;

    this.log('Navigating to Portal Authorization screen');
    expect(await this.gwAdmin.navigatePortalAuthScreen()).toBeTruthy();
});

And('Remove the {string} from profile', async function (this: CustomWorld, claimnumber: string) {
    await this.initPages();
    if (!this.shouldRun('Remove the Claim Number')) return;

    const claimNo = this.currentRow['Claim Number'];
    this.log(`Removing Claim Number from profile: ${claimNo}`);
    expect(await this.gwAdmin.removeClaimFromPortalAuth(claimNo)).toBeTruthy();
});

And('Remove all the claims from profile', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Remove all the claims from Profile')) return;

    this.log('Removing all claims from profile');
    expect(await this.gwAdmin.removeAllClaimFromPortalAuth()).toBeTruthy();
});

And('Search for Claim number', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Search for the Claim')) return;

    const claimNo = (this as any).DirectDeposit?.Claimnumber;
    this.log(`Searching for Claim Number: ${claimNo}`);
    expect(await this.gwSearch.searchClaim(claimNo)).toBeTruthy();
});

And('Verify the document is landed in GWCC with valid Author and Description', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Verify the document is landed in GWCC with valid Author and Description')) return;

    const author = this.currentRow['Author'];
    let description: string;
    const scenarioType = this.scenarioType;

    if (scenarioType === 'WSIB') {
        description = this.currentRow['Description'];
        this.log("Using 'Description' for WSIB scenario.");
    } else if (scenarioType === 'NonWSIB') {
        description = this.currentRow['nonDescription'];
        this.log("Using 'nonDescription' for NonWSIB scenario.");
    } else {
        this.log("Unknown scenario type or neither WSIB nor NonWSIB tag found. Defaulting to 'Description'.");
        description = this.currentRow['Description'];
    }

    this.log(`Verifying document in GWCC with Author: ${author} and Description: ${description}`);
    expect(await this.gwDocuments.verifyLandedDocument(author, description)).toBeTruthy();
});

And('Verify the document are landed in GWCC with valid Author and Description', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Verify the document are landed in GWCC with valid Author and Description')) return;

    const author = this.currentRow['Author'];
    let descriptionsJsonString: string;
    const scenarioType = this.scenarioType;

    if (scenarioType === 'WSIB') {
        descriptionsJsonString = this.currentRow['Descriptions'];
        this.log("Using 'Descriptions' for WSIB scenario.");
    } else if (scenarioType === 'NonWSIB') {
        descriptionsJsonString = this.currentRow['nonDescriptions'];
        this.log("Using 'nonDescriptions' for NonWSIB scenario.");
    } else {
        this.log("Unknown scenario type or neither WSIB nor NonWSIB tag found. Defaulting to 'Descriptions'.");
        descriptionsJsonString = this.currentRow['Descriptions'];
    }

    const descriptions = descriptionsJsonString.split('|').map(s => s.trim());
    this.log(`Verifying multiple documents in GWCC with Author: ${author} and Descriptions: ${descriptions}`);
    expect(await this.gwDocuments.verifyLandedDocuments(author, descriptions)).toBeTruthy();
});

And('Verify the document is landed in GWCC', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Verify the document is landed in GWCC')) return;

    const author = this.currentRow['Author'];
    const description = this.currentRow['Description'];
    this.log(`Verifying Unnumbered document in GWCC with Author: ${author} and Description: ${description}`);
    expect(await this.gwDocuments.verifyLandedUNCDDocument(author, description)).toBeTruthy();
});

And('Verify the EDOB document is landed in GWCC with {string}, {string}', async function (this: CustomWorld, authorParam: string, descriptionParam: string) {
    await this.initPages();
    if (!this.shouldRun('Verify the EDOB document is landed in GWCC with')) return;

    const author = this.currentRow['Author'];
    const description = this.currentRow['Description'];

    this.log(`Verifying EDOB document in GWCC with Author: ${author} and Description: ${description}`);
    expect(await this.gwDocuments.verifyLandedDocument(author, description)).toBeTruthy();
});

Given('User is on GWlogin page', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('User is on GWlogin page')) return;

    this.log('Verifying User is on GW Login Page');
    expect(await this.gwLogin.verifyOnGWCC()).toBeTruthy();
});

When('User submit username and password', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('User submit username and password')) return;

    if (process.env.ENV?.toUpperCase() !== 'PPD') {
        const username = process.env.GWCC_Username || '';
        const password = process.env.GWCC_Password || '';
        this.log(`Submitting GWCC Username: ${username} and Password: ${password}`);
        await this.gwLogin.loginToGWCC(username, password);
    }
});

Then('User should be able to login successfully into GWCC', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('User should be able to login successfully into GWCC')) return;

    this.log('Verifying successful login into GWCC');
    expect(await this.gwSearch.gwCCLoginSuccess()).toBeTruthy();
});

Given('User Logged into ClaimCenter', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('User Logged into ClaimCenter')) return;

    this.log('Verifying User is logged into ClaimCenter');
    expect(await this.gwSearch.gwCCLoginSuccess()).toBeTruthy();
});

When('User initiates Manual Registration', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('User initiates Manual Registration')) return;

    this.log('Initiating Manual Registration');
    expect(await this.gwRegistration.kickManualRegistration()).toBeTruthy();
});

Then('User selects Source of Information', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('User selects Source of Information')) return;

    this.log('Selecting Source of Information');
    await this.gwRegistration.selectSourceOfInformation();
});

And('User enters new worker information', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('User enters new worker information')) return;

    const gender = this.currentRow['gender'];
    const dob = this.currentRow['dateofbirth'];
    const postalcode = this.currentRow['postalcode'];
    const phonenumber = this.currentRow['phonenumber'];

    const manipulatedFirstName = 'KKFirst' + generateRandomText(5);
    const manipulatedLastName = 'KKLast' + generateRandomText(5);
    this.log(`Manipulating Name to: ${manipulatedFirstName} ${manipulatedLastName}`);

    this.currentRow['firstname'] = manipulatedFirstName;
    this.currentRow['lastname'] = manipulatedLastName;
    await this.persistCurrentRow();

    this.log('Entering New Worker Information');
    await this.gwRegistration.createNewWorker(manipulatedFirstName, manipulatedLastName, gender, dob, postalcode, phonenumber);
});

And('User searches for Account with bussiness activity', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('User searches for Account with bussiness activity')) return;

    this.log('Searching for Account with business activity');
    await this.gwRegistration.searchAccountNumber();
});

And('User enters Accident Details', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('User enters Accident Details')) return;

    const dateofAccident = this.currentRow['dateofaccident'];
    const dateReportedToEmployer = this.currentRow['dateReported'];
    this.log('Entering Accident Details');
    await this.gwRegistration.enterAccidentDetails(dateofAccident, dateReportedToEmployer);
});

And('User Enters Body part details', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('User Enters Body part details')) return;

    const areaofbody = this.currentRow['areaofbody'];
    const areaofinjury = this.currentRow['areaofinjury'];
    const accidentType = this.currentRow['accidentType'];
    const detailedaccidentType = this.currentRow['detailedaccidentType'];
    const natureofinjury = this.currentRow['natureofinjury'];
    this.log('Entering Body part details');
    await this.gwRegistration.enterBodyPartDetails(areaofbody, accidentType, areaofinjury, detailedaccidentType, natureofinjury);
});

And('Select Third Party accident', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Select Third Party accident')) return;

    this.log('Selecting Third Party Accident');
    await this.gwRegistration.tpaSelection();
});

And('Select Accident Location from the dropdown', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Select Accident Location from the dropdown')) return;

    this.log('Selecting Accident Location');
    await this.gwRegistration.selectAccidentLocation();
});

And('Select Health Care Received', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Select Health Care Received')) return;

    const hcIndicator = this.currentRow['HealthCareReceived'];
    this.log('Selecting Health Care Received');
    await this.gwRegistration.selectHealthCareReceived(hcIndicator);
});

And('Select Claim Type', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Select Claim Type')) return;

    const claimtype = this.currentRow['ClaimType'];
    this.log('Selecting Claim Type');
    await this.gwRegistration.selectClaimType(claimtype);
});

And('Click on Register Claim button and verify that Claim has been registered Successfully', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Click on Register Claim button and verify that Claim has been registered Successfully')) return;

    this.log('Registering Claim...');
    const claimData = await this.gwRegistration.registerClaim(); // [claimNumber, dob]

    this.currentRow['Claim Number'] = claimData[0];
    this.currentRow['DOB'] = claimData[1];

    this.log(`Claim Registered Successfully:: Claim Number:${claimData[0]} DOB:${claimData[1]}`);
    await this.persistCurrentRow();
});

And('Search for Reference Number', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Search for Reference Number')) return;

    const referenceNumber = this.currentRow['ReferenceNumber'];
    this.log(`Searching for Reference Number: ${referenceNumber}`);
    expect(await this.gwSearch.searchReference(referenceNumber)).toBeTruthy();
});

And('Verify intake and Worker Information and Validate worker Address', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Verify intake and Worker Information and Validate worker Address')) return;

    const fname = this.currentRow['FirstName'];
    const lname = this.currentRow['LastName'];
    const gender = this.currentRow['Gender'];
    const pronouns = this.currentRow['Pronouns'];
    this.log('Verifying intake and Worker Information and Validate worker Address');
    await this.gwRegistration.verifyIntakeWorkerInformation(fname, lname, gender, pronouns);
});

And('Search with firstname and lastname & dateofbirth {string}', async function (this: CustomWorld, dateofbirthParam: string) {
    await this.initPages();
    if (!this.shouldRun('Search with firstname and lastname & dateofbirth')) return;

    const dateofbirth = this.currentRow['dateofbirth'];
    this.log('Searching for firstname and lastname and dateofbirth');
    expect(await this.gwSearch.searchClaimant(this.firstname, this.lastname, dateofbirth)).toBeTruthy();
});

And('Verify the UNCD document is landed in GWCC with {string}, {string}', async function (this: CustomWorld, authorParam: string, descriptionParam: string) {
    await this.initPages();
    if (!this.shouldRun('Verify the UNCD document is landed in GWCC with ')) return;

    const author = this.currentRow['Author'];
    const description = this.currentRow['Description'];

    this.log(`Verifying UNCD document in GWCC with Author: ${author} and Description: ${description}`);
    expect(await this.gwDocuments.verifyLandedUNCDDocument(author, description)).toBeTruthy();
});

And('Search with firstname and lastname & dateofbirth', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Search with firstname and lastname & dateofbirth ')) return;

    const firstName = this.currentRow['First Name'];
    const lastName = this.currentRow['Last Name'];
    const dateOfBirth = getDateFormat(this.currentRow['dateOfBirth'], 'd/MMMM/yyyy', 'dd/MM/yyyy');
    this.log('Searching for firstname and lastname and dateofbirth');
    expect(await this.gwSearch.searchClaimant(firstName, lastName, dateOfBirth)).toBeTruthy();
});

And('Verify the Appeal is created in ClaimCenter', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Verify the Appeal is created in ClaimCenter')) return;

    this.log('Verifying the Appeal is created in ClaimCenter');
    expect(await this.gwAppeals.createAppeal()).toBeTruthy();
});

And('Run the DI batch job in ClaimCenter to process the Auto Registration', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Run the DI batch job in ClaimCenter to process the Auto Registration')) return;

    this.log('Running DI7 Auto Registration...');
    expect(await this.gwAppeals.runDIBatchJob('Process Auto Reg Claims')).toBeTruthy();
});

And('Verify the Claim is Auto Registered in ClaimCenter', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Verify the Claim is Auto Registered in ClaimCenter')) return;

    const firstName = this.currentRow['First Name'];
    const lastName = this.currentRow['Last Name'];
    const dateOfBirth = getDateFormat(this.currentRow['Date of Birth'], 'd/MMMM/yyyy', 'dd/MM/yyyy');
    this.log('Verifying the Claim is Auto Registered in ClaimCenter');
    expect(await this.gwSearch.searchDIClaim(firstName, lastName, dateOfBirth)).toBeTruthy();
});

And('Verify the Mailing address is updated in GWCC', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Verify the Mailing address is updated in GWCC')) return;

    const addrLine1Raw = this.currentRow['Address Line1'] || '';
    const parts = addrLine1Raw.split('-');
    const addressLine1 = (parts[1] || '') + ' UNIT ' + (parts[0] || '');

    const addressLine2 = (this.currentRow['City'] || '') + ' ' +
                         getProvinceAbbreviation(this.currentRow['Province'] || '') + ' ' +
                         (this.currentRow['Postal Code'] || '');

    const addressLine3 = this.currentRow['Country'] || '';

    this.log('Verifying Mailing Address is updated in GWCC');
    expect(await this.gwParticipants.verifyUpdatedMailingAddress(addressLine1, addressLine2, addressLine3)).toBeTruthy();
});

And('Verify that history events are generated for Mailing address update in GWCC', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Verify that history events are generated for Mailing address update in GWCC')) return;

    const address = (this.currentRow['Address Line1'] || '') +
                    ',\\n' + (this.currentRow['City'] || '') + ', ' +
                    getProvinceAbbreviation(this.currentRow['Province'] || '') + ' ' +
                    (this.currentRow['Postal Code'] || '');

    const onlineUser = process.env.OSPC_username || '';
    this.log('Verifying that history events are generated for Mailing address update in GWCC');
    expect(await this.gwCCHistory.verifyHistoryEventForMailingAddressUpdate(address, onlineUser)).toBeTruthy();
});

And('Verify the Phone Number is updated in GWCC', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Verify the Phone Number is updated in GWCC')) return;

    const phoneNumber = this.currentRow['Phone Number'];
    this.log('Verifying Phone Number is updated in GWCC');
    expect(await this.gwParticipants.verifyUpdatedPhoneNumber(phoneNumber)).toBeTruthy();
});

And('Verify that history events are generated for Phone Number update in GWCC', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Verify that history events are generated for Phone Number update in GWCC')) return;

    const phoneNumber = this.currentRow['Phone Number'];
    const onlineUser = process.env.OSPC_username || '';
    this.log('Verifying that history events are generated for Phone Number update in GWCC');
    expect(await this.gwCCHistory.verifyHistoryEventForPhoneNumberUpdate(phoneNumber, onlineUser)).toBeTruthy();
});

Given('I have created a new claim in GW ClaimCenter with New Worker', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('I have created a new claim in GW ClaimCenter with New Worker')) return;

    await this.userLoggedIntoClaimCenter();
    await this.userInitiatesManualRegistration();
    await this.userSelectsSourceOfInformation();
    await this.userEntersNewWorkerInformation();
    await this.userSearchesForWithBusinessActivity();
    await this.userEntersAccidentDetails();
    await this.userEntersBodyPartDetails();
    await this.selectThirdPartyAccident();
    await this.selectAccidentLocation();
    await this.selectHealthCareReceived();
    await this.selectClaimType();
    await this.clickOnRegisterClaimButton();
});

Then('Setup Appeals Data on the Claim', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Setup Appeals Data on the Claim')) return;

    this.log('Setup Appeals Data on the Claim');
    expect(await this.gwAppeals.createAppeal()).toBeTruthy();
});

Then('Setup RTW information on the Claim', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Setup RTW information on the Claim')) return;

    const rtwData = {
        proposedRtwGoal: this.currentRow['Proposed_RTW_Goal'],
        proposedInterimRtwGoal: this.currentRow['Proposed_Interim_RTW_Goal'],
        proposedRecoveryGoal: this.currentRow['Proposed_Recovery_Goal'],
        proposedDateRtwGoal: this.currentRow['ProposedDate_RTW_Goal'],
        proposedDateInterimRtwGoal: this.currentRow['ProposedDate_Interim_RTW_Goal'],
        proposedDateRecoveryGoal: this.currentRow['ProposedDate_Recovery_Goal'],
        currentRtwStatus: this.currentRow['Current_RTW_Status'],
        currentRecoveryStatus: this.currentRow['Current_Recovery_Status'],
        actualRtwGoal: this.currentRow['Actual_RTW_Goal'],
        actualRecoveryGoal: this.currentRow['Actual_Recovery_Goal'],
        actualRtwDate: this.currentRow['Actual_RTW_Date'],
        actualRecoveryDate: this.currentRow['Actual_Recovery_Date'],
    };

    this.log('Setup RTW information on the Claim');
    expect(await this.gwRecovery.setupRTWData(
        rtwData.proposedRtwGoal, rtwData.proposedInterimRtwGoal, rtwData.proposedRecoveryGoal,
        rtwData.proposedDateRtwGoal, rtwData.proposedDateInterimRtwGoal, rtwData.proposedDateRecoveryGoal,
        rtwData.currentRtwStatus, rtwData.currentRecoveryStatus, rtwData.actualRtwGoal,
        rtwData.actualRecoveryGoal, rtwData.actualRtwDate, rtwData.actualRecoveryDate
    )).toBeTruthy();
});

And('User searches for Existing Worker', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('User searches for Existing Worker')) return;

    const wcbId = this.currentRow['WCB ID'];
    this.log(`Searching for Existing Worker with WCB ID: ${wcbId}`);
    expect(await this.gwRegistration.searchExistingWorker(wcbId)).toBeTruthy();
});

Given('I have created a new claim in GW ClaimCenter with Existing Worker', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('I have created a new claim in GW ClaimCenter with Existing Worker')) return;

    await this.userLoggedIntoClaimCenter();
    await this.userInitiatesManualRegistration();
    await this.userSelectsSourceOfInformation();
    await this.userSearchesForExistingWorker();
    await this.userSearchesForWithBusinessActivity();
    await this.userEntersAccidentDetails();
    await this.userEntersBodyPartDetails();
    await this.selectThirdPartyAccident();
    await this.selectAccidentLocation();
    await this.selectHealthCareReceived();
    await this.selectClaimType();
    await this.clickOnRegisterClaimButton();
});

Then('Setup Device Details on the Claim', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Setup Device Details on the Claim')) return;

    const rowData = this.currentRow;
    let devices: any[] = [];

    if (rowData['DevicesData']) {
        try {
            devices = JSON.parse(rowData['DevicesData']);
        } catch (e) {
            this.log(`Error parsing Device Data: ${e}`);
        }
    } else if (rowData['Device_Category']) {
        const firstDevice = { ...rowData };
        devices.push(firstDevice);

        let index = 1;
        while (rowData[`Device_Category_${index}`]) {
            devices.push({
                Device_Category: rowData[`Device_Category_${index}`],
                Device_Type: rowData[`Device_Type_${index}`],
                Device_Status: rowData[`Device_Status_${index}`],
                Device_ServiceType: rowData[`Device_ServiceType_${index}`],
                Device_StartDate: rowData[`Device_StartDate_${index}`],
                Device_EndDate: rowData[`Device_EndDate_${index}`],
                Device_DecisionDate: rowData[`Device_DecisionDate_${index}`],
                PurposeReview: rowData[`PurposeReview_${index}`],
                Rationale: rowData[`Rationale_${index}`],
            });
            index++;
        }
    }

    if (devices.length === 0) {
        this.log('No device data found in JSON.');
        return;
    }

    for (let i = 0; i < devices.length; i++) {
        const device = devices[i];
        this.log(`Setup Device Details on the Claim (Record ${i + 1})`);
        expect(await this.gwRecovery.setupDeviceData(
            device.Device_Category, device.Device_Type, device.Device_Status,
            device.Device_ServiceType, device.Device_StartDate, device.Device_EndDate,
            device.Device_DecisionDate, device.PurposeReview, device.Rationale
        )).toBeTruthy();
    }
});

Then('Setup Independent Living Allowance on the Claim', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Setup Independent Living Allowance on the Claim')) return;

    const rowData = this.currentRow;
    let dataList: any[] = [];

    if (rowData['ILA_Data']) {
        try {
            dataList = JSON.parse(rowData['ILA_Data']);
        } catch (e) {
            this.log(`Error parsing ILA Data: ${e}`);
        }
    } else if (rowData['ILA_Status']) {
        dataList.push(rowData);
    }

    for (let i = 0; i < dataList.length; i++) {
        const data = dataList[i];
        this.log(`Setup Independent Living Allowance on the Claim (Record ${i + 1})`);
        expect(await this.gwRecovery.setupILAData(data.ILA_Status, data.ILA_FromDate, data.ILA_ToDate)).toBeTruthy();
    }
});

Then('Setup Personal Care Allowance on the Claim', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Setup Personal Care Allowance on the Claim')) return;

    const rowData = this.currentRow;
    let dataList: any[] = [];

    if (rowData['PCA_Data']) {
        try {
            dataList = JSON.parse(rowData['PCA_Data']);
        } catch (e) {
            this.log(`Error parsing PCA Data: ${e}`);
        }
    } else if (rowData['PCA_AssesmentType']) {
        dataList.push(rowData);
    }

    for (let i = 0; i < dataList.length; i++) {
        const data = dataList[i];
        this.log(`Setup Personal Care Allowance on the Claim (Record ${i + 1})`);
        expect(await this.gwRecovery.setupPCAData(
            data.PCA_AssesmentType, data.PCA_AssessmentOutcome, data.PCA_FromDate,
            data.PCA_ToDate, data.PCA_ReassesRequired, data.PCA_ReassessmentDate
        )).toBeTruthy();
    }
});

Then('Setup Treatment Details on the Claim', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Setup Treatment Details on the Claim')) return;

    const rowData = this.currentRow;
    let dataList: any[] = [];

    if (rowData['Treatment_Data']) {
        try {
            dataList = JSON.parse(rowData['Treatment_Data']);
        } catch (e) {
            this.log(`Error parsing Treatment Data: ${e}`);
        }
    } else if (rowData['Treatment_Type']) {
        dataList.push(rowData);
    }

    for (let i = 0; i < dataList.length; i++) {
        const data = dataList[i];
        this.log(`Setup Treatment Details on the Claim (Record ${i + 1})`);
        expect(await this.gwRecovery.setupTreatmentData(
            data.Treatment_Type, data.Treatment_Status, data.Treatment_StartDate,
            data.Treatment_EndDate, data.Treatment_FreqNum, data.Treatment_EntitlementDUnit,
            data.PurposeReview, data.Rationale
        )).toBeTruthy();
    }
});

Then('Setup Medication Details on the Claim', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Setup Medication Details on the Claim')) return;

    const rowData = this.currentRow;
    let dataList: any[] = [];

    if (rowData['Medication_Data']) {
        try {
            dataList = JSON.parse(rowData['Medication_Data']);
        } catch (e) {
            this.log(`Error parsing Medication Data: ${e}`);
        }
    } else if (rowData['Medication_Type']) {
        dataList.push(rowData);
    }

    for (let i = 0; i < dataList.length; i++) {
        const data = dataList[i];
        this.log(`Setup Medication Details on the Claim (Record ${i + 1})`);
        expect(await this.gwRecovery.setupMedicationData(
            data.Medication_Type, data.Medication_Status, data.Medication_Formulary,
            data.Medication_StartDate, data.Medication_EndDate, data.PurposeReview, data.Rationale
        )).toBeTruthy();
    }
});

Then('Setup Payments data on the Claim', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Setup Payments data on the Claim')) return;

    const checkSourceId = this.currentRow['CheckSourceId'];
    const payee = this.currentRow['firstname'];
    const payTo = this.currentRow['lastname'];
    const status = this.currentRow['Status'];
    const tAmount = this.currentRow['TAmount'];
    const issuedDate = this.currentRow['IssuedDate'];
    const costCategory = this.currentRow['CostCategory'];
    const costType = this.currentRow['CostType'];
    const amount = this.currentRow['Amount'];
    const payFromDate = this.currentRow['PayFromDate'];
    const payToDate = this.currentRow['PayToDate'];

    this.log('Setup Payments data on the Claim');
    expect(await this.gwRecovery.setupPaymentsData(
        checkSourceId, payee, payTo, status, tAmount, issuedDate,
        costCategory, costType, amount, payFromDate, payToDate
    )).toBeTruthy();
});

Then('Setup Clothing Allowance on the Claim', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Setup Clothing Allowance on the Claim')) return;

    const rowData = this.currentRow;
    let dataList: any[] = [];

    if (rowData['Clothing_Data']) {
        try {
            dataList = JSON.parse(rowData['Clothing_Data']);
        } catch (e) {
            this.log(`Error parsing Clothing Data: ${e}`);
        }
    } else if (rowData['ClothingAllowanceApproved']) {
        dataList.push(rowData);
    }

    for (let i = 0; i < dataList.length; i++) {
        const data = dataList[i];
        this.log(`Setup Clothing Allowance on the Claim (Record ${i + 1})`);
        expect(await this.gwRecovery.setupClothingAllowanceData(
            data.ClothingAllowanceApproved, data.ClothingAllowance_DecisionDate
        )).toBeTruthy();
    }
});

And('Search for the NIHL claimant in GWCC', async function (this: CustomWorld) {
    await this.initPages();
    if (!this.shouldRun('Search for the NIHL claimant in GWCC')) return;

    const row = this.currentRow;
    const firstName = row['First Name'];
    const lastName = row['Last Name'];
    const dob = getDateFormat(row['dateOfBirth'], 'd/MMMM/yyyy', 'dd/MM/yyyy');

    const timeout = parseInt(process.env.NIHLClaimTimeoutSeconds || '900');
    const poll = parseInt(process.env.NIHLPollSeconds || '30');

    expect(await this.gwSearch.searchNIHLClaimant(firstName, lastName, dob, timeout, poll)).toBeTruthy();
});

And('Verify the NIHL submission documents landed in GWCC', async function (this: CustomWorld, table: any) {
    await this.initPages();
    if (!this.shouldRun('Verify the NIHL submission documents landed in GWCC')) return;

    const row = this.currentRow;
    const reference = row['NIHLGWCCReference'];
    const submittedOn = row['NIHLSubmissionDate'];

    const options = table.hashes()[0];
    const uploaded: string[] = [];

    if (row['HealthCareFiles']) {
        uploaded.push(...row['HealthCareFiles'].split('|').map((s: string) => s.trim()));
    }
    if (row['EmploymentFiles']) {
        uploaded.push(...row['EmploymentFiles'].split('|').map((s: string) => s.trim()));
    }

    const descriptions = (options['SupportingDescriptions'] || '').split('|').map((s: string) => s.trim());
    const authors = (options['SupportingAuthors'] || '').split('|').map((s: string) => s.trim());

    if (descriptions.length !== uploaded.length) {
        throw new Error(`Configured ${descriptions.length} supporting GWCC descriptions for ${uploaded.length} uploaded files.`);
    }

    const expected = [];
    expected.push({
        author: row['Author'],
        description: row['Description'],
        isOptional: false
    });

    for (let i = 0; i < descriptions.length; i++) {
        expected.push({
            author: authors.length === 1 ? authors[0] : authors[i],
            description: descriptions[i],
            isOptional: false
        });
    }

    this.log(`[NIHL GWCC] Verifying reference ${reference}; expected report/supporting row occurrences=${expected.length}`);

    const timeout = parseInt(process.env.NIHLDocumentTimeoutSeconds || '900');
    const poll = parseInt(process.env.NIHLPollSeconds || '30');
    const maxPages = parseInt(process.env.NIHLMaxDocumentPages || '200');

    expect(await this.gwDocuments.verifyNIHLUNCDDocuments(expected, submittedOn, timeout, poll, maxPages)).toBeTruthy();
});
