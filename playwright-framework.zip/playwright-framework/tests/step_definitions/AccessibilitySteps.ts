import { When, Then, And } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { CustomWorld } from './world';
import { AccessibilityUtils } from '../../utils/AccessibilityUtils';

When('User runs accessibility scan on {string}', async function (this: CustomWorld, pageName: string) {
    await this.initPages();
    console.log(`Running accessibility scan on ${pageName}.`);
    this.lastScanResults = await AccessibilityUtils.runAccessibilityScan(this.page!, pageName);

    const summary = AccessibilityUtils.buildViolationSummary(this.lastScanResults);
    console.log(summary);
});

Then('the page should have no critical WCAG violations', async function (this: CustomWorld) {
    if (!this.lastScanResults) {
        throw new Error("No accessibility scan results found. Run a scan first.");
    }
    const summary = AccessibilityUtils.buildViolationSummary(this.lastScanResults);
    const hasCritical = AccessibilityUtils.hasCriticalViolations(this.lastScanResults);
    expect(hasCritical, `Critical/Serious WCAG violations found:\n${summary}`).toBe(false);
});

Then('the page should have no WCAG violations', async function (this: CustomWorld) {
    if (!this.lastScanResults) {
        throw new Error("No accessibility scan results found. Run a scan first.");
    }
    const summary = AccessibilityUtils.buildViolationSummary(this.lastScanResults);
    const violationsCount = this.lastScanResults.violations?.length || 0;
    expect(violationsCount, `WCAG violations found:\n${summary}`).toBe(0);
});

And('User logs all WCAG results without failing', async function (this: CustomWorld) {
    if (!this.lastScanResults) {
        console.log("No accessibility scan results to log.");
        return;
    }
    const summary = AccessibilityUtils.buildViolationSummary(this.lastScanResults);
    console.log(summary);
});
